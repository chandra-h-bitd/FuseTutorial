/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.SimpleBeanInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceAdapterConfigurationBeanInfo
/*     */   extends SimpleBeanInfo
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/ResourceAdapterConfigurationBeanInfo.java";
/*  69 */   private static final Class beanClass = ResourceAdapterConfiguration.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceAdapterConfigurationBeanInfo()
/*     */   {
/*  76 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterConfigurationBeanInfo()", "<init>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  81 */     JCATraceAdapter.traceExit(this, "ResourceAdapterConfigurationBeanInfo()", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/*  93 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     
/*     */     try
/*     */     {
/*  97 */       PropertyDescriptor connectionConcurrency = new PropertyDescriptor("connectionConcurrency", beanClass);
/*     */       
/*  99 */       connectionConcurrency.setExpert(true);
/*     */       
/* 101 */       logWriterEnabled = new PropertyDescriptor("logWriterEnabled", beanClass);
/* 102 */       logWriterEnabled.setExpert(true);
/*     */       
/* 104 */       PropertyDescriptor maxConnections = new PropertyDescriptor("maxConnections", beanClass);
/* 105 */       maxConnections.setExpert(true);
/*     */       
/* 107 */       PropertyDescriptor reconnectionRetryCount = new PropertyDescriptor("reconnectionRetryCount", beanClass);
/*     */       
/* 109 */       reconnectionRetryCount.setExpert(true);
/*     */       
/* 111 */       PropertyDescriptor reconnectionRetryInterval = new PropertyDescriptor("reconnectionRetryInterval", beanClass);
/*     */       
/* 113 */       reconnectionRetryInterval.setExpert(true);
/*     */       
/* 115 */       PropertyDescriptor startupRetryCount = new PropertyDescriptor("startupRetryCount", beanClass);
/*     */       
/* 117 */       startupRetryCount.setExpert(true);
/*     */       
/* 119 */       PropertyDescriptor startupRetryInterval = new PropertyDescriptor("startupRetryInterval", beanClass);
/*     */       
/* 121 */       startupRetryInterval.setExpert(true);
/*     */       
/* 123 */       PropertyDescriptor traceEnabled = new PropertyDescriptor("traceEnabled", beanClass);
/* 124 */       traceEnabled.setPreferred(true);
/*     */       
/* 126 */       PropertyDescriptor traceLevel = new PropertyDescriptor("traceLevel", beanClass);
/* 127 */       traceLevel.setPreferred(true);
/*     */       
/*     */ 
/* 130 */       PropertyDescriptor nativeLibraryPath = new PropertyDescriptor("nativeLibraryPath", beanClass);
/* 131 */       nativeLibraryPath.setPreferred(true);
/*     */       
/*     */ 
/* 134 */       PropertyDescriptor[] rv = { connectionConcurrency, logWriterEnabled, maxConnections, reconnectionRetryCount, reconnectionRetryInterval, startupRetryCount, startupRetryInterval, traceEnabled, traceLevel, nativeLibraryPath };
/*     */       
/*     */ 
/* 137 */       return rv;
/*     */     }
/*     */     catch (IntrospectionException e) {
/*     */       PropertyDescriptor logWriterEnabled;
/* 141 */       JCATraceAdapter.traceException(this, "ResourceAdapterConfigurationBeanInfo", "getPropertyDescriptors()", e);
/*     */       
/* 143 */       return null;
/*     */     }
/*     */     finally
/*     */     {
/* 147 */       JCATraceAdapter.traceExit(this, "ResourceAdapterConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/ResourceAdapterConfigurationBeanInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */