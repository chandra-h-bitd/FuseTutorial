/*      */ package com.ibm.mq.connector;
/*      */ 
/*      */ import com.ibm.mq.connector.configuration.CleanupLevelEnum;
/*      */ import com.ibm.mq.connector.configuration.ReadAheadAllowedEnum;
/*      */ import com.ibm.mq.connector.configuration.SubscriptionStoreEnum;
/*      */ import com.ibm.mq.connector.configuration.TransportTypeEnum;
/*      */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*      */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*      */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*      */ import java.io.Serializable;
/*      */ import java.util.HashMap;
/*      */ import javax.resource.spi.InvalidPropertyException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractConfiguration
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 4815162342L;
/*      */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*      */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/AbstractConfiguration.java";
/*      */   public static final String MQJCA_BROKER_V1 = "1";
/*      */   public static final String MQJCA_BROKER_V2 = "2";
/*   83 */   private static final String[] brokerVersionValues = { "1", "2" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_CLONE_SUPPORT_ENABLED = "ENABLED";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_CLONE_SUPPORT_DISABLED = "DISABLED";
/*      */   
/*      */ 
/*   92 */   private static final String[] cloneSupportValues = { "DISABLED", "ENABLED" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSEL_CLIENT = "CLIENT";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSEL_BROKER = "BROKER";
/*      */   
/*      */ 
/*  101 */   private static final String[] messageSelectionValues = { "CLIENT", "BROKER" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_HDR_COMP_NONE = "NONE";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_HDR_COMP_SYSTEM = "SYSTEM";
/*      */   
/*      */ 
/*  110 */   private static final String[] hdrCompressionValues = { "NONE", "SYSTEM" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSG_COMP_NONE = "NONE";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSG_COMP_RLE = "RLE";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSG_COMP_ZLIBHIGH = "ZLIBHIGH";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_MSG_COMP_ZLIBFAST = "ZLIBFAST";
/*      */   
/*      */ 
/*  125 */   private static final String[] msgCompressionValues = { "NONE", "RLE", "ZLIBFAST", "ZLIBHIGH" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_SPARSE_FALSE = "FALSE";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_SPARSE_TRUE = "TRUE";
/*      */   
/*      */ 
/*  134 */   private static final String[] sparseValues = { "FALSE", "TRUE" };
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String MQJCA_TP_CLIENT_MQ_TCPIP = "CLIENT";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String MQJCA_TP_BINDINGS_MQ = "BINDINGS";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String MQJCA_TP_BINDINGS_CLIENT_MQ = "BINDINGS_THEN_CLIENT";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_PROVIDER_VER_UNSPECIFIED = "UNSPECIFIED";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_SHARECONV_YES = "YES";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_SHARECONV_NO = "NO";
/*      */   
/*      */ 
/*      */   private static final String MQJCA_SHARECONV_TRUE = "TRUE";
/*      */   
/*      */ 
/*      */   private static final String MQJCA_SHARECONV_FALSE = "FALSE";
/*      */   
/*      */ 
/*  164 */   private static final String[] shareConvAllowedValues = { "NO", "YES" };
/*      */   
/*      */ 
/*      */   public static final String MQJCA_WILDCARD_TOPIC_ONLY = "TOPIC";
/*      */   
/*      */ 
/*      */   public static final String MQJCA_WILDCARD_CHAR_ONLY = "CHAR";
/*      */   
/*      */ 
/*  173 */   private static final String[] wildcardFormatAllowedValues = { "TOPIC", "CHAR" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  181 */   private String brokerCCSubQueue = "SYSTEM.JMS.ND.CC.SUBSCRIBER.QUEUE";
/*      */   
/*      */ 
/*  184 */   private String brokerSubQueue = "SYSTEM.JMS.ND.SUBSCRIBER.QUEUE";
/*      */   
/*      */ 
/*  187 */   private String brokerPubQueue = "SYSTEM.BROKER.DEFAULT.STREAM";
/*      */   
/*      */ 
/*  190 */   private String brokerControlQueue = "SYSTEM.BROKER.CONTROL.QUEUE";
/*      */   
/*      */ 
/*  193 */   private String brokerQueueManager = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  199 */   private String brokerVersion = "1";
/*      */   
/*      */ 
/*  202 */   private String ccdtURL = null;
/*      */   
/*      */ 
/*  205 */   private int CCSID = 819;
/*      */   
/*      */ 
/*  208 */   private int receiveCCSID = 1208;
/*      */   
/*      */ 
/*  211 */   private String receiveConversion = "CLIENT_MSG";
/*      */   
/*      */ 
/*      */   public static final String DEFAULT_CHANNEL = "SYSTEM.DEF.SVRCONN";
/*      */   
/*  216 */   private String channel = "SYSTEM.DEF.SVRCONN";
/*      */   
/*      */ 
/*  219 */   private long cleanupInterval = 3600000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  224 */   private CleanupLevelEnum cleanupLevel = CleanupLevelEnum.SAFE;
/*      */   
/*      */ 
/*      */   private String applicationName;
/*      */   
/*      */   private String badCleanupLevel;
/*      */   
/*  231 */   private String clientId = null;
/*      */   
/*      */ 
/*  234 */   private String cloneSupport = "DISABLED";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  239 */   private boolean failIfQuiesce = true;
/*      */   
/*      */ 
/*  242 */   private String headerCompression = "NONE";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  248 */   private String hostName = "localhost";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  253 */   private String localAddress = null;
/*      */   
/*      */ 
/*  256 */   private String messageCompression = "NONE";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  262 */   private String messageSelection = "CLIENT";
/*      */   
/*      */ 
/*  265 */   private String password = null;
/*      */   
/*      */ 
/*  268 */   private int port = 1414;
/*      */   
/*      */ 
/*  271 */   private int pollingInterval = 5000;
/*      */   
/*      */ 
/*  274 */   private String queueManager = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  281 */   private String receiveExit = null;
/*      */   
/*      */ 
/*  284 */   private String receiveExitInit = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  290 */   private int rescanInterval = 5000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  297 */   private String securityExit = null;
/*      */   
/*      */ 
/*  300 */   private String securityExitInit = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  307 */   private String sendExit = null;
/*      */   
/*      */ 
/*  310 */   private String sendExitInit = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  315 */   private String sparseSubscriptions = "FALSE";
/*      */   
/*      */ 
/*  318 */   private String sslCertStores = null;
/*      */   
/*      */ 
/*  321 */   private String sslCipherSuite = null;
/*      */   
/*      */ 
/*  324 */   private boolean sslFipsRequired = false;
/*      */   
/*      */ 
/*  327 */   private String sslPeerName = null;
/*      */   
/*      */ 
/*  330 */   private int sslResetCount = 0;
/*      */   
/*      */ 
/*  333 */   private int statusRefreshInterval = 60000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  338 */   private SubscriptionStoreEnum subscriptionStore = SubscriptionStoreEnum.MIGRATE;
/*      */   
/*      */   private String badSubscriptionStore;
/*      */   
/*  342 */   private TransportTypeEnum transportType = TransportTypeEnum.CLIENT;
/*      */   
/*      */ 
/*  345 */   private String badTransportType = null;
/*      */   
/*      */ 
/*  348 */   private String username = null;
/*      */   
/*      */ 
/*      */   public static final String MQJCA_DEFAULT_CONNECTION_NAME_LIST = "localhost(1414)";
/*      */   
/*      */ 
/*  354 */   private String connectionNameList = "localhost(1414)";
/*      */   
/*      */ 
/*  357 */   private String qmid = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */   private String arbitraryProperties = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  372 */   private String providerVersion = "UNSPECIFIED";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  377 */   private ReadAheadAllowedEnum readAheadAllowed = ReadAheadAllowedEnum.AS_DEST;
/*      */   
/*      */ 
/*      */ 
/*      */   private String badReadAheadAllowed;
/*      */   
/*      */ 
/*  384 */   private String shareConvAllowed = "YES";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  390 */   private String shareConvAllowedExt = this.shareConvAllowed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  395 */   private String sslSocketFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  400 */   private String wildcardFormat = "TOPIC";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  405 */   protected final HashMap<String, Object> inserts = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationName(String applicationName)
/*      */   {
/*  425 */     if (JCATraceAdapter.isOn) {
/*  426 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setApplicationName", "ApplicationName", applicationName);
/*      */     }
/*  428 */     this.applicationName = applicationName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getApplicationName()
/*      */   {
/*  437 */     return this.applicationName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerCCSubQueue(String brokerCCSubQueue)
/*      */   {
/*  447 */     if (JCATraceAdapter.isOn) {
/*  448 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerCCSubQueue", "brokerCCSubQueue", brokerCCSubQueue);
/*      */     }
/*      */     
/*  451 */     this.brokerCCSubQueue = brokerCCSubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrokerCCSubQueue()
/*      */   {
/*  460 */     return this.brokerCCSubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerControlQueue(String brokerControlQueue)
/*      */   {
/*  470 */     if (JCATraceAdapter.isOn) {
/*  471 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerControlQueue", "brokerControlQueue", brokerControlQueue);
/*      */     }
/*      */     
/*  474 */     this.brokerControlQueue = brokerControlQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrokerControlQueue()
/*      */   {
/*  483 */     return this.brokerControlQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerSubQueue(String brokerSubQueue)
/*      */   {
/*  491 */     if (JCATraceAdapter.isOn) {
/*  492 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerSubQueue", "brokerSubQueue", brokerSubQueue);
/*      */     }
/*      */     
/*  495 */     this.brokerSubQueue = brokerSubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getBrokerSubQueue()
/*      */   {
/*  502 */     return this.brokerSubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerPubQueue(String brokerPubQueue)
/*      */   {
/*  510 */     if (JCATraceAdapter.isOn) {
/*  511 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerPubQueue", "brokerPubQueue", brokerPubQueue);
/*      */     }
/*      */     
/*  514 */     this.brokerPubQueue = brokerPubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getBrokerPubQueue()
/*      */   {
/*  521 */     return this.brokerPubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerQueueManager(String brokerQueueManager)
/*      */   {
/*  531 */     if (JCATraceAdapter.isOn) {
/*  532 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerQueueManager", "brokerQueueManager", brokerQueueManager);
/*      */     }
/*      */     
/*  535 */     this.brokerQueueManager = brokerQueueManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrokerQueueManager()
/*      */   {
/*  544 */     return this.brokerQueueManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerVersion(String brokerVersion)
/*      */   {
/*  556 */     if (JCATraceAdapter.isOn) {
/*  557 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setBrokerVersion", "brokerVersion", brokerVersion);
/*      */     }
/*      */     
/*  560 */     this.brokerVersion = brokerVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrokerVersion()
/*      */   {
/*  569 */     return this.brokerVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCcdtURL(String ccdtURL)
/*      */   {
/*  580 */     if (JCATraceAdapter.isOn) {
/*  581 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCcdtURL", "ccdtURL", ccdtURL);
/*      */     }
/*      */     
/*  584 */     this.ccdtURL = ccdtURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCcdtURL()
/*      */   {
/*  593 */     return this.ccdtURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCCSID(int ccsid)
/*      */   {
/*  603 */     if (JCATraceAdapter.isOn) {
/*  604 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCCSID(int)", "ccsid", new Integer(ccsid));
/*      */     }
/*      */     
/*  607 */     this.CCSID = ccsid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCCSID(Integer ccsid)
/*      */   {
/*  617 */     if (JCATraceAdapter.isOn) {
/*  618 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCCSID(Integer)", "ccsid", ccsid);
/*      */     }
/*      */     
/*  621 */     setCCSID(ccsid.intValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCCSID(String s)
/*      */   {
/*  631 */     if (JCATraceAdapter.isOn) {
/*  632 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCCSID(String)", "s", s);
/*      */     }
/*      */     try
/*      */     {
/*  636 */       setCCSID(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  640 */       this.inserts.clear();
/*  641 */       this.inserts.put("JCA_CONFIG_PROPERTY", "CCSID");
/*  642 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  643 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.CCSID));
/*      */       
/*  645 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCCSID()
/*      */   {
/*  655 */     return this.CCSID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getReceiveCCSID()
/*      */   {
/*  664 */     return this.receiveCCSID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveCCSID(int receiveCCSID)
/*      */   {
/*  674 */     if (JCATraceAdapter.isOn) {
/*  675 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveCCSID(int)", "receiveCCSID", new Integer(receiveCCSID));
/*      */     }
/*      */     
/*  678 */     this.receiveCCSID = receiveCCSID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveCCSID(Integer receiveCCSID)
/*      */   {
/*  688 */     if (JCATraceAdapter.isOn) {
/*  689 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveCCSID(Integer)", "receiveCCSID", receiveCCSID);
/*      */     }
/*      */     
/*  692 */     this.receiveCCSID = receiveCCSID.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveCCSID(String s)
/*      */   {
/*  702 */     if (JCATraceAdapter.isOn) {
/*  703 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveCCSID(String)", "receiveCCSID", s);
/*      */     }
/*      */     try
/*      */     {
/*  707 */       setReceiveCCSID(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  711 */       this.inserts.clear();
/*  712 */       this.inserts.put("JCA_CONFIG_PROPERTY", "ReceiveCCSID");
/*  713 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  714 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.receiveCCSID));
/*      */       
/*  716 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReceiveConversion()
/*      */   {
/*  727 */     return this.receiveConversion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveConversion(String receiveConversion)
/*      */   {
/*  738 */     if (JCATraceAdapter.isOn) {
/*  739 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveConversion", "receiveConversion", receiveConversion);
/*      */     }
/*      */     
/*  742 */     this.receiveConversion = receiveConversion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChannel(String channel)
/*      */   {
/*  752 */     if (JCATraceAdapter.isOn) {
/*  753 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setChannel", "channel", channel);
/*      */     }
/*      */     
/*  756 */     this.channel = channel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getChannel()
/*      */   {
/*  765 */     return this.channel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCleanupInterval(long cleanupInterval)
/*      */   {
/*  775 */     if (JCATraceAdapter.isOn) {
/*  776 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCleanupInterval(long)", "cleanupInterval", new Long(cleanupInterval));
/*      */     }
/*      */     
/*  779 */     this.cleanupInterval = cleanupInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCleanupInterval(Long cleanupInterval)
/*      */   {
/*  788 */     if (JCATraceAdapter.isOn) {
/*  789 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCleanupInterval(Long)", "cleanupInterval", cleanupInterval);
/*      */     }
/*      */     
/*  792 */     setCleanupInterval(cleanupInterval.longValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCleanupInterval(String s)
/*      */   {
/*  802 */     if (JCATraceAdapter.isOn) {
/*  803 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCleanupInterval(String)", "cleanupInterval", s);
/*      */     }
/*      */     try
/*      */     {
/*  807 */       this.cleanupInterval = Long.parseLong(s);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  811 */       this.inserts.clear();
/*  812 */       this.inserts.put("JCA_CONFIG_PROPERTY", "cleanupInterval");
/*  813 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  814 */       this.inserts.put("JCA_CONFIG_DEFAULT", Long.toString(this.cleanupInterval));
/*      */       
/*  816 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getCleanupInterval()
/*      */   {
/*  826 */     return this.cleanupInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCleanupLevel(String cleanupLevel)
/*      */   {
/*  845 */     if (JCATraceAdapter.isOn) {
/*  846 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCleanupLevel", "cleanupLevel", cleanupLevel);
/*      */     }
/*      */     
/*  849 */     CleanupLevelEnum cleanupLevelValue = CleanupLevelEnum.byTag(cleanupLevel);
/*  850 */     if (cleanupLevelValue != null) {
/*  851 */       this.cleanupLevel = cleanupLevelValue;
/*      */     }
/*      */     else {
/*  854 */       this.badCleanupLevel = cleanupLevel;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CleanupLevelEnum getCleanupLevelEnum()
/*      */   {
/*  864 */     return this.cleanupLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCleanupLevel()
/*      */   {
/*  873 */     return this.cleanupLevel.getTag();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setClientID(String cid)
/*      */   {
/*  885 */     if (JCATraceAdapter.isOn) {
/*  886 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setClientID", "cid", cid);
/*      */     }
/*      */     
/*  889 */     this.clientId = cid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getClientID()
/*      */   {
/*  900 */     return this.clientId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientId(String cid)
/*      */   {
/*  911 */     if (JCATraceAdapter.isOn) {
/*  912 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setClientId", "cid", cid);
/*      */     }
/*      */     
/*  915 */     this.clientId = cid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClientId()
/*      */   {
/*  924 */     return this.clientId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCloneSupport(String cs)
/*      */   {
/*  938 */     if (JCATraceAdapter.isOn) {
/*  939 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setCloneSupport", "cs", cs);
/*      */     }
/*      */     
/*  942 */     this.cloneSupport = cs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCloneSupport()
/*      */   {
/*  951 */     return this.cloneSupport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailIfQuiesce(boolean failIfQuiesce)
/*      */   {
/*  963 */     if (JCATraceAdapter.isOn) {
/*  964 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setFailIfQuiesce(boolean)", "failIfQuiesce", new Boolean(failIfQuiesce));
/*      */     }
/*      */     
/*  967 */     this.failIfQuiesce = failIfQuiesce;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailIfQuiesce(Boolean failIfQuiesce)
/*      */   {
/*  979 */     if (JCATraceAdapter.isOn) {
/*  980 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setFailIfQuiesce(Boolean)", "failIfQuiesce", failIfQuiesce);
/*      */     }
/*      */     
/*  983 */     setFailIfQuiesce(failIfQuiesce.booleanValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailIfQuiesce(String failIfQuiesce)
/*      */   {
/*  994 */     if (JCATraceAdapter.isOn) {
/*  995 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setFailIfQuiesce(String)", "failIfQuiesce", failIfQuiesce);
/*      */     }
/*      */     
/*  998 */     this.failIfQuiesce = (failIfQuiesce != null ? failIfQuiesce.equalsIgnoreCase("true") : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFailIfQuiesce()
/*      */   {
/* 1007 */     return this.failIfQuiesce;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderCompression(String list)
/*      */   {
/* 1017 */     if (JCATraceAdapter.isOn) {
/* 1018 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setHeaderCompression", "headerCompression", list);
/*      */     }
/*      */     
/* 1021 */     this.headerCompression = list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHeaderCompression()
/*      */   {
/* 1030 */     return this.headerCompression;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostName(String hostName)
/*      */   {
/* 1040 */     if (JCATraceAdapter.isOn) {
/* 1041 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setHostName", "hostName", hostName);
/*      */     }
/*      */     
/* 1044 */     this.hostName = hostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHostName()
/*      */   {
/* 1053 */     return this.hostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalAddress(String localAddress)
/*      */   {
/* 1064 */     if (JCATraceAdapter.isOn) {
/* 1065 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setLocalAddress", "localAddress", localAddress);
/*      */     }
/*      */     
/* 1068 */     this.localAddress = localAddress;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalAddress()
/*      */   {
/* 1077 */     return this.localAddress;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageCompression(String list)
/*      */   {
/* 1087 */     if (JCATraceAdapter.isOn) {
/* 1088 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setMessageCompression", "messageCompression", list);
/*      */     }
/*      */     
/* 1091 */     this.messageCompression = list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessageCompression()
/*      */   {
/* 1100 */     return this.messageCompression;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageSelection(String messageSelection)
/*      */   {
/* 1116 */     if (JCATraceAdapter.isOn) {
/* 1117 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setMessageSelection", "messageSelection", messageSelection);
/*      */     }
/*      */     
/* 1120 */     this.messageSelection = messageSelection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessageSelection()
/*      */   {
/* 1129 */     return this.messageSelection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/* 1139 */     if (JCATraceAdapter.isOn) {
/* 1140 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPassword", "password", password);
/*      */     }
/*      */     
/* 1143 */     this.password = password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/* 1152 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPollingInterval(int pi)
/*      */   {
/* 1162 */     if (JCATraceAdapter.isOn) {
/* 1163 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPollingInterval(int)", "interval", new Integer(pi));
/*      */     }
/*      */     
/* 1166 */     this.pollingInterval = pi;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPollingInterval(Integer pi)
/*      */   {
/* 1176 */     if (JCATraceAdapter.isOn) {
/* 1177 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPollingInterval(Integer)", "interval", pi);
/*      */     }
/*      */     
/* 1180 */     setPollingInterval(pi.intValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPollingInterval(String s)
/*      */   {
/* 1191 */     if (JCATraceAdapter.isOn) {
/* 1192 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPollingInterval(String)", "interval", s);
/*      */     }
/*      */     try
/*      */     {
/* 1196 */       setPollingInterval(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1200 */       this.inserts.clear();
/* 1201 */       this.inserts.put("JCA_CONFIG_PROPERTY", "pollingInterval");
/* 1202 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1203 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.pollingInterval));
/*      */       
/* 1205 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPollingInterval()
/*      */   {
/* 1215 */     return this.pollingInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/* 1225 */     if (JCATraceAdapter.isOn) {
/* 1226 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPort(int)", "port", new Integer(port));
/*      */     }
/*      */     
/* 1229 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(Integer port)
/*      */   {
/* 1239 */     if (JCATraceAdapter.isOn) {
/* 1240 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPort(Integer)", "port", port);
/*      */     }
/*      */     
/* 1243 */     this.port = port.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String s)
/*      */   {
/* 1254 */     if (JCATraceAdapter.isOn) {
/* 1255 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setPort(String)", "port", s);
/*      */     }
/*      */     try
/*      */     {
/* 1259 */       setPort(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1263 */       this.inserts.clear();
/* 1264 */       this.inserts.put("JCA_CONFIG_PROPERTY", "port");
/* 1265 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1266 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.port));
/*      */       
/* 1268 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/* 1278 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueueManager(String qm)
/*      */   {
/* 1288 */     if (JCATraceAdapter.isOn) {
/* 1289 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setQueueManager", "qm", qm);
/*      */     }
/*      */     
/* 1292 */     this.queueManager = qm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQueueManager()
/*      */   {
/* 1301 */     return this.queueManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveExit(String receiveExit)
/*      */   {
/* 1313 */     if (JCATraceAdapter.isOn) {
/* 1314 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveExit", "receiveExit", receiveExit);
/*      */     }
/*      */     
/* 1317 */     this.receiveExit = receiveExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReceiveExit()
/*      */   {
/* 1326 */     return this.receiveExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveExitInit(String receiveExitInit)
/*      */   {
/* 1336 */     if (JCATraceAdapter.isOn) {
/* 1337 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReceiveExitInit", "receiveExitInit", receiveExitInit);
/*      */     }
/*      */     
/* 1340 */     this.receiveExitInit = receiveExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReceiveExitInit()
/*      */   {
/* 1349 */     return this.receiveExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRescanInterval(int ri)
/*      */   {
/* 1359 */     if (JCATraceAdapter.isOn) {
/* 1360 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setRescanInterval(int)", "rescanInterval", new Integer(ri));
/*      */     }
/*      */     
/* 1363 */     this.rescanInterval = ri;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRescanInterval(Integer ri)
/*      */   {
/* 1373 */     if (JCATraceAdapter.isOn) {
/* 1374 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setRescanInterval(Integer)", "rescanInterval", ri);
/*      */     }
/*      */     
/* 1377 */     this.rescanInterval = ri.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRescanInterval(String s)
/*      */   {
/* 1388 */     if (JCATraceAdapter.isOn) {
/* 1389 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setRescanInterval(String)", "rescanInterval", s);
/*      */     }
/*      */     try
/*      */     {
/* 1393 */       setRescanInterval(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1397 */       this.inserts.clear();
/* 1398 */       this.inserts.put("JCA_CONFIG_PROPERTY", "rescanInterval");
/* 1399 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1400 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.rescanInterval));
/*      */       
/* 1402 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRescanInterval()
/*      */   {
/* 1412 */     return this.rescanInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecurityExit(String securityExit)
/*      */   {
/* 1425 */     if (JCATraceAdapter.isOn) {
/* 1426 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSecurityExit", "securityExit", securityExit);
/*      */     }
/*      */     
/* 1429 */     this.securityExit = securityExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecurityExit()
/*      */   {
/* 1438 */     return this.securityExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecurityExitInit(String securityExitInit)
/*      */   {
/* 1448 */     if (JCATraceAdapter.isOn) {
/* 1449 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSecurityExitInit", "securityExitInit", securityExitInit);
/*      */     }
/*      */     
/* 1452 */     this.securityExitInit = securityExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecurityExitInit()
/*      */   {
/* 1461 */     return this.securityExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSendExit(String sendExit)
/*      */   {
/* 1474 */     if (JCATraceAdapter.isOn) {
/* 1475 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSendExit", "sendExit", sendExit);
/*      */     }
/*      */     
/* 1478 */     this.sendExit = sendExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSendExit()
/*      */   {
/* 1487 */     return this.sendExit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSendExitInit(String sendExitInit)
/*      */   {
/* 1497 */     if (JCATraceAdapter.isOn) {
/* 1498 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSendExitInit", "sendExitInit", sendExitInit);
/*      */     }
/*      */     
/* 1501 */     this.sendExitInit = sendExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSendExitInit()
/*      */   {
/* 1510 */     return this.sendExitInit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSparseSubscriptions(String sparse)
/*      */   {
/* 1520 */     if (JCATraceAdapter.isOn) {
/* 1521 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSparseSubscriptions", "sparse", sparse);
/*      */     }
/*      */     
/* 1524 */     this.sparseSubscriptions = sparse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSparseSubscriptions()
/*      */   {
/* 1533 */     return this.sparseSubscriptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslCertStores(String sslCertStores)
/*      */   {
/* 1543 */     if (JCATraceAdapter.isOn) {
/* 1544 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslCertStores", "sslCertStores", sslCertStores);
/*      */     }
/*      */     
/* 1547 */     this.sslCertStores = sslCertStores;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSslCertStores()
/*      */   {
/* 1556 */     return this.sslCertStores;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslCipherSuite(String sslCipherSuite)
/*      */   {
/* 1567 */     if (JCATraceAdapter.isOn) {
/* 1568 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslCipherSuite", "sslCipherSuite", sslCipherSuite);
/*      */     }
/*      */     
/* 1571 */     this.sslCipherSuite = sslCipherSuite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSslCipherSuite()
/*      */   {
/* 1580 */     return this.sslCipherSuite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslFipsRequired(boolean sslFipsRequired)
/*      */   {
/* 1590 */     if (JCATraceAdapter.isOn) {
/* 1591 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslFipsRequired(boolean)", "sslFipsRequired", new Boolean(sslFipsRequired));
/*      */     }
/*      */     
/* 1594 */     this.sslFipsRequired = sslFipsRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslFipsRequired(String sslFipsRequired)
/*      */   {
/* 1604 */     if (JCATraceAdapter.isOn) {
/* 1605 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslFipsRequired(String)", "sslFipsRequired", sslFipsRequired);
/*      */     }
/*      */     
/* 1608 */     this.sslFipsRequired = Boolean.getBoolean(sslFipsRequired);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSslFipsRequired()
/*      */   {
/* 1617 */     return this.sslFipsRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslPeerName(String sslPeerName)
/*      */   {
/* 1627 */     if (JCATraceAdapter.isOn) {
/* 1628 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslPeerName", "sslPeerName", sslPeerName);
/*      */     }
/*      */     
/* 1631 */     this.sslPeerName = sslPeerName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSslPeerName()
/*      */   {
/* 1640 */     return this.sslPeerName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslResetCount(int sslResetCount)
/*      */   {
/* 1651 */     if (JCATraceAdapter.isOn) {
/* 1652 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslResetCount(int)", "sslResetCount", new Integer(sslResetCount));
/*      */     }
/*      */     
/* 1655 */     this.sslResetCount = sslResetCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslResetCount(Integer sslResetCount)
/*      */   {
/* 1666 */     if (JCATraceAdapter.isOn) {
/* 1667 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslResetCount(Integer)", "sslResetCount", sslResetCount);
/*      */     }
/*      */     
/* 1670 */     this.sslResetCount = sslResetCount.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslResetCount(String s)
/*      */   {
/* 1681 */     if (JCATraceAdapter.isOn) {
/* 1682 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslResetCount(String)", "sslResetCount", s);
/*      */     }
/*      */     try
/*      */     {
/* 1686 */       this.sslResetCount = Integer.parseInt(s);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1690 */       this.inserts.clear();
/* 1691 */       this.inserts.put("JCA_CONFIG_PROPERTY", "sslResetCount");
/* 1692 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1693 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.sslResetCount));
/*      */       
/* 1695 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSslResetCount()
/*      */   {
/* 1705 */     return this.sslResetCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatusRefreshInterval(int ival)
/*      */   {
/* 1715 */     if (JCATraceAdapter.isOn) {
/* 1716 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setStatusRefreshInterval(int)", "statusRefreshInterval", new Integer(ival));
/*      */     }
/*      */     
/* 1719 */     this.statusRefreshInterval = ival;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatusRefreshInterval(Integer ival)
/*      */   {
/* 1729 */     if (JCATraceAdapter.isOn) {
/* 1730 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setStatusRefreshInterval(Integer)", "statusRefreshInterval", ival);
/*      */     }
/*      */     
/* 1733 */     this.statusRefreshInterval = ival.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatusRefreshInterval(String s)
/*      */   {
/* 1744 */     if (JCATraceAdapter.isOn) {
/* 1745 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setStatusRefreshInterval(String)", "statusRefreshInterval", s);
/*      */     }
/*      */     try
/*      */     {
/* 1749 */       setStatusRefreshInterval(Integer.parseInt(s));
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1753 */       this.inserts.clear();
/* 1754 */       this.inserts.put("JCA_CONFIG_PROPERTY", "statusRefreshInterval");
/* 1755 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1756 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.statusRefreshInterval));
/*      */       
/* 1758 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStatusRefreshInterval()
/*      */   {
/* 1768 */     return this.statusRefreshInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubscriptionStore(String subscriptionStore)
/*      */   {
/* 1780 */     if (JCATraceAdapter.isOn) {
/* 1781 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSubscriptionStore", "subscriptionStore", subscriptionStore);
/*      */     }
/*      */     
/* 1784 */     SubscriptionStoreEnum subscriptionStoreValue = SubscriptionStoreEnum.byTag(subscriptionStore);
/* 1785 */     if (subscriptionStoreValue != null) {
/* 1786 */       this.subscriptionStore = subscriptionStoreValue;
/*      */     }
/*      */     else {
/* 1789 */       this.badSubscriptionStore = subscriptionStore;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SubscriptionStoreEnum getSubscriptionStoreEnum()
/*      */   {
/* 1799 */     return this.subscriptionStore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSubscriptionStore()
/*      */   {
/* 1808 */     return this.subscriptionStore.getTag();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransportType(String transport)
/*      */   {
/* 1818 */     if (JCATraceAdapter.isOn) {
/* 1819 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setTransportType", "transport", transport);
/*      */     }
/*      */     
/* 1822 */     TransportTypeEnum transportTypeValue = TransportTypeEnum.byTag(transport);
/* 1823 */     if (transportTypeValue != null) {
/* 1824 */       this.transportType = transportTypeValue;
/*      */     }
/*      */     else {
/* 1827 */       this.badTransportType = transport;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TransportTypeEnum getTransportTypeEnum()
/*      */   {
/* 1837 */     return this.transportType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTransportType()
/*      */   {
/* 1846 */     return this.transportType.getTag();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setUsername(String username)
/*      */   {
/* 1859 */     if (JCATraceAdapter.isOn) {
/* 1860 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setUsername", "username", username);
/*      */     }
/*      */     
/* 1863 */     this.username = username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getUsername()
/*      */   {
/* 1875 */     return this.username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserName(String username)
/*      */   {
/* 1885 */     if (JCATraceAdapter.isOn) {
/* 1886 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setUserName", "username", username);
/*      */     }
/*      */     
/* 1889 */     this.username = username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */   {
/* 1898 */     return this.username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArbitraryProperties(String properties)
/*      */   {
/* 1917 */     if (JCATraceAdapter.isOn) {
/* 1918 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setArbitraryProperties", "properties", properties);
/*      */     }
/*      */     
/* 1921 */     this.arbitraryProperties = properties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getArbitraryProperties()
/*      */   {
/* 1930 */     return this.arbitraryProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionNameList(String list)
/*      */   {
/* 1939 */     this.connectionNameList = list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionNameList()
/*      */   {
/* 1946 */     return this.connectionNameList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProviderVersion(String providerVersion)
/*      */   {
/* 1958 */     if (JCATraceAdapter.isOn) {
/* 1959 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setProviderVersion", "providerVersion", providerVersion);
/*      */     }
/*      */     
/* 1962 */     this.providerVersion = providerVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProviderVersion()
/*      */   {
/* 1971 */     return this.providerVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadAheadAllowed(String readAheadAllowed)
/*      */   {
/* 1981 */     if (JCATraceAdapter.isOn) {
/* 1982 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setReadAheadAllowed", "readAheadAllowed", readAheadAllowed);
/*      */     }
/*      */     
/* 1985 */     ReadAheadAllowedEnum readAheadAllowedValue = ReadAheadAllowedEnum.byTag(readAheadAllowed);
/* 1986 */     if (readAheadAllowedValue != null) {
/* 1987 */       this.readAheadAllowed = readAheadAllowedValue;
/*      */     }
/*      */     else {
/* 1990 */       this.badReadAheadAllowed = readAheadAllowed;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReadAheadAllowedEnum getReadAheadAllowedEnum()
/*      */   {
/* 2000 */     return this.readAheadAllowed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReadAheadAllowed()
/*      */   {
/* 2009 */     return this.readAheadAllowed.getTag();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShareConvAllowed(String shareConvAllowed)
/*      */   {
/* 2019 */     if (JCATraceAdapter.isOn) {
/* 2020 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setShareConvAllowed", "shareConvAllowed", shareConvAllowed);
/*      */     }
/*      */     
/*      */ 
/* 2024 */     this.shareConvAllowedExt = shareConvAllowed;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2029 */     if (shareConvAllowed.equalsIgnoreCase("TRUE")) {
/* 2030 */       this.shareConvAllowed = "YES";
/*      */     }
/* 2032 */     else if (shareConvAllowed.equalsIgnoreCase("FALSE")) {
/* 2033 */       this.shareConvAllowed = "NO";
/*      */     }
/*      */     else {
/* 2036 */       this.shareConvAllowed = shareConvAllowed;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getShareConvAllowed()
/*      */   {
/* 2046 */     return this.shareConvAllowedExt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getShareConvAllowedCanonical()
/*      */   {
/* 2057 */     return this.shareConvAllowed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslSocketFactory(String fac)
/*      */   {
/* 2070 */     if (JCATraceAdapter.isOn) {
/* 2071 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setSslSocketFactory(String)", "sslSocketFactory", fac);
/*      */     }
/*      */     
/* 2074 */     this.sslSocketFactory = fac;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSslSocketFactory()
/*      */   {
/* 2083 */     return this.sslSocketFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWildcardFormat(String wildcardFormat)
/*      */   {
/* 2093 */     if (JCATraceAdapter.isOn) {
/* 2094 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setWildcardFormat", "wildcardFormat", wildcardFormat);
/*      */     }
/*      */     
/* 2097 */     this.wildcardFormat = wildcardFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWildcardFormat()
/*      */   {
/* 2106 */     return this.wildcardFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validate()
/*      */     throws InvalidPropertyException
/*      */   {
/* 2120 */     if (!isValidString(this.brokerVersion, brokerVersionValues))
/*      */     {
/* 2122 */       this.inserts.clear();
/* 2123 */       this.inserts.put("JCA_CONFIG_PROPERTY", "brokerVersion");
/* 2124 */       this.inserts.put("JCA_CONFIG_VALUE", this.brokerVersion);
/*      */       
/* 2126 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2130 */     if (this.CCSID <= 0)
/*      */     {
/* 2132 */       this.inserts.clear();
/* 2133 */       this.inserts.put("JCA_CONFIG_PROPERTY", "CCSID");
/* 2134 */       this.inserts.put("JCA_CONFIG_VALUE", Integer.valueOf(this.CCSID));
/*      */       
/* 2136 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2140 */     if (this.receiveCCSID < 0)
/*      */     {
/* 2142 */       this.inserts.clear();
/* 2143 */       this.inserts.put("JCA_CONFIG_PROPERTY", "receiveCCSID");
/* 2144 */       this.inserts.put("JCA_CONFIG_VALUE", Integer.valueOf(this.receiveCCSID));
/*      */       
/* 2146 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2150 */     if ((!this.receiveConversion.equalsIgnoreCase("CLIENT_MSG")) && (!this.receiveConversion.equalsIgnoreCase("QMGR")))
/*      */     {
/* 2152 */       this.inserts.clear();
/* 2153 */       this.inserts.put("JCA_CONFIG_PROPERTY", "receiveConversion");
/* 2154 */       this.inserts.put("JCA_CONFIG_VALUE", this.receiveConversion);
/*      */       
/* 2156 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2160 */     if (this.cleanupInterval <= 0L)
/*      */     {
/* 2162 */       this.inserts.clear();
/* 2163 */       this.inserts.put("JCA_CONFIG_PROPERTY", "cleanupInterval");
/* 2164 */       this.inserts.put("JCA_CONFIG_VALUE", Long.valueOf(this.cleanupInterval));
/*      */       
/* 2166 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2170 */     if (this.badCleanupLevel != null)
/*      */     {
/* 2172 */       this.inserts.clear();
/* 2173 */       this.inserts.put("JCA_CONFIG_PROPERTY", "cleanupLevel");
/* 2174 */       this.inserts.put("JCA_CONFIG_VALUE", this.cleanupLevel);
/*      */       
/* 2176 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2180 */     if (!isValidString(this.cloneSupport, cloneSupportValues))
/*      */     {
/* 2182 */       this.inserts.clear();
/* 2183 */       this.inserts.put("JCA_CONFIG_PROPERTY", "cloneSupport");
/* 2184 */       this.inserts.put("JCA_CONFIG_VALUE", this.cloneSupport);
/*      */       
/* 2186 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2190 */     if (!isValidString(this.headerCompression, hdrCompressionValues))
/*      */     {
/* 2192 */       this.inserts.clear();
/* 2193 */       this.inserts.put("JCA_CONFIG_PROPERTY", "headerCompression");
/* 2194 */       this.inserts.put("JCA_CONFIG_VALUE", this.headerCompression);
/*      */       
/* 2196 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2200 */     if (!"NONE".equals(this.messageCompression))
/*      */     {
/* 2202 */       String[] result = null;
/* 2203 */       if (this.messageCompression != null)
/*      */       {
/* 2205 */         result = this.messageCompression.split("\\s");
/*      */       }
/*      */       else
/*      */       {
/* 2209 */         this.inserts.clear();
/* 2210 */         this.inserts.put("JCA_CONFIG_PROPERTY", "messageCompression");
/* 2211 */         this.inserts.put("JCA_CONFIG_VALUE", "null");
/*      */         
/* 2213 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/* 2217 */       for (int i = 0; i < result.length; i++) {
/* 2218 */         if (!isValidString(result[i], msgCompressionValues))
/*      */         {
/* 2220 */           this.inserts.clear();
/* 2221 */           this.inserts.put("JCA_CONFIG_PROPERTY", "messageCompression");
/* 2222 */           this.inserts.put("JCA_CONFIG_VALUE", this.messageCompression);
/*      */           
/* 2224 */           throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2231 */     if (!isValidString(this.messageSelection, messageSelectionValues))
/*      */     {
/* 2233 */       this.inserts.clear();
/* 2234 */       this.inserts.put("JCA_CONFIG_PROPERTY", "messageSelection");
/* 2235 */       this.inserts.put("JCA_CONFIG_VALUE", this.messageSelection);
/*      */       
/* 2237 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2241 */     if (this.pollingInterval <= 0)
/*      */     {
/* 2243 */       this.inserts.clear();
/* 2244 */       this.inserts.put("JCA_CONFIG_PROPERTY", "pollingInterval");
/* 2245 */       this.inserts.put("JCA_CONFIG_VALUE", Integer.valueOf(this.pollingInterval));
/*      */       
/* 2247 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2251 */     if (this.rescanInterval <= 0)
/*      */     {
/* 2253 */       this.inserts.clear();
/* 2254 */       this.inserts.put("JCA_CONFIG_PROPERTY", "rescanInterval");
/* 2255 */       this.inserts.put("JCA_CONFIG_VALUE", Integer.valueOf(this.rescanInterval));
/*      */       
/* 2257 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2261 */     if (!isValidString(this.sparseSubscriptions, sparseValues))
/*      */     {
/* 2263 */       this.inserts.clear();
/* 2264 */       this.inserts.put("JCA_CONFIG_PROPERTY", "sparseSubscriptions");
/* 2265 */       this.inserts.put("JCA_CONFIG_VALUE", this.sparseSubscriptions);
/*      */       
/* 2267 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2271 */     if (this.statusRefreshInterval <= 0)
/*      */     {
/* 2273 */       this.inserts.clear();
/* 2274 */       this.inserts.put("JCA_CONFIG_PROPERTY", "statusRefreshInterval");
/* 2275 */       this.inserts.put("JCA_CONFIG_VALUE", Integer.valueOf(this.statusRefreshInterval));
/*      */       
/* 2277 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2281 */     if (this.badSubscriptionStore != null)
/*      */     {
/* 2283 */       this.inserts.clear();
/* 2284 */       this.inserts.put("JCA_CONFIG_PROPERTY", "subscriptionStore");
/* 2285 */       this.inserts.put("JCA_CONFIG_VALUE", this.badSubscriptionStore);
/*      */       
/* 2287 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2291 */     if (this.badTransportType != null)
/*      */     {
/* 2293 */       this.inserts.clear();
/* 2294 */       this.inserts.put("JCA_CONFIG_PROPERTY", "transportType");
/* 2295 */       this.inserts.put("JCA_CONFIG_VALUE", this.transportType);
/*      */       
/* 2297 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/* 2300 */     this.transportType.validate(this);
/*      */     
/*      */ 
/* 2303 */     boolean isV7 = false;
/* 2304 */     if (this.providerVersion != null)
/*      */     {
/*      */ 
/* 2307 */       if (this.providerVersion.equalsIgnoreCase("UNSPECIFIED")) {
/* 2308 */         JCATraceAdapter.traceInfo(this, "AbstractConfiguration", "validate()", "provider version unspecified");
/*      */         
/* 2310 */         isV7 = true;
/*      */       }
/* 2312 */       else if (this.providerVersion.startsWith("6")) {
/* 2313 */         JCATraceAdapter.traceInfo(this, "AbstractConfiguration", "validate()", "provider version six");
/*      */       }
/* 2315 */       else if (this.providerVersion.startsWith("7")) {
/* 2316 */         JCATraceAdapter.traceInfo(this, "AbstractConfiguration", "validate()", "provider version seven");
/* 2317 */         isV7 = true;
/*      */       }
/*      */       else
/*      */       {
/* 2321 */         this.inserts.clear();
/* 2322 */         this.inserts.put("JCA_CONFIG_PROPERTY", "providerVersion");
/* 2323 */         this.inserts.put("JCA_CONFIG_VALUE", this.providerVersion);
/*      */         
/* 2325 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 2331 */       this.inserts.clear();
/* 2332 */       this.inserts.put("JCA_CONFIG_PROPERTY", "providerVersion");
/* 2333 */       this.inserts.put("JCA_CONFIG_VALUE", "null");
/*      */       
/* 2335 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/* 2338 */     if (isV7)
/*      */     {
/* 2340 */       if (this.badReadAheadAllowed != null)
/*      */       {
/* 2342 */         this.inserts.clear();
/* 2343 */         this.inserts.put("JCA_CONFIG_PROPERTY", "readAheadAllowed");
/* 2344 */         this.inserts.put("JCA_CONFIG_VALUE", this.badReadAheadAllowed);
/*      */         
/* 2346 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2351 */       if (!isValidString(this.shareConvAllowed, shareConvAllowedValues))
/*      */       {
/* 2353 */         this.inserts.clear();
/* 2354 */         this.inserts.put("JCA_CONFIG_PROPERTY", "shareConvAllowed");
/* 2355 */         this.inserts.put("JCA_CONFIG_VALUE", this.shareConvAllowed);
/*      */         
/* 2357 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/* 2361 */       if (!isValidString(this.wildcardFormat, wildcardFormatAllowedValues))
/*      */       {
/* 2363 */         this.inserts.clear();
/* 2364 */         this.inserts.put("JCA_CONFIG_PROPERTY", "wildcardFormat");
/* 2365 */         this.inserts.put("JCA_CONFIG_VALUE", this.wildcardFormat);
/*      */         
/* 2367 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2373 */     if (this.connectionNameList == null)
/*      */     {
/* 2375 */       this.inserts.clear();
/* 2376 */       this.inserts.put("JCA_CONFIG_PROPERTY", "connectionNameList");
/* 2377 */       this.inserts.put("JCA_CONFIG_VALUE", this.connectionNameList);
/*      */       
/* 2379 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */     
/*      */ 
/* 2383 */     validateSslSocketFactory();
/*      */     
/*      */ 
/* 2386 */     validateArbitraryProperties();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isValidString(String s, String[] values)
/*      */   {
/* 2398 */     boolean result = false;
/*      */     
/* 2400 */     if ((s != null) && (values != null) && (values.length > 0)) {
/* 2401 */       int count = 0;
/* 2402 */       while ((!result) && (count < values.length))
/*      */       {
/* 2404 */         result = s.equalsIgnoreCase(values[count]);
/*      */         
/* 2406 */         count++;
/*      */       }
/*      */     }
/*      */     
/* 2410 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void validateArbitraryProperties()
/*      */     throws InvalidPropertyException
/*      */   {
/* 2421 */     if ((this.arbitraryProperties != null) && (this.arbitraryProperties.trim().length() != 0))
/*      */     {
/*      */       try
/*      */       {
/* 2425 */         CustomPropertyHandler.parseCustomProperties(this.arbitraryProperties);
/*      */       }
/*      */       catch (ParseException pe) {
/* 2428 */         JCATraceAdapter.traceInfo(this, "AbstractConfiguration", "validateArbitraryProperties()", "arbitrary property validation failed with exception: " + pe);
/*      */         
/* 2430 */         this.inserts.clear();
/* 2431 */         this.inserts.put("JCA_CONFIG_PROPERTY", "arbitraryProperties");
/* 2432 */         this.inserts.put("JCA_CONFIG_VALUE", this.arbitraryProperties);
/*      */         
/* 2434 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void validateSslSocketFactory()
/*      */     throws InvalidPropertyException
/*      */   {
/* 2448 */     if ((this.sslSocketFactory != null) && (this.sslSocketFactory.trim().length() != 0)) {
/* 2449 */       validateSslSocketFactory(this.sslSocketFactory);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void validateSslSocketFactory(String socketFactory)
/*      */     throws InvalidPropertyException
/*      */   {
/*      */     try
/*      */     {
/* 2461 */       SSLSocketFactoryHandler.parseSSLSocketFactory(socketFactory);
/*      */     }
/*      */     catch (SocketFactoryParseException sfpe) {
/* 2464 */       JCATraceAdapter.traceInfo(this, "AbstractConfiguration", "validateSslSocketFactory()", "sslSocketFactory validation failed with exception: " + sfpe);
/*      */       
/* 2466 */       this.inserts.clear();
/* 2467 */       this.inserts.put("JCA_CONFIG_PROPERTY", "sslSocketFactory");
/* 2468 */       this.inserts.put("JCA_CONFIG_VALUE", socketFactory);
/*      */       
/* 2470 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean compareQueueManagers(AbstractConfiguration b)
/*      */   {
/* 2487 */     boolean theSame = true;
/* 2488 */     if (b == null)
/*      */     {
/* 2490 */       theSame = false;
/*      */ 
/*      */     }
/* 2493 */     else if ((checkEquals(this.brokerCCSubQueue, b.getBrokerCCSubQueue())) && (checkEquals(this.brokerControlQueue, b.getBrokerControlQueue())) && (checkEquals(this.brokerPubQueue, b.getBrokerPubQueue())) && (checkEquals(this.brokerQueueManager, b.getBrokerQueueManager())) && (checkEquals(this.brokerVersion, b.getBrokerVersion())) && (checkEquals(this.ccdtURL, b.getCcdtURL())) && (checkEquals(this.channel, b.getChannel())) && (this.cleanupInterval == b.getCleanupInterval()) && (this.cleanupLevel == b.getCleanupLevelEnum()) && (checkEquals(this.clientId, b.getClientId())) && (checkEquals(this.cloneSupport, b.getCloneSupport())) && (this.failIfQuiesce == b.getFailIfQuiesce()) && (checkEquals(this.headerCompression, b.getHeaderCompression())) && (checkEquals(this.hostName, b.getHostName())) && (checkEquals(this.localAddress, b.getLocalAddress())) && (checkEquals(this.messageCompression, b.getMessageCompression())) && (checkEquals(this.messageSelection, b.getMessageSelection())) && (checkEquals(this.password, b.getPassword())) && (this.pollingInterval == b.getPollingInterval()) && (this.port == b.getPort()) && (checkEquals(this.providerVersion, b.getProviderVersion())) && (checkEquals(this.queueManager, b.getQueueManager())) && (this.readAheadAllowed == b.getReadAheadAllowedEnum()) && (checkEquals(this.receiveExit, b.getReceiveExit())) && (checkEquals(this.receiveExitInit, b.getReceiveExitInit())) && (this.rescanInterval == b.getRescanInterval()) && (checkEquals(this.securityExit, b.getSecurityExit())) && (checkEquals(this.securityExitInit, b.getSecurityExitInit())) && (checkEquals(this.sendExit, b.getSendExit())) && (checkEquals(this.sendExitInit, b.getSendExitInit())) && (checkEquals(this.shareConvAllowed, b.getShareConvAllowedCanonical())) && (checkEquals(this.sparseSubscriptions, b.getSparseSubscriptions())) && (checkEquals(this.sslCertStores, b.getSslCertStores())) && (checkEquals(this.sslCipherSuite, b.getSslCipherSuite())) && (this.sslFipsRequired == b.getSslFipsRequired()) && (checkEquals(this.sslPeerName, b.getSslPeerName())) && (this.sslResetCount == b.getSslResetCount()) && (this.statusRefreshInterval == b.getStatusRefreshInterval()) && (this.subscriptionStore == b.getSubscriptionStoreEnum()) && (this.transportType == b.transportType) && (checkEquals(this.username, b.getUsername())) && (checkEquals(this.wildcardFormat, b.getWildcardFormat())) && (checkEquals(this.connectionNameList, b.getConnectionNameList())))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2538 */       theSame = true;
/*      */     }
/*      */     else
/*      */     {
/* 2542 */       theSame = false;
/*      */     }
/*      */     
/*      */ 
/* 2546 */     return theSame;
/*      */   }
/*      */   
/*      */   private static boolean checkEquals(String s1, String s2)
/*      */   {
/* 2551 */     if (s1 == s2) {
/* 2552 */       return true;
/*      */     }
/* 2554 */     if ((s1 == null) || (s2 == null)) {
/* 2555 */       return false;
/*      */     }
/* 2557 */     return s1.equalsIgnoreCase(s2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean equals(Object o)
/*      */   {
/* 2572 */     return super.equals(o);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int hashCode()
/*      */   {
/* 2586 */     return super.hashCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQmid(String qmid)
/*      */   {
/* 2600 */     if (JCATraceAdapter.isOn) {
/* 2601 */       JCATraceAdapter.traceData(this, "AbstractConfiguration", "setQmid", "qmid", qmid);
/*      */     }
/*      */     
/* 2604 */     this.qmid = qmid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQmid()
/*      */   {
/* 2612 */     return this.qmid;
/*      */   }
/*      */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/AbstractConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */