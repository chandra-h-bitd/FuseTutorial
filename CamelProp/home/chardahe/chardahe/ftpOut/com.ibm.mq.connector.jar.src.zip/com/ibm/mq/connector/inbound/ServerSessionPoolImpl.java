/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ServerSession;
/*     */ import javax.jms.ServerSessionPool;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.XAConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSessionPoolImpl
/*     */   implements ServerSessionPool
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ServerSessionPoolImpl.java";
/*  87 */   private MessageEndpointDeployment theMessageEndpointDeployment = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private Connection theConnection = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private boolean isTransacted = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private int currentPoolDepth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private int maxPoolDepth = 10;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 113 */   private Map<Session, ServerSessionImpl> serverSessions = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 118 */   private List<ServerSessionImpl> thePool = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   private int serverSessionsInUse = 0;
/*     */   
/*     */ 
/* 128 */   private static PoolScavengerThread scavengerThread = null;
/*     */   
/*     */ 
/* 131 */   public static final Object lock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 136 */   private int idleTime = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 141 */   private volatile boolean isClosing = false;
/*     */   
/*     */ 
/*     */ 
/* 145 */   final String lineSeparator = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */   {
/*     */     public String run() {
/* 148 */       return System.getProperty("line.separator");
/*     */     }
/* 145 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class CloseState
/*     */   {
/*     */     private CloseState() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 158 */     boolean inProgress = false;
/*     */     
/*     */      }
/* 161 */   private CloseState closeState = new CloseState(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerSessionPoolImpl(MessageEndpointDeployment med, Connection conn, int maxDepth)
/*     */   {
/* 173 */     if (JCATraceAdapter.isOn) {
/* 174 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "<init>");
/*     */     }
/*     */     
/*     */ 
/* 178 */     this.theMessageEndpointDeployment = med;
/* 179 */     this.theConnection = conn;
/* 180 */     this.maxPoolDepth = maxDepth;
/* 181 */     if (JCATraceAdapter.isOn) {
/* 182 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "<init>", "max pool depth: " + maxDepth);
/*     */     }
/*     */     
/* 185 */     this.serverSessions = new HashMap(maxDepth);
/*     */     
/* 187 */     this.isTransacted = (conn instanceof XAConnection);
/*     */     
/* 189 */     this.thePool = new ArrayList(this.maxPoolDepth);
/*     */     
/*     */ 
/* 192 */     synchronized (lock) {
/* 193 */       if (scavengerThread == null) {
/* 194 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "<init>", "creating scavenger thread");
/* 195 */         scavengerThread = new PoolScavengerThread();
/*     */         
/* 197 */         scavengerThread.setPriority(1);
/* 198 */         scavengerThread.setDaemon(true);
/*     */         
/* 200 */         scavengerThread.start();
/* 201 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "<init>", "scavenger thread started");
/*     */       }
/*     */       
/* 204 */       scavengerThread.addServerSessionPool(this);
/*     */     }
/*     */     
/*     */ 
/* 208 */     if (JCATraceAdapter.isOn) {
/* 209 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIdleTimeout()
/*     */   {
/* 219 */     return this.idleTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdleTimeout(int idle)
/*     */   {
/* 230 */     synchronized (this.thePool) {
/* 231 */       if (idle < 0)
/*     */       {
/* 233 */         this.idleTime = 0;
/*     */       }
/*     */       else
/*     */       {
/* 237 */         this.idleTime = idle;
/*     */         
/* 239 */         poolCleanup();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int waitForNoSessionsInUse(long timeout)
/*     */   {
/* 253 */     if (JCATraceAdapter.isOn) {
/* 254 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)");
/* 255 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)", "timeout: " + timeout);
/*     */     }
/*     */     
/* 258 */     int sessionsRemaining = 0;
/* 259 */     long timeLeft = timeout;
/*     */     
/*     */ 
/* 262 */     long timeLoopStart = 0L;
/* 263 */     long timeLastLoopStart = 0L;
/* 264 */     long timeLastLoopDuration = 0L;
/*     */     
/* 266 */     synchronized (this.thePool)
/*     */     {
/* 268 */       while (this.serverSessionsInUse > 0)
/*     */       {
/*     */ 
/*     */ 
/* 272 */         timeLoopStart = System.currentTimeMillis();
/* 273 */         timeLastLoopDuration = timeLastLoopStart == 0L ? 0L : timeLoopStart - timeLastLoopStart + 1L;
/* 274 */         timeLastLoopStart = timeLoopStart;
/*     */         
/*     */ 
/* 277 */         timeLeft -= timeLastLoopDuration;
/* 278 */         if (timeLeft < 1L) {
/* 279 */           if (!JCATraceAdapter.isOn) break;
/* 280 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)", "waiting for no ServerSessions to be in use: Timeout expired: " + timeout);
/* 281 */           break;
/*     */         }
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 287 */           if (JCATraceAdapter.isOn) {
/* 288 */             JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)", "waiting for no ServerSessions to be in use: timeLeft: " + timeLeft);
/*     */           }
/* 290 */           this.thePool.wait(timeLeft);
/*     */         }
/*     */         catch (InterruptedException ie) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 298 */       sessionsRemaining = this.serverSessionsInUse;
/*     */     }
/*     */     
/*     */ 
/* 302 */     if (JCATraceAdapter.isOn) {
/* 303 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)", "Sessions remaining in use: " + sessionsRemaining);
/* 304 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "waitForNoSessionsInUse(int)");
/*     */     }
/*     */     
/* 307 */     return sessionsRemaining;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int getCurrentPoolDepth()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	com/ibm/mq/connector/inbound/ServerSessionPoolImpl:thePool	Ljava/util/List;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 5	com/ibm/mq/connector/inbound/ServerSessionPoolImpl:currentPoolDepth	I
/*     */     //   11: aload_1
/*     */     //   12: monitorexit
/*     */     //   13: ireturn
/*     */     //   14: astore_2
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: aload_2
/*     */     //   18: athrow
/*     */     // Line number table:
/*     */     //   Java source line #317	-> byte code offset #0
/*     */     //   Java source line #318	-> byte code offset #7
/*     */     //   Java source line #319	-> byte code offset #14
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	19	0	this	ServerSessionPoolImpl
/*     */     //   5	11	1	Ljava/lang/Object;	Object
/*     */     //   14	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	13	14	finally
/*     */     //   14	17	14	finally
/*     */   }
/*     */   
/*     */   public ServerSession getServerSession()
/*     */     throws JMSException
/*     */   {
/* 333 */     if (JCATraceAdapter.isOn) {
/* 334 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "getServerSession()");
/*     */     }
/*     */     
/*     */ 
/* 338 */     ServerSessionImpl aServerSession = null;
/*     */     
/*     */ 
/* 341 */     synchronized (this.thePool) {
/* 342 */       if (this.isClosing)
/*     */       {
/* 344 */         if (JCATraceAdapter.isOn) {
/* 345 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "Exiting early as ServerSessionPool is closing");
/* 346 */           JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "getServerSession()");
/*     */         }
/* 348 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 356 */       if (JCATraceAdapter.isOn) {
/* 357 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "serverSessionsInUse: " + this.serverSessionsInUse + ", currentPoolDepth: " + this.currentPoolDepth + ", maxPoolDepth: " + this.maxPoolDepth);
/*     */         
/* 359 */         tracePoolContents();
/*     */       }
/* 361 */       if ((this.serverSessionsInUse != this.currentPoolDepth) || (this.currentPoolDepth == this.maxPoolDepth))
/*     */       {
/*     */ 
/* 364 */         while ((this.serverSessionsInUse == this.currentPoolDepth) && (!this.isClosing)) {
/*     */           try {
/* 366 */             if (JCATraceAdapter.isOn) {
/* 367 */               JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "waiting for a ServerSession to become available");
/*     */             }
/* 369 */             this.thePool.wait();
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 376 */         if (this.isClosing)
/*     */         {
/* 378 */           if (JCATraceAdapter.isOn) {
/* 379 */             JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "Exiting early as ServerSessionPool is closing");
/* 380 */             JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "getServerSession()");
/*     */           }
/* 382 */           return null;
/*     */         }
/*     */         
/*     */ 
/* 386 */         this.serverSessionsInUse += 1;
/*     */         
/* 388 */         for (ServerSessionImpl s : this.thePool)
/*     */         {
/* 390 */           if (!s.isInUse())
/*     */           {
/* 392 */             s.markInUse();
/*     */             
/* 394 */             aServerSession = s;
/*     */             
/* 396 */             break;
/*     */           }
/*     */         }
/* 399 */         if (JCATraceAdapter.isOn) {
/* 400 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "found ServerSession: " + aServerSession);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 406 */         if (JCATraceAdapter.isOn) {
/* 407 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "creating new ServerSession");
/*     */         }
/* 409 */         Session s = createJMSSession();
/* 410 */         aServerSession = new ServerSessionImpl(this, this.theMessageEndpointDeployment, s);
/*     */         
/* 412 */         this.serverSessions.put(s, aServerSession);
/*     */         
/* 414 */         aServerSession.markInUse();
/*     */         
/* 416 */         this.thePool.add(aServerSession);
/*     */         
/* 418 */         this.currentPoolDepth += 1;
/*     */         
/* 420 */         this.serverSessionsInUse += 1;
/* 421 */         if (JCATraceAdapter.isOn) {
/* 422 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "created ServerSession, pool depth now: " + this.currentPoolDepth);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 429 */       Session s = aServerSession.getSession();
/* 430 */       if (JCATraceAdapter.isOn) {
/* 431 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "getServerSession()", "setting listener on: " + s);
/*     */       }
/* 433 */       s.setMessageListener(new MessageEndpointWrapper());
/*     */     }
/*     */     
/*     */ 
/* 437 */     if (JCATraceAdapter.isOn) {
/* 438 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "getServerSession()");
/*     */     }
/*     */     
/*     */ 
/* 442 */     return aServerSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sessionReleased(Session s)
/*     */   {
/* 452 */     sessionReleased(s, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sessionReleased(Session s, boolean renew)
/*     */   {
/* 465 */     if (JCATraceAdapter.isOn) {
/* 466 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "sessionReleased(...)");
/* 467 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "releasing Session: " + s + " renew:" + renew);
/*     */     }
/*     */     
/* 470 */     synchronized (this.thePool)
/*     */     {
/* 472 */       ServerSessionImpl ss = (ServerSessionImpl)this.serverSessions.get(s);
/*     */       
/*     */ 
/* 475 */       if (ss != null)
/*     */       {
/* 477 */         ss.release();
/*     */         
/* 479 */         this.serverSessionsInUse -= 1;
/*     */       }
/* 481 */       if (JCATraceAdapter.isOn) {
/* 482 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "released ServerSession: " + ss + ", sessionsInUse now: " + this.serverSessionsInUse);
/* 483 */         tracePoolContents();
/*     */       }
/*     */       
/* 486 */       if (renew) {
/* 487 */         if (JCATraceAdapter.isOn) {
/* 488 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "Renewing connection");
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 493 */           Session newS = createJMSSession();
/* 494 */           ServerSessionImpl newServerSession = new ServerSessionImpl(this, this.theMessageEndpointDeployment, newS);
/*     */           
/*     */ 
/* 497 */           if ((newServerSession.getTheWork() != null) && (ss.getTheWork() != null)) {
/* 498 */             if (JCATraceAdapter.isOn) {
/* 499 */               JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "Setting failedLast time on new serversession to: " + Boolean.toString(ss.getTheWork().isFailedLastTime()));
/*     */             }
/*     */             
/* 502 */             newServerSession.getTheWork().setFailedLastTime(ss.getTheWork().isFailedLastTime());
/*     */ 
/*     */           }
/* 505 */           else if (JCATraceAdapter.isOn) {
/* 506 */             JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "Unable to set theWork values: newSS.theWork: " + newServerSession.getTheWork() + ", ss.theWork: " + ss.getTheWork());
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 511 */           this.serverSessions.put(newS, newServerSession);
/*     */           
/* 513 */           newServerSession.release();
/*     */           
/* 515 */           this.thePool.add(newServerSession);
/*     */           
/* 517 */           this.currentPoolDepth += 1;
/*     */           
/*     */ 
/*     */ 
/* 521 */           ss.close();
/*     */           
/* 523 */           this.serverSessions.remove(s);
/*     */           
/* 525 */           boolean removed = this.thePool.remove(ss);
/* 526 */           if (removed)
/*     */           {
/* 528 */             this.currentPoolDepth -= 1;
/*     */           }
/* 530 */           if (JCATraceAdapter.isOn) {
/* 531 */             JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "sessionReleased(...)", "Discarded ServerSession: " + ss + ", currentPoolDepth: " + this.currentPoolDepth + " removed from pool: " + removed);
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (JMSException e)
/*     */         {
/*     */ 
/* 540 */           if (JCATraceAdapter.isOn) {
/* 541 */             JCATraceAdapter.traceException(this, "ServerSessionImpl", "sessionReleased(...)", e);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 547 */       this.thePool.notifyAll();
/*     */     }
/*     */     
/*     */ 
/* 551 */     if (JCATraceAdapter.isOn) {
/* 552 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "sessionReleased(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws JMSException
/*     */   {
/* 563 */     if (JCATraceAdapter.isOn) {
/* 564 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "close()");
/*     */     }
/*     */     
/* 567 */     boolean doClose = false;
/*     */     
/* 569 */     synchronized (this.closeState) {
/* 570 */       if (this.closeState.inProgress) {
/* 571 */         if (JCATraceAdapter.isOn) {
/* 572 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "close()", "close already in Progress - waiting");
/*     */         }
/* 574 */         synchronized (this.closeState) {
/* 575 */           while (this.closeState.inProgress) {
/*     */             try {
/* 577 */               this.closeState.wait();
/*     */             }
/*     */             catch (InterruptedException e) {}
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 584 */         if (JCATraceAdapter.isOn) {
/* 585 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "close()", "finished waiting");
/*     */         }
/*     */       }
/*     */       else {
/* 589 */         this.closeState.inProgress = true;
/* 590 */         doClose = true;
/*     */       }
/*     */     }
/*     */     
/* 594 */     if (doClose) {
/* 595 */       closeInternal();
/*     */       
/* 597 */       if (JCATraceAdapter.isOn) {
/* 598 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "close()", "close completed - notifying any waiters");
/*     */       }
/*     */       
/* 601 */       synchronized (this.closeState) {
/* 602 */         this.closeState.inProgress = false;
/* 603 */         this.closeState.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 608 */     if (JCATraceAdapter.isOn) {
/* 609 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "close()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void closeInternal()
/*     */   {
/* 616 */     if (JCATraceAdapter.isOn) {
/* 617 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "closeInternal()");
/*     */     }
/*     */     
/* 620 */     List<ServerSessionImpl> inUseSessions = new ArrayList();
/* 621 */     List<ServerSessionImpl> notInUseSessions = new ArrayList();
/*     */     
/* 623 */     synchronized (this.thePool)
/*     */     {
/*     */ 
/* 626 */       for (ServerSessionImpl s : this.thePool) {
/* 627 */         if (s.isInUse()) {
/* 628 */           inUseSessions.add(s);
/*     */         }
/*     */         else {
/* 631 */           notInUseSessions.add(s);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 636 */     if (JCATraceAdapter.isOn) {
/* 637 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "closeInternal()", "At close time, found " + inUseSessions.size() + " ServerSessions in use," + " and " + notInUseSessions.size() + " not in use.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 645 */       for (ServerSessionImpl s : notInUseSessions) {
/* 646 */         if (JCATraceAdapter.isOn) {
/* 647 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "closeInternal()", "closing not in use ServerSession: " + s);
/*     */         }
/*     */         
/* 650 */         s.close();
/*     */       }
/* 652 */       for (ServerSessionImpl s : inUseSessions) {
/* 653 */         if (JCATraceAdapter.isOn) {
/* 654 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "closeInternal()", "closing in use ServerSession: " + s);
/*     */         }
/*     */         
/* 657 */         s.close();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 662 */       scavengerThread.removeServerSessionPool(this);
/*     */       
/* 664 */       this.serverSessions.clear();
/*     */       
/* 666 */       if (JCATraceAdapter.isOn) {
/* 667 */         JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "closeInternal()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Session createJMSSession()
/*     */     throws JMSException
/*     */   {
/* 682 */     if (JCATraceAdapter.isOn) {
/* 683 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "createJMSSession()");
/*     */     }
/*     */     try
/*     */     {
/* 687 */       Session s = null;
/*     */       
/* 689 */       if (this.isTransacted) {
/* 690 */         s = ((XAConnection)this.theConnection).createXASession();
/* 691 */         if (JCATraceAdapter.isOn) {
/* 692 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "createJMSSession()", "created XASession: " + s);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 697 */         s = this.theConnection.createSession(false, 1);
/* 698 */         if (JCATraceAdapter.isOn) {
/* 699 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "createJMSSession()", "created Session: " + s);
/*     */         }
/*     */       }
/*     */       
/* 703 */       return s;
/*     */     }
/*     */     finally
/*     */     {
/* 707 */       if (JCATraceAdapter.isOn) {
/* 708 */         JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "createJMSSession()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void poolCleanup()
/*     */   {
/* 719 */     if (JCATraceAdapter.isOn) {
/* 720 */       JCATraceAdapter.traceEntry(this, "ServerSessionPoolImpl", "poolCleanup()");
/* 721 */       JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "poolCleanup()", "Pool Cleanup routine called for " + this);
/*     */     }
/* 723 */     synchronized (this.thePool)
/*     */     {
/* 725 */       Iterator<ServerSessionImpl> i = this.thePool.iterator();
/* 726 */       while (i.hasNext()) {
/* 727 */         ServerSessionImpl p = (ServerSessionImpl)i.next();
/* 728 */         if (JCATraceAdapter.isOn) {
/* 729 */           JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "poolCleanup()", p + ", idle time: " + p.getIdleTime() + " isInUse: " + p.isInUse());
/*     */         }
/* 731 */         if (!p.isInUse())
/*     */         {
/* 733 */           if ((this.idleTime != 0) && (p.getIdleTime() > this.idleTime)) {
/* 734 */             if (JCATraceAdapter.isOn) {
/* 735 */               JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "poolCleanup()", "closing: " + p + ", idle time = " + p.getIdleTime());
/*     */             }
/*     */             
/*     */ 
/* 739 */             this.serverSessions.remove(p.getSession());
/*     */             
/* 741 */             p.close();
/*     */             
/* 743 */             this.currentPoolDepth -= 1;
/*     */             
/*     */ 
/* 746 */             i.remove();
/*     */             
/* 748 */             if (JCATraceAdapter.isOn) {
/* 749 */               JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "poolCleanup()", "objectsInUse: " + this.serverSessionsInUse + ", currentPoolDepth: " + this.currentPoolDepth + ", maxPoolDepth: " + this.maxPoolDepth);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 756 */       if (JCATraceAdapter.isOn) {
/* 757 */         JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "poolCleanup()", "Pool Cleanup routine complete");
/*     */       }
/*     */     }
/* 760 */     if (JCATraceAdapter.isOn) {
/* 761 */       JCATraceAdapter.traceExit(this, "ServerSessionPoolImpl", "poolCleanup()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void tracePoolContents()
/*     */   {
/* 771 */     StringBuffer poolContents = new StringBuffer("Session Pool Contents:");
/* 772 */     for (ServerSessionImpl session : this.thePool) {
/* 773 */       poolContents.append(this.lineSeparator + session.introspectSelf());
/*     */     }
/*     */     
/* 776 */     JCATraceAdapter.traceInfo(this, "ServerSessionPoolImpl", "tracePoolContents()", poolContents.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIsClosing(boolean isClosing)
/*     */   {
/* 784 */     synchronized (this.thePool) {
/* 785 */       this.isClosing = isClosing;
/* 786 */       this.thePool.notifyAll();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ServerSessionPoolImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */