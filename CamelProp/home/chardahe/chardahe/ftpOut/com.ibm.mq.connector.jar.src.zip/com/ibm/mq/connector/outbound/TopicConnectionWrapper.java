/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.ConnectionConsumer;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ServerSessionPool;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicConnectionWrapper
/*     */   extends ConnectionWrapper
/*     */   implements TopicConnection
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/TopicConnectionWrapper.java";
/*     */   
/*     */   public TopicConnectionWrapper(ManagedConnectionImpl mc, TopicConnection con, boolean isManaged)
/*     */   {
/*  72 */     super(mc, con, isManaged);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TopicSession createTopicSession(boolean arg0, int arg1)
/*     */     throws JMSException
/*     */   {
/*  80 */     JCATraceAdapter.traceEntry(this, "TopicConnectionWrapper", "createTopicSession()");
/*     */     try
/*     */     {
/*  83 */       assertOpen();
/*  84 */       if (this.theSessionWrapper == null)
/*     */       {
/*  86 */         this.theSessionWrapper = new TopicSessionWrapper(this, this.theManagedConnection.getPhysicalSession());
/*     */       }
/*     */       else
/*     */       {
/*  90 */         throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1018"));
/*     */       }
/*     */       
/*  93 */       return (TopicSession)this.theSessionWrapper;
/*     */     }
/*     */     finally
/*     */     {
/*  97 */       JCATraceAdapter.traceExit(this, "TopicConnectionWrapper", "createTopicSession()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionConsumer createConnectionConsumer(Topic arg0, String arg1, ServerSessionPool arg2, int arg3)
/*     */     throws JMSException
/*     */   {
/* 107 */     return super.createConnectionConsumer(arg0, arg1, arg2, arg3);
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/TopicConnectionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */