/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.commonservices.propertystore.PropertyStore;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceAdapterConfiguration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/ResourceAdapterConfiguration.java";
/*     */   @Deprecated
/*     */   public static final int DEFAULT_CONNECTION_CONCURRENCY = 1;
/*     */   public static final int DEFAULT_MAX_CONNECTIONS = 50;
/*     */   public static final int DEFAULT_RECONNECTION_RETRY_COUNT = 5;
/*     */   public static final int DEFAULT_RECONNECTION_RETRY_INTERVAL = 300000;
/*     */   public static final int DEFAULT_STARTUP_RETRY_COUNT = 10;
/*     */   public static final int DEFAULT_STARTUP_RETRY_INTERVAL = 30000;
/*     */   public static final int DEFAULT_TRACE_LEVEL = 3;
/*     */   public static final String performJEEContainerChecksProperty = "com.ibm.mq.connector.performJavaEEContainerChecks";
/*     */   @Deprecated
/* 115 */   private int connectionConcurrency = 1;
/* 116 */   private boolean logWriterEnabled = true;
/* 117 */   private int maxConnections = 50;
/* 118 */   private int reconnectionRetryCount = 5;
/* 119 */   private int reconnectionRetryInterval = 300000;
/* 120 */   private int startupRetryCount = 10;
/* 121 */   private int startupRetryInterval = 30000;
/* 122 */   private boolean traceEnabled = false;
/* 123 */   private int traceLevel = 3;
/*     */   
/*     */ 
/*     */   String nativeLibPath;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 132 */     PropertyStore.register("com.ibm.mq.connector.performJavaEEContainerChecks", true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTraceLevel(int traceLevel)
/*     */   {
/* 154 */     this.traceLevel = traceLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTraceLevel(Integer traceLevel)
/*     */   {
/* 161 */     this.traceLevel = traceLevel.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTraceLevel(String traceLevel)
/*     */   {
/*     */     try
/*     */     {
/* 169 */       this.traceLevel = Integer.parseInt(traceLevel);
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 172 */       this.traceLevel = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTraceLevel()
/*     */   {
/* 180 */     return this.traceLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTraceEnabled(boolean traceEnabled)
/*     */   {
/* 187 */     this.traceEnabled = traceEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTraceEnabled(Boolean traceEnabled)
/*     */   {
/* 194 */     this.traceEnabled = traceEnabled.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTraceEnabled(String traceEnabled)
/*     */   {
/* 201 */     this.traceEnabled = (traceEnabled != null ? traceEnabled.equalsIgnoreCase("true") : false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getTraceEnabled()
/*     */   {
/* 208 */     return this.traceEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogWriterEnabled(boolean logWriterEnabled)
/*     */   {
/* 215 */     this.logWriterEnabled = logWriterEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogWriterEnabled(Boolean logWriterEnabled)
/*     */   {
/* 222 */     this.logWriterEnabled = logWriterEnabled.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogWriterEnabled(String logWriterEnabled)
/*     */   {
/* 229 */     this.logWriterEnabled = (logWriterEnabled != null ? logWriterEnabled.equalsIgnoreCase("true") : false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getLogWriterEnabled()
/*     */   {
/* 236 */     return this.logWriterEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMaxConnections(int maxConnections)
/*     */   {
/* 243 */     this.maxConnections = maxConnections;
/* 244 */     JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "setMaxConnections(int)", "maxConnections", Integer.valueOf(this.maxConnections));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMaxConnections(Integer maxConnections)
/*     */   {
/* 251 */     this.maxConnections = maxConnections.intValue();
/* 252 */     JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "setMaxConnections(Integer)", "maxConnections", Integer.valueOf(this.maxConnections));
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxConnections(String maxConnections)
/*     */   {
/*     */     try
/*     */     {
/* 260 */       this.maxConnections = Integer.parseInt(maxConnections);
/* 261 */       JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "setMaxConnections(String)", "maxConnections", Integer.valueOf(this.maxConnections));
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 264 */       this.maxConnections = 50;
/* 265 */       JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "setMaxConnections(String)", "maxConnections defaulted to ", maxConnections);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxConnections()
/*     */   {
/* 273 */     JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "getMaxConnections", "maxConnections", Integer.valueOf(this.maxConnections));
/* 274 */     return this.maxConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEffectiveMaxConnections()
/*     */   {
/* 281 */     int effectiveMaxConnections = this.maxConnections * this.connectionConcurrency;
/* 282 */     JCATraceAdapter.traceData(this, "ResourceAdapterConfiguration", "getEffectiveMaxConnections", "effectiveMaxConnections", Integer.valueOf(effectiveMaxConnections));
/* 283 */     return effectiveMaxConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setConnectionConcurrency(int connectionConcurrency)
/*     */   {
/* 292 */     JCATraceAdapter.traceInfo(this, "ResourceAdapterConfiguration", "setConnectionConcurrency(int)", "deprecated, ignoring supplied value: " + connectionConcurrency);
/* 293 */     this.connectionConcurrency = connectionConcurrency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setConnectionConcurrency(Integer connectionConcurrency)
/*     */   {
/* 302 */     JCATraceAdapter.traceInfo(this, "ResourceAdapterConfiguration", "setConnectionConcurrency(Integer)", "deprecated, ignoring supplied value: " + connectionConcurrency);
/* 303 */     this.connectionConcurrency = connectionConcurrency.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setConnectionConcurrency(String connectionConcurrency)
/*     */   {
/* 312 */     JCATraceAdapter.traceInfo(this, "ResourceAdapterConfiguration", "setConnectionConcurrency(String)", "deprecated, ignoring supplied value: " + connectionConcurrency);
/* 313 */     this.connectionConcurrency = Integer.parseInt(connectionConcurrency);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public int getConnectionConcurrency()
/*     */   {
/* 322 */     return this.connectionConcurrency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReconnectionRetryInterval(int reconnectionRetryInterval)
/*     */   {
/* 329 */     this.reconnectionRetryInterval = reconnectionRetryInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReconnectionRetryInterval(Integer reconnectionRetryInterval)
/*     */   {
/* 336 */     this.reconnectionRetryInterval = reconnectionRetryInterval.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setReconnectionRetryInterval(String reconnectionRetryInterval)
/*     */   {
/*     */     try
/*     */     {
/* 344 */       this.reconnectionRetryInterval = Integer.parseInt(reconnectionRetryInterval);
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 347 */       this.reconnectionRetryInterval = 300000;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getReconnectionRetryInterval()
/*     */   {
/* 355 */     return this.reconnectionRetryInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReconnectionRetryCount(int reconnectionRetryCount)
/*     */   {
/* 362 */     this.reconnectionRetryCount = reconnectionRetryCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReconnectionRetryCount(Integer reconnectionRetryCount)
/*     */   {
/* 369 */     this.reconnectionRetryCount = reconnectionRetryCount.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setReconnectionRetryCount(String reconnectionRetryCount)
/*     */   {
/*     */     try
/*     */     {
/* 377 */       this.reconnectionRetryCount = Integer.parseInt(reconnectionRetryCount);
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 380 */       this.reconnectionRetryCount = 5;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getReconnectionRetryCount()
/*     */   {
/* 388 */     return this.reconnectionRetryCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStartupRetryInterval(int startupRetryInterval)
/*     */   {
/* 395 */     this.startupRetryInterval = startupRetryInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStartupRetryInterval(Integer startupRetryInterval)
/*     */   {
/* 402 */     this.startupRetryInterval = startupRetryInterval.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStartupRetryInterval(String startupRetryInterval)
/*     */   {
/*     */     try
/*     */     {
/* 410 */       this.startupRetryInterval = Integer.parseInt(startupRetryInterval);
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 413 */       this.startupRetryInterval = 30000;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getStartupRetryInterval()
/*     */   {
/* 421 */     return this.startupRetryInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStartupRetryCount(int startupRetryCount)
/*     */   {
/* 428 */     this.startupRetryCount = startupRetryCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStartupRetryCount(Integer startupRetryCount)
/*     */   {
/* 435 */     this.startupRetryCount = startupRetryCount.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStartupRetryCount(String startupRetryCount)
/*     */   {
/*     */     try
/*     */     {
/* 443 */       this.startupRetryCount = Integer.parseInt(startupRetryCount);
/*     */     }
/*     */     catch (NumberFormatException nfe) {
/* 446 */       this.startupRetryCount = 10;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNativeLibraryPath(String nativeLibPath)
/*     */   {
/* 455 */     PropertyStore.set("com.ibm.mq.cfg.jmqi.libpath", nativeLibPath);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getNativeLibraryPath()
/*     */   {
/* 461 */     return this.nativeLibPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartupRetryCount()
/*     */   {
/* 469 */     return this.startupRetryCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isZOS()
/*     */   {
/* 477 */     int env = ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment();
/* 478 */     return (env == 8) || (env == 16) || (env == 32) || (env == 184);
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/ResourceAdapterConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */