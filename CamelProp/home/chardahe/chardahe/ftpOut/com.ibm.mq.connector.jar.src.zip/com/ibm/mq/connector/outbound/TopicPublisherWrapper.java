/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageProducer;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicPublisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicPublisherWrapper
/*     */   extends MessageProducerWrapper
/*     */   implements TopicPublisher
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/TopicPublisherWrapper.java";
/*     */   
/*     */   protected TopicPublisherWrapper(SessionWrapper sw, Session s, Topic t)
/*     */     throws JMSException
/*     */   {
/*  62 */     JCATraceAdapter.traceEntry(this, "TopicPublisherWrapper", "<init>");
/*     */     
/*     */ 
/*  65 */     if ((t instanceof MQTopicProxy))
/*     */     {
/*  67 */       this.theDestination = ((MQTopicProxy)t).getMQTopic();
/*  68 */       JCATraceAdapter.traceInfo(this, "TopicPublisherWrapper", "<init>", "extracted Topic: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  73 */       this.theDestination = t;
/*  74 */       JCATraceAdapter.traceInfo(this, "TopicPublisherWrapper", "<init>", "using Topic: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/*  78 */     this.theSessionWrapper = sw;
/*     */     try
/*     */     {
/*  81 */       this.theProducer = s.createProducer(this.theDestination);
/*     */     }
/*     */     finally
/*     */     {
/*  85 */       JCATraceAdapter.traceExit(this, "TopicPublisherWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Topic getTopic()
/*     */     throws JMSException
/*     */   {
/*  93 */     assertOpen();
/*     */     
/*  95 */     return (Topic)this.theDestination;
/*     */   }
/*     */   
/*     */ 
/*     */   public void publish(Message msg)
/*     */     throws JMSException
/*     */   {
/* 102 */     assertOpen();
/*     */     
/* 104 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 105 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 108 */     this.theProducer.send(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void publish(Message msg, int deliveryMode, int priority, long timeToLive)
/*     */     throws JMSException
/*     */   {
/* 116 */     assertOpen();
/*     */     
/* 118 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 119 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 122 */     this.theProducer.send(msg, deliveryMode, priority, timeToLive);
/*     */   }
/*     */   
/*     */ 
/*     */   public void publish(Topic dest, Message msg)
/*     */     throws JMSException
/*     */   {
/* 129 */     assertOpen();
/*     */     
/* 131 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 132 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 135 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 137 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg);
/*     */     }
/*     */     else
/*     */     {
/* 141 */       this.theProducer.send(dest, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void publish(Topic dest, Message msg, int deliveryMode, int priority, long timeToLive)
/*     */     throws JMSException
/*     */   {
/* 150 */     assertOpen();
/*     */     
/* 152 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 153 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 156 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 158 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg, deliveryMode, priority, timeToLive);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 163 */       this.theProducer.send(dest, msg, deliveryMode, priority, timeToLive);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/TopicPublisherWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */