/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.AbstractConfiguration;
/*     */ import com.ibm.mq.connector.ConnectionFactoryBuilder;
/*     */ import com.ibm.mq.connector.CustomPropertyHandler;
/*     */ import com.ibm.mq.connector.ResourceAdapterConfiguration;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.jms.JmsConnection;
/*     */ import com.ibm.msg.client.jms.JmsConnectionFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.XAConnectionFactory;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionHandler
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2012 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ConnectionHandler.java";
/*     */   private static final long serialVersionUID = 4815162342L;
/*  82 */   private static ConnectionHandler theConnectionHandler = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ResourceAdapterConfiguration rac;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  93 */   private static int maxConnections = -1;
/*     */   
/*     */ 
/*  96 */   private final Map<AbstractConfiguration, ConnectionFactory> nonTXPool = new HashMap();
/*  97 */   private final Map<AbstractConfiguration, ConnectionFactory> txPool = new HashMap();
/*     */   
/*     */ 
/* 100 */   private final Map<AbstractConfiguration, String> qmidMap = new HashMap();
/*     */   
/*     */ 
/* 103 */   private final List<Connection> countedConnections = new ArrayList();
/*     */   
/*     */ 
/* 106 */   private final List<Connection> unCountedConnections = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConnectionHandler getInstance()
/*     */   {
/* 119 */     if (theConnectionHandler == null)
/*     */     {
/* 121 */       theConnectionHandler = new ConnectionHandler();
/*     */     }
/* 123 */     return theConnectionHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerResourceAdapter(ResourceAdapterConfiguration racP)
/*     */   {
/* 132 */     JCATraceAdapter.traceData(null, "ConnectionHandler", "registerResourceAdapter", "ResourceAdapterConfiguration", racP);
/*     */     
/*     */ 
/* 135 */     rac = racP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Connection allocateConnection(ActivationSpecImpl config, boolean transacted, boolean observeMaxConnections)
/*     */     throws ResourceAdapterInternalException
/*     */   {
/* 150 */     JCATraceAdapter.traceEntry(this, "ConnectionHandler", "allocateConnection(...)", new Object[] { config, Boolean.valueOf(transacted), Boolean.valueOf(observeMaxConnections) });
/*     */     
/* 152 */     JCATraceAdapter.traceData(this, "ConnectionHandler", "allocateConnection(...)", "current connection count", Integer.valueOf(this.countedConnections.size()));
/*     */     
/* 154 */     if (observeMaxConnections) {
/* 155 */       int currentMaxConnections = maxConnections;
/* 156 */       if (currentMaxConnections == -1)
/*     */       {
/*     */ 
/* 159 */         currentMaxConnections = rac.getEffectiveMaxConnections();
/*     */       }
/*     */       
/*     */ 
/* 163 */       if (this.countedConnections.size() >= currentMaxConnections) {
/* 164 */         JMSException je = new JMSException("maximum connections (" + currentMaxConnections + ") reached");
/*     */         
/* 166 */         throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1011", je));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 172 */     if (config == null) {
/* 173 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1011", new NullPointerException("supplied actSpec is null")));
/*     */     }
/*     */     
/*     */ 
/* 177 */     Connection c = null;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 183 */       ConnectionFactory cf = null;
/* 184 */       if ((transacted) && (this.txPool.containsKey(config)))
/*     */       {
/* 186 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "reusing cached XACF");
/* 187 */         cf = (ConnectionFactory)this.txPool.get(config);
/*     */       }
/* 189 */       else if ((!transacted) && (this.nonTXPool.containsKey(config)))
/*     */       {
/* 191 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "reusing cached non-XA CF");
/* 192 */         cf = (ConnectionFactory)this.nonTXPool.get(config);
/*     */       }
/*     */       else {
/* 195 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "creating new CF");
/*     */         
/* 197 */         cf = ConnectionFactoryBuilder.getInstance().createConnectionFactory(config, 1, transacted);
/*     */         
/* 199 */         if (transacted) {
/* 200 */           this.txPool.put(config, cf);
/*     */         }
/*     */         else {
/* 203 */           this.nonTXPool.put(config, cf);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 209 */       if ((transacted) && ((cf instanceof XAConnectionFactory)))
/*     */       {
/* 211 */         c = ((XAConnectionFactory)cf).createXAConnection(config.getUserName(), config.getPassword());
/*     */       }
/*     */       else
/*     */       {
/* 215 */         c = cf.createConnection(config.getUserName(), config.getPassword());
/*     */       }
/*     */       
/*     */       String qmid;
/* 219 */       if (transacted) {
/* 220 */         qmid = null;
/*     */         try {
/* 222 */           qmid = ((JmsConnection)c).getStringProperty("XMSC_WMQ_RESOLVED_QUEUE_MANAGER_ID");
/* 223 */           JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "qmid: " + qmid);
/*     */         }
/*     */         catch (JMSException je)
/*     */         {
/* 227 */           HashMap<String, Object> info = new HashMap();
/* 228 */           info.put("Exception", je);
/* 229 */           JCATraceAdapter.ffst(null, "ConnectionHandler", "JCA90210", info);
/*     */         }
/* 231 */         if ((qmid != null) && (this.qmidMap.containsKey(config))) {
/* 232 */           String oldQMID = (String)this.qmidMap.get(config);
/*     */           
/* 234 */           if (!qmid.equals(oldQMID))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */             String qsgName = null;
/*     */             try {
/* 243 */               qsgName = ((JmsConnection)c).getStringProperty("XMSC_WMQ_REMOTE_QMGR_QSGNAME");
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 247 */               if (JCATraceAdapter.isOn) {
/* 248 */                 JCATraceAdapter.traceException(this, "ResourceAdapterConnectionPool", "allocateConnection()", e);
/*     */               }
/*     */               
/* 251 */               qsgName = "UNKNOWN";
/*     */             }
/*     */             
/* 254 */             if ((qsgName == null) || (qsgName.trim().length() == 0)) {
/* 255 */               if (JCATraceAdapter.isOn) {
/* 256 */                 JCATraceAdapter.traceData(this, "ResourceAdapterConnectionPool", "allocateConnection()", "QSGName is \"" + qsgName + "\", throwing ResourceAdapterInternalException for qmid: " + qmid + " and oldQMID: " + oldQMID, null);
/*     */               }
/*     */               
/*     */ 
/* 260 */               throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1011", new ResourceException("QMID mismatch (expected: " + oldQMID + ", received " + qmid + ")")));
/*     */             }
/*     */             
/*     */ 
/* 264 */             if (JCATraceAdapter.isOn) {
/* 265 */               JCATraceAdapter.traceData(this, "ResourceAdapterConnectionPool", "allocateConnection()", "QSGNAME is " + qsgName + ", ignoring that QMIDs do not match", null);
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 271 */           else if (JCATraceAdapter.isOn) {
/* 272 */             JCATraceAdapter.traceData(this, "ResourceAdapterConnectionPool", "allocateConnection()", "Skipping QMID check as session is not transacted", "");
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 278 */         else if (qmid != null)
/*     */         {
/* 280 */           this.qmidMap.put(config, qmid);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 287 */       JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "propeties string: " + config.getArbitraryProperties());
/*     */       
/* 289 */       CustomPropertyHandler.setCustomProperties(config, (JmsConnectionFactory)cf, true);
/*     */       
/*     */ 
/* 292 */       if (observeMaxConnections) {
/* 293 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "adding the connection to the counted set");
/* 294 */         this.countedConnections.add(c);
/*     */       }
/*     */       else {
/* 297 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "allocateConnection()", "adding the connection to the uncounted set");
/* 298 */         this.unCountedConnections.add(c);
/*     */       }
/*     */       
/* 301 */       return c;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/*     */ 
/*     */ 
/* 310 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1011", je));
/*     */     }
/*     */     finally
/*     */     {
/* 314 */       JCATraceAdapter.traceExit(this, "ConnectionHandler", "allocateConnection(...)", c);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void destroyConnection(Connection conn)
/*     */   {
/* 325 */     JCATraceAdapter.traceEntry(this, "ConnectionHandler", "destroyConnection()", new Object[] { conn });
/* 326 */     boolean connectionClosed = false;
/*     */     try {
/* 328 */       if ((this.countedConnections.contains(conn)) || (this.unCountedConnections.contains(conn)))
/*     */       {
/* 330 */         conn.close();
/* 331 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "destroyConnection()", "destroyed successfully");
/*     */         
/* 333 */         connectionClosed = true;
/*     */       }
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 338 */       JCAMessageBuilder.buildWarning("MQJCA4011", null);
/*     */       
/* 340 */       JCATraceAdapter.traceException(this, "ConnectionHandler", "destroyConnection(...)", je);
/*     */     }
/*     */     finally {
/* 343 */       if (connectionClosed)
/*     */       {
/* 345 */         if (!this.countedConnections.remove(conn)) {
/* 346 */           this.unCountedConnections.remove(conn);
/*     */         }
/* 348 */         JCATraceAdapter.traceInfo(this, "ConnectionHandler", "destroyConnection()", "removed from list");
/*     */       }
/* 350 */       JCATraceAdapter.traceExit(this, "ConnectionHandler", "destroyConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void purgeConnections()
/*     */   {
/* 359 */     JCATraceAdapter.traceEntry(this, "ConnectionHandler", "purgeConnections()");
/*     */     try
/*     */     {
/* 362 */       for (Connection c : this.countedConnections) {
/* 363 */         c.close();
/*     */       }
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 368 */       JCAMessageBuilder.buildWarning("MQJCA4011", null);
/*     */       
/* 370 */       JCATraceAdapter.traceException(this, "ConnectionHandler", "purgeConnections(...)", je);
/*     */     }
/*     */     finally
/*     */     {
/* 374 */       this.countedConnections.clear();
/* 375 */       JCATraceAdapter.traceExit(this, "ConnectionHandler", "purgeConnections()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 384 */     purgeConnections();
/*     */     
/* 386 */     this.txPool.clear();
/* 387 */     this.nonTXPool.clear();
/* 388 */     this.qmidMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int getMaxConnections()
/*     */   {
/* 395 */     return maxConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void setMaxConnections(int i)
/*     */   {
/* 402 */     maxConnections = i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getConnectionCount()
/*     */   {
/* 409 */     return this.countedConnections.size();
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ConnectionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */