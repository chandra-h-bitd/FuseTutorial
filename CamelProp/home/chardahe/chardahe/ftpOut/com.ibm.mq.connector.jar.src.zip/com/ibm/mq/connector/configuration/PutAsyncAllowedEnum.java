/*     */ package com.ibm.mq.connector.configuration;
/*     */ 
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PutAsyncAllowedEnum
/*     */ {
/*  37 */   AS_DEST("DESTINATION", "putAsyncAllowed", -1), 
/*     */   
/*  39 */   AS_QDEF("QUEUE", "putAsyncAllowed", -1), 
/*     */   
/*  41 */   AS_TOPIC("TOPIC", "putAsyncAllowed", -1), 
/*     */   
/*  43 */   DISABLED("DISABLED", "putAsyncAllowed", 0), 
/*     */   
/*  45 */   ENABLED("ENABLED", "putAsyncAllowed", 0);
/*     */   
/*     */ 
/*     */ 
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/configuration/PutAsyncAllowedEnum.java";
/*     */   
/*     */   private String tag;
/*     */   
/*     */   private String property;
/*     */   
/*     */   private int propertyValue;
/*     */   
/*     */   private static HashMap<String, PutAsyncAllowedEnum> lookup;
/*     */   
/*     */ 
/*     */   private PutAsyncAllowedEnum(String tag, String property, int propertyValue)
/*     */   {
/*  64 */     this.tag = tag;
/*  65 */     this.property = property;
/*  66 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*  71 */     lookup = new HashMap();
/*  72 */     for (PutAsyncAllowedEnum e : values()) {
/*  73 */       lookup.put(e.tag, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PutAsyncAllowedEnum byTag(String tag)
/*     */   {
/*  82 */     return (PutAsyncAllowedEnum)lookup.get(tag.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProperty(JmsPropertyContext context)
/*     */     throws JMSException
/*     */   {
/*  90 */     context.setIntProperty(this.property, this.propertyValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTag()
/*     */   {
/*  97 */     return this.tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     return this.tag;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/configuration/PutAsyncAllowedEnum.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */