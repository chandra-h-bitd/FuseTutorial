/*      */ package com.ibm.mq.connector.inbound;
/*      */ 
/*      */ import com.ibm.mq.connector.AbstractConfiguration;
/*      */ import com.ibm.mq.connector.JCARuntimeHelper;
/*      */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*      */ import com.ibm.mq.connector.configuration.TransportTypeEnum;
/*      */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*      */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*      */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*      */ import com.ibm.msg.client.commonservices.cssystem.WASSupport.WASRuntimeHelper;
/*      */ import com.ibm.msg.client.commonservices.propertystore.PropertyStore;
/*      */ import java.util.HashMap;
/*      */ import javax.resource.spi.ActivationSpec;
/*      */ import javax.resource.spi.InvalidPropertyException;
/*      */ import javax.resource.spi.ResourceAdapter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ActivationSpecImpl
/*      */   extends AbstractConfiguration
/*      */   implements ActivationSpec
/*      */ {
/*      */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2012 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*      */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ActivationSpecImpl.java";
/*      */   private static final long serialVersionUID = 4815162342L;
/*      */   public static final String QUEUE = "javax.jms.Queue";
/*      */   public static final String TOPIC = "javax.jms.Topic";
/*      */   public static final String DURABLE = "Durable";
/*      */   public static final String NON_DURABLE = "NonDurable";
/*   88 */   private ResourceAdapter theAssociatedResourceAdapter = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String MQJCA_MRET_YES = "YES";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String MQJCA_MRET_NO = "NO";
/*      */   
/*      */ 
/*      */ 
/*  100 */   private static final String[] MRET_VALUES = { "YES", "NO" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  110 */   private int acknowledgeMode = 1;
/*      */   
/*      */ 
/*  113 */   private int maxPoolDepth = 10;
/*      */   
/*      */ 
/*  116 */   private int nonASFTimeout = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  122 */   private boolean nonASFRollbackEnabled = false;
/*      */   
/*      */ 
/*  125 */   private int poolTimeout = 300000;
/*      */   
/*      */ 
/*  128 */   private int maxMessages = 1;
/*      */   
/*      */ 
/*  131 */   private int messageBatchSize = 10;
/*      */   
/*      */ 
/*  134 */   private String messageRetention = "YES";
/*      */   
/*      */ 
/*  137 */   private String messageSelector = null;
/*      */   
/*      */ 
/*  140 */   private String subscriptionDurability = "NonDurable";
/*      */   
/*      */ 
/*  143 */   private String subscriptionName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private int startTimeout = 10000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  158 */   private String destinationType = "javax.jms.Queue";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  165 */   private String destination = "SYSTEM.DEFAULT.LOCAL.QUEUE";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  172 */   private boolean useJNDI = false;
/*      */   
/*      */ 
/*  175 */   private String brokerCCDurSubQueue = "SYSTEM.JMS.D.CC.SUBSCRIBER.QUEUE";
/*      */   
/*      */ 
/*      */ 
/*  179 */   public static String MQJCA_READ_AHEAD_CLOSE_POLICY_ALL = "ALL";
/*  180 */   public static String MQJCA_READ_AHEAD_CLOSE_POLICY_CURRENT = "CURRENT";
/*      */   
/*  182 */   private String readAheadClosePolicy = MQJCA_READ_AHEAD_CLOSE_POLICY_ALL;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReadAheadClosePolicy()
/*      */   {
/*  190 */     return this.readAheadClosePolicy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadAheadClosePolicy(String readAheadClosePolicy)
/*      */   {
/*  205 */     if (JCATraceAdapter.isOn) {
/*  206 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setReadAheadClosePolicy", "readAheadClosePolicy", readAheadClosePolicy);
/*      */     }
/*      */     
/*  209 */     this.readAheadClosePolicy = readAheadClosePolicy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validate()
/*      */     throws InvalidPropertyException
/*      */   {
/*  242 */     JCATraceAdapter.traceEntry(this, "ActivationSpecImpl", "validate()");
/*      */     try
/*      */     {
/*  245 */       if (JCATraceAdapter.isOn)
/*      */       {
/*  247 */         traceParams();
/*      */       }
/*      */       
/*      */ 
/*  251 */       super.validate();
/*      */       
/*      */ 
/*  254 */       if ((this.acknowledgeMode != 1) && (this.acknowledgeMode != 3))
/*      */       {
/*  256 */         this.inserts.clear();
/*  257 */         this.inserts.put("JCA_CONFIG_PROPERTY", "acknowledgeMode");
/*  258 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.acknowledgeMode));
/*      */         
/*  260 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  265 */       if (this.maxPoolDepth <= 0)
/*      */       {
/*  267 */         this.inserts.clear();
/*  268 */         this.inserts.put("JCA_CONFIG_PROPERTY", "maxPoolDepth");
/*  269 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.maxPoolDepth));
/*      */         
/*  271 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  276 */       if (PropertyStore.wasOverridden("com.ibm.mq.connector.nonASFRollbackEnabled", null)) {
/*  277 */         this.nonASFRollbackEnabled = PropertyStore.getBooleanPropertyObject("com.ibm.mq.connector.nonASFRollbackEnabled").booleanValue();
/*  278 */         JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "validate()", "overriding of NONASF_ROLLBACK_ENABLED" + this.nonASFRollbackEnabled);
/*      */       }
/*      */       
/*      */ 
/*  282 */       if (PropertyStore.wasOverridden("com.ibm.mq.connector.nonASFTimeout", null)) {
/*  283 */         Long overridePropertyValue = PropertyStore.getLongPropertyObject("com.ibm.mq.connector.nonASFTimeout");
/*  284 */         if (overridePropertyValue != null) {
/*  285 */           int overrideTimeout = (int)overridePropertyValue.longValue();
/*  286 */           JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "validate()", "overriding of NONASF_TIMEOUT" + overrideTimeout);
/*  287 */           this.nonASFTimeout = overrideTimeout;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  292 */       if ((this.nonASFTimeout > 0) && (ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment() == 1)) {
/*  293 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA2007", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*  297 */       if (this.nonASFTimeout < 0)
/*      */       {
/*  299 */         this.inserts.clear();
/*  300 */         this.inserts.put("JCA_CONFIG_PROPERTY", "nonASFTimeout");
/*  301 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.nonASFTimeout));
/*      */         
/*  303 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  308 */       if (this.poolTimeout <= 0)
/*      */       {
/*  310 */         this.inserts.clear();
/*  311 */         this.inserts.put("JCA_CONFIG_PROPERTY", "poolTimeout");
/*  312 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.poolTimeout));
/*      */         
/*  314 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  319 */       if (this.maxMessages <= 0)
/*      */       {
/*  321 */         this.inserts.clear();
/*  322 */         this.inserts.put("JCA_CONFIG_PROPERTY", "maxMessages");
/*  323 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.maxMessages));
/*      */         
/*  325 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*  329 */       if (this.messageBatchSize <= 0)
/*      */       {
/*  331 */         this.inserts.clear();
/*  332 */         this.inserts.put("JCA_CONFIG_PROPERTY", "messageBatchSize");
/*  333 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.messageBatchSize));
/*      */         
/*  335 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*  339 */       if (!isValidString(this.messageRetention, MRET_VALUES))
/*      */       {
/*  341 */         this.inserts.clear();
/*  342 */         this.inserts.put("JCA_CONFIG_PROPERTY", "messageRetention");
/*  343 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.messageRetention));
/*      */         
/*  345 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  350 */       if (this.startTimeout < 0)
/*      */       {
/*  352 */         this.inserts.clear();
/*  353 */         this.inserts.put("JCA_CONFIG_PROPERTY", "startTimeout");
/*  354 */         this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.startTimeout));
/*      */         
/*  356 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  362 */       if ((this.destinationType == null) || ((!this.destinationType.equalsIgnoreCase("javax.jms.Queue")) && (!this.destinationType.equalsIgnoreCase("javax.jms.Topic")))) {
/*  363 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA2003"));
/*      */       }
/*      */       
/*  366 */       if (this.destination == null) {
/*  367 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA2002"));
/*      */       }
/*      */       
/*  370 */       if (this.destinationType.equalsIgnoreCase("javax.jms.Topic"))
/*      */       {
/*  372 */         if ("Durable".equalsIgnoreCase(this.subscriptionDurability)) {
/*  373 */           if ((this.subscriptionName == null) || (this.subscriptionName.equals(""))) {
/*  374 */             throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA2004"));
/*      */           }
/*  376 */           if (this.brokerCCDurSubQueue == null) {
/*  377 */             throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA2006"));
/*      */           }
/*      */         }
/*  380 */         else if (!"NonDurable".equalsIgnoreCase(this.subscriptionDurability))
/*      */         {
/*  382 */           this.inserts.clear();
/*  383 */           this.inserts.put("JCA_CONFIG_PROPERTY", "subscriptionDurability");
/*  384 */           this.inserts.put("JCA_CONFIG_VALUE", this.subscriptionDurability);
/*      */           
/*  386 */           throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  392 */       if ((!this.readAheadClosePolicy.equalsIgnoreCase(MQJCA_READ_AHEAD_CLOSE_POLICY_ALL)) && (!this.readAheadClosePolicy.equalsIgnoreCase(MQJCA_READ_AHEAD_CLOSE_POLICY_CURRENT)))
/*      */       {
/*  394 */         this.inserts.clear();
/*  395 */         this.inserts.put("JCA_CONFIG_PROPERTY", "readAheadClosePolicy");
/*  396 */         this.inserts.put("JCA_CONFIG_VALUE", this.readAheadClosePolicy);
/*      */         
/*  398 */         throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  404 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "validate()", "ActivationSpec " + toString() + " validated successfully");
/*      */     }
/*      */     finally
/*      */     {
/*  408 */       JCATraceAdapter.traceExit(this, "ActivationSpecImpl", "validate()");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResourceAdapter(ResourceAdapter ra)
/*      */   {
/*  424 */     if (JCATraceAdapter.isOn) {
/*  425 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setResourceAdapter", "ra", ra);
/*      */     }
/*      */     
/*      */ 
/*  429 */     if (this.theAssociatedResourceAdapter == null) {
/*  430 */       this.theAssociatedResourceAdapter = ra;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResourceAdapter getResourceAdapter()
/*      */   {
/*  441 */     return this.theAssociatedResourceAdapter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAcknowledgeMode(int ackmode)
/*      */   {
/*  457 */     if (JCATraceAdapter.isOn) {
/*  458 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setAcknowledgeMode(int)", "ackmode", new Integer(ackmode));
/*      */     }
/*      */     
/*  461 */     this.acknowledgeMode = ackmode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAcknowlegeMode(String ackmode)
/*      */   {
/*  470 */     if (JCATraceAdapter.isOn) {
/*  471 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setAcknowlegeMode(String)", "ackmode", ackmode);
/*      */     }
/*      */     
/*      */ 
/*  475 */     setAcknowledgeMode(ackmode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAcknowledgeMode(String ackmode)
/*      */   {
/*  484 */     if (JCATraceAdapter.isOn) {
/*  485 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setAcknowledgeMode(String)", "ackmode", ackmode);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  491 */     setAcknowledgeMode(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAcknowledgeMode()
/*      */   {
/*  500 */     return this.acknowledgeMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxPoolDepth(int depth)
/*      */   {
/*  511 */     if (JCATraceAdapter.isOn) {
/*  512 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMaxPoolDepth(int)", "depth", new Integer(depth));
/*      */     }
/*      */     
/*  515 */     this.maxPoolDepth = depth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxPoolDepth(Integer depth)
/*      */   {
/*  526 */     if (JCATraceAdapter.isOn) {
/*  527 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMaxPoolDepth(Integer)", "depth", depth);
/*      */     }
/*      */     
/*  530 */     this.maxPoolDepth = depth.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxPoolDepth()
/*      */   {
/*  540 */     return this.maxPoolDepth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFRollbackEnabled(boolean enabled)
/*      */   {
/*  551 */     this.nonASFRollbackEnabled = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFRollbackEnabled(Boolean enabled)
/*      */   {
/*  562 */     this.nonASFRollbackEnabled = enabled.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFRollbackEnabled(String enabled)
/*      */   {
/*  573 */     this.nonASFRollbackEnabled = (enabled != null ? enabled.equalsIgnoreCase("true") : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getNonASFRollbackEnabled()
/*      */   {
/*  581 */     return this.nonASFRollbackEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFTimeout(int timeout)
/*      */   {
/*  592 */     this.nonASFTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFTimeout(Integer timeout)
/*      */   {
/*  603 */     this.nonASFTimeout = timeout.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonASFTimeout(String timeout)
/*      */   {
/*      */     try
/*      */     {
/*  615 */       this.nonASFTimeout = Integer.parseInt(timeout);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  619 */       this.inserts.clear();
/*  620 */       this.inserts.put("JCA_CONFIG_PROPERTY", "nonASFTimeout");
/*  621 */       this.inserts.put("JCA_CONFIG_VALUE", timeout);
/*  622 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(0));
/*      */       
/*  624 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNonASFTimeout()
/*      */   {
/*  633 */     return this.nonASFTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPoolTimeout(int timeout)
/*      */   {
/*  645 */     if (JCATraceAdapter.isOn) {
/*  646 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setPoolTimeout(int)", "timeout", new Integer(timeout));
/*      */     }
/*      */     
/*  649 */     this.poolTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPoolTimeout(Integer timeout)
/*      */   {
/*  661 */     if (JCATraceAdapter.isOn) {
/*  662 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setPoolTimeout(Integer)", "timeout", timeout);
/*      */     }
/*      */     
/*  665 */     this.poolTimeout = timeout.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPoolTimeout()
/*      */   {
/*  675 */     return this.poolTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxMessages(int max)
/*      */   {
/*  686 */     if (JCATraceAdapter.isOn) {
/*  687 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMaxMessages(int)", "max", new Integer(max));
/*      */     }
/*      */     
/*  690 */     this.maxMessages = max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxMessages(Integer max)
/*      */   {
/*  701 */     if (JCATraceAdapter.isOn) {
/*  702 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMaxMessages(Integer)", "max", max);
/*      */     }
/*      */     
/*  705 */     this.maxMessages = max.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxMessages(String max)
/*      */   {
/*  716 */     if (JCATraceAdapter.isOn) {
/*  717 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMaxMessages(String)", "max", max);
/*      */     }
/*      */     try
/*      */     {
/*  721 */       this.maxMessages = Integer.parseInt(max);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  725 */       this.inserts.clear();
/*  726 */       this.inserts.put("JCA_CONFIG_PROPERTY", "maxMessages");
/*  727 */       this.inserts.put("JCA_CONFIG_VALUE", max);
/*  728 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.maxMessages));
/*      */       
/*  730 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxMessages()
/*      */   {
/*  741 */     return this.maxMessages;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageBatchSize(int mbs)
/*      */   {
/*  752 */     if (JCATraceAdapter.isOn) {
/*  753 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMessageBatchSize(int)", "mbs", new Integer(mbs));
/*      */     }
/*      */     
/*  756 */     this.messageBatchSize = mbs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageBatchSize(Integer mbs)
/*      */   {
/*  767 */     if (JCATraceAdapter.isOn) {
/*  768 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMessageBatchSize(Integer)", "mbs", mbs);
/*      */     }
/*      */     
/*  771 */     this.messageBatchSize = mbs.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMessageBatchSize()
/*      */   {
/*  780 */     return this.messageBatchSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageRetention(String ret)
/*      */   {
/*  791 */     if (JCATraceAdapter.isOn) {
/*  792 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMessageRetention", "ret", ret);
/*      */     }
/*      */     
/*  795 */     this.messageRetention = ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessageRetention()
/*      */   {
/*  804 */     return this.messageRetention;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageSelector(String selector)
/*      */   {
/*  814 */     if (JCATraceAdapter.isOn) {
/*  815 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setMessageSelector", "selector", selector);
/*      */     }
/*      */     
/*  818 */     this.messageSelector = selector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessageSelector()
/*      */   {
/*  827 */     return this.messageSelector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubscriptionDurability(String durability)
/*      */   {
/*  839 */     if (JCATraceAdapter.isOn) {
/*  840 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setSubscriptionDurability", "durability", durability);
/*      */     }
/*      */     
/*  843 */     this.subscriptionDurability = durability;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSubscriptionDurability()
/*      */   {
/*  852 */     return this.subscriptionDurability;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubscriptionName(String name)
/*      */   {
/*  863 */     if (JCATraceAdapter.isOn) {
/*  864 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setSubscriptionName", "name", name);
/*      */     }
/*      */     
/*  867 */     this.subscriptionName = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSubscriptionName()
/*      */   {
/*  876 */     return this.subscriptionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStartTimeout(int timeout)
/*      */   {
/*  893 */     if (JCATraceAdapter.isOn) {
/*  894 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setStartTimeout(int)", "timeout", new Integer(timeout));
/*      */     }
/*      */     
/*  897 */     this.startTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStartTimeout(Integer timeout)
/*      */   {
/*  910 */     if (JCATraceAdapter.isOn) {
/*  911 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setStartTimeout(Integer)", "timeout", timeout);
/*      */     }
/*      */     
/*  914 */     this.startTimeout = timeout.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStartTimeout()
/*      */   {
/*  924 */     return this.startTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDestinationType(String type)
/*      */   {
/*  938 */     if (JCATraceAdapter.isOn) {
/*  939 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setDestinationType", "type", type);
/*      */     }
/*      */     
/*  942 */     this.destinationType = type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDestinationType()
/*      */   {
/*  951 */     return this.destinationType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDestination(String dest)
/*      */   {
/*  963 */     if (JCATraceAdapter.isOn) {
/*  964 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setDestination", "dest", dest);
/*      */     }
/*      */     
/*  967 */     this.destination = dest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDestination()
/*      */   {
/*  976 */     return this.destination;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJNDI(boolean jndi)
/*      */   {
/*  988 */     if (JCATraceAdapter.isOn) {
/*  989 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setUseJNDI(boolean)", "jndi", new Boolean(jndi));
/*      */     }
/*      */     
/*  992 */     this.useJNDI = jndi;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJNDI(Boolean jndi)
/*      */   {
/* 1004 */     if (JCATraceAdapter.isOn) {
/* 1005 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setUseJNDI(Boolean)", "jndi", jndi);
/*      */     }
/*      */     
/* 1008 */     this.useJNDI = jndi.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJNDI(String jndi)
/*      */   {
/* 1020 */     if (JCATraceAdapter.isOn) {
/* 1021 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setUseJNDI(String)", "jndi", jndi);
/*      */     }
/*      */     
/* 1024 */     this.useJNDI = (jndi != null ? jndi.equalsIgnoreCase("true") : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseJNDI()
/*      */   {
/* 1033 */     return this.useJNDI;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBrokerCCDurSubQueue(String queue)
/*      */   {
/* 1044 */     if (JCATraceAdapter.isOn) {
/* 1045 */       JCATraceAdapter.traceData(this, "ActivationSpecImpl", "setBrokerCCDurSubQueue", "queue", queue);
/*      */     }
/*      */     
/* 1048 */     this.brokerCCDurSubQueue = queue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrokerCCDurSubQueue()
/*      */   {
/* 1057 */     return this.brokerCCDurSubQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1078 */     return this.destinationType + ":" + this.destination + "@" + getQueueManager() + " <" + System.identityHashCode(this) + ">";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean compareQueueManagers(AbstractConfiguration b)
/*      */   {
/* 1098 */     boolean theSame = super.compareQueueManagers(b);
/*      */     
/* 1100 */     if (theSame) {
/* 1101 */       if ((b instanceof ActivationSpecImpl))
/*      */       {
/*      */ 
/* 1104 */         ActivationSpecImpl as = (ActivationSpecImpl)b;
/* 1105 */         theSame = (this.messageBatchSize == as.getMessageBatchSize()) && (this.messageRetention != null ? this.messageRetention.equalsIgnoreCase(as.getMessageRetention()) : as.getMessageRetention() == null);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1110 */         theSame = false;
/*      */       }
/*      */     }
/*      */     
/* 1114 */     return theSame;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void traceParams()
/*      */   {
/* 1124 */     JCATraceAdapter.traceEntry(this, "ActivationSpecImpl", "traceParams()");
/*      */     
/*      */ 
/* 1127 */     JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "destination:          " + this.destination);
/* 1128 */     JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "destinationType:      " + this.destinationType);
/*      */     
/*      */ 
/* 1131 */     if (this.useJNDI) {
/* 1132 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "useJNDI:              " + this.useJNDI);
/*      */     }
/* 1134 */     if (this.maxMessages != 1) {
/* 1135 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "maxMessages:          " + this.maxMessages);
/*      */     }
/* 1137 */     if (this.messageBatchSize != 10) {
/* 1138 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "msgBatchSize:         " + this.messageBatchSize);
/*      */     }
/* 1140 */     if (!"YES".equals(this.messageRetention)) {
/* 1141 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "msgRetention:         " + this.messageRetention);
/*      */     }
/* 1143 */     if (this.maxPoolDepth != 10) {
/* 1144 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "maxPoolDepth:         " + this.maxPoolDepth);
/*      */     }
/* 1146 */     if (this.messageSelector != null) {
/* 1147 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "messageSelector:      " + this.messageSelector);
/*      */     }
/* 1149 */     if (this.poolTimeout != 300000) {
/* 1150 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "poolTimeout:          " + this.poolTimeout);
/*      */     }
/* 1152 */     if (this.startTimeout != 10000) {
/* 1153 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "startTimeout:         " + this.startTimeout);
/*      */     }
/*      */     
/*      */ 
/* 1157 */     if (this.readAheadClosePolicy != MQJCA_READ_AHEAD_CLOSE_POLICY_ALL) {
/* 1158 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "readAheadClosePolicy:     " + this.readAheadClosePolicy);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1163 */     if ("javax.jms.Topic".equals(this.destinationType)) {
/* 1164 */       if (!"brokerCCDurSubQueue".equals(this.brokerCCDurSubQueue)) {
/* 1165 */         JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "brokerCCDurSubQueue:        " + this.brokerCCDurSubQueue);
/*      */       }
/* 1167 */       if (!"NonDurable".equals(this.subscriptionDurability)) {
/* 1168 */         JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "subscriptionDurability:     " + this.subscriptionDurability);
/*      */       }
/* 1170 */       if (this.subscriptionName != null) {
/* 1171 */         JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "traceParams()", "subscriptionName:           " + this.subscriptionName);
/*      */       }
/*      */     }
/* 1174 */     JCATraceAdapter.traceExit(this, "ActivationSpecImpl", "traceParams()");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean getRRSTransactional()
/*      */   {
/* 1192 */     boolean rrsTransactional = false;
/* 1193 */     WASSupport.WASRuntimeHelper helper = (WASSupport.WASRuntimeHelper)PropertyStore.getObjectProperty("com.ibm.mq.connector.JCARuntimeHelper");
/* 1194 */     if ((helper != null) && 
/* 1195 */       (helper.getEnvironment() == 184)) {
/* 1196 */       JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "getRRSTransactional()", "Running on zOS Liberty");
/*      */       
/* 1198 */       TransportTypeEnum trType = getTransportTypeEnum();
/*      */       
/* 1200 */       if (trType == TransportTypeEnum.BINDINGS) {
/* 1201 */         rrsTransactional = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1207 */     JCATraceAdapter.traceInfo(this, "ActivationSpecImpl", "getRRSTransactional()", "rrsTransactional:" + rrsTransactional);
/* 1208 */     return rrsTransactional;
/*      */   }
/*      */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ActivationSpecImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */