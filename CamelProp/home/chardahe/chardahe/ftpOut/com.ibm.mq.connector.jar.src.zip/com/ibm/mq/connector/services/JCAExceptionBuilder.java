/*     */ package com.ibm.mq.connector.services;
/*     */ 
/*     */ import com.ibm.mq.connector.DetailedInvalidPropertyException;
/*     */ import com.ibm.mq.connector.DetailedResourceAdapterInternalException;
/*     */ import com.ibm.mq.connector.DetailedResourceException;
/*     */ import com.ibm.mq.connector.DetailedSecurityException;
/*     */ import com.ibm.msg.client.commonservices.nls.NLSServices;
/*     */ import com.ibm.msg.client.jms.DetailedIllegalStateException;
/*     */ import com.ibm.msg.client.jms.DetailedJMSException;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JCAExceptionBuilder
/*     */   extends JCAMessageBuilder
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/JCAExceptionBuilder.java";
/*     */   public static final int RESOURCE_EXCEPTION = 0;
/*     */   public static final int RESOURCE_ADAPTER_INTERNAL_EXCEPTION = 1;
/*     */   public static final int INVALID_PROPERTY_EXCEPTION = 2;
/*     */   public static final int JMS_EXCEPTION = 3;
/*     */   public static final int ILLEGAL_STATE_EXCEPTION = 4;
/*     */   public static final int SECURITY_EXCEPTION = 5;
/*     */   
/*     */   public static Throwable buildException(int type, String messageCode)
/*     */   {
/*  91 */     return buildException(type, messageCode, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable buildException(int type, String messageCode, Throwable linked)
/*     */   {
/* 105 */     return buildException(type, messageCode, null, linked);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable buildException(int type, String messageCode, HashMap inserts, Throwable linked)
/*     */   {
/* 120 */     Throwable t = null;
/* 121 */     String message = messageCode + ": " + NLSServices.getMessage(messageCode, inserts);
/* 122 */     String explanation = NLSServices.getExplanation(messageCode, inserts);
/* 123 */     String useraction = NLSServices.getUserAction(messageCode, inserts);
/*     */     
/*     */ 
/* 126 */     switch (type)
/*     */     {
/*     */     case 0: 
/* 129 */       t = new DetailedResourceException(message, messageCode, explanation, useraction, inserts);
/* 130 */       t.initCause(linked);
/* 131 */       break;
/*     */     
/*     */     case 1: 
/* 134 */       t = new DetailedResourceAdapterInternalException(message, messageCode, explanation, useraction, inserts);
/*     */       
/* 136 */       t.initCause(linked);
/* 137 */       break;
/*     */     
/*     */     case 2: 
/* 140 */       t = new DetailedInvalidPropertyException(message, messageCode, explanation, useraction, inserts);
/*     */       
/* 142 */       t.initCause(linked);
/* 143 */       break;
/*     */     
/*     */     case 3: 
/* 146 */       t = new DetailedJMSException(message, messageCode, explanation, useraction, inserts);
/*     */       
/* 148 */       if ((linked instanceof Exception))
/* 149 */         ((JMSException)t).setLinkedException((Exception)linked);
/* 150 */       break;
/*     */     
/*     */ 
/*     */     case 4: 
/* 154 */       t = new DetailedIllegalStateException(message, messageCode, explanation, useraction, inserts);
/*     */       
/* 156 */       break;
/*     */     
/*     */     case 5: 
/* 159 */       t = new DetailedSecurityException(message, messageCode, explanation, useraction, inserts);
/* 160 */       t.initCause(linked);
/* 161 */       break;
/*     */     
/*     */ 
/*     */     default: 
/* 165 */       HashMap insert = new HashMap();
/* 166 */       insert.put("JCA_NLS_MESSAGE_ID", new Integer(type));
/* 167 */       t = new RuntimeException(NLSServices.getMessage("MQJCA0000", insert), linked);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 172 */     JCATraceAdapter.traceException(null, "JCAExceptionBuilder", "buildException()", t);
/* 173 */     return t;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/JCAExceptionBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */