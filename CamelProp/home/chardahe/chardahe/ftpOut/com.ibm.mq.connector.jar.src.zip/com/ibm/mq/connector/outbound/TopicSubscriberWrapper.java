/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicSubscriberWrapper
/*     */   extends MessageConsumerWrapper
/*     */   implements TopicSubscriber
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/TopicSubscriberWrapper.java";
/*     */   private boolean noLocal;
/*     */   
/*     */   public TopicSubscriberWrapper(SessionWrapper sw, Session s, boolean isManaged, Topic t)
/*     */     throws JMSException
/*     */   {
/*  66 */     this(sw, s, isManaged, t, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicSubscriberWrapper(SessionWrapper sw, Session s, boolean isManaged, Topic t, String sel)
/*     */     throws JMSException
/*     */   {
/*  80 */     this(sw, s, isManaged, t, sel, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicSubscriberWrapper(SessionWrapper sw, Session s, boolean isManaged, Topic t, String sel, boolean noLoc)
/*     */     throws JMSException
/*     */   {
/* 101 */     this(sw, s, isManaged, t, null, sel, noLoc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicSubscriberWrapper(SessionWrapper sw, Session s, boolean isManaged, Topic t, String name, String sel, boolean noLoc)
/*     */     throws JMSException
/*     */   {
/* 125 */     JCATraceAdapter.traceEntry(this, "TopicSubscriberWrapper", "<init>");
/*     */     
/* 127 */     this.isManaged = isManaged;
/* 128 */     this.noLocal = noLoc;
/*     */     
/* 130 */     if ((t instanceof MQTopicProxy))
/*     */     {
/* 132 */       this.theDestination = ((MQTopicProxy)t).getMQTopic();
/* 133 */       JCATraceAdapter.traceInfo(this, "TopicSubscriberWrapper", "<init>", "extracted Topic: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 138 */       this.theDestination = t;
/* 139 */       JCATraceAdapter.traceInfo(this, "TopicSubscriberWrapper", "<init>", "using Topic: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/* 143 */     this.theSessionWrapper = sw;
/*     */     
/* 145 */     JCATraceAdapter.traceInfo(this, "TopicSubscriberWrapper", "<init>", "noLocal: " + noLoc + ", selector: " + sel);
/*     */     
/*     */     try
/*     */     {
/* 149 */       if (name != null)
/*     */       {
/* 151 */         this.theConsumer = s.createDurableSubscriber((Topic)this.theDestination, name, sel, noLoc);
/*     */       }
/*     */       else
/*     */       {
/* 155 */         this.theConsumer = s.createConsumer(this.theDestination, sel, noLoc);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 160 */       JCATraceAdapter.traceExit(this, "TopicSubscriberWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Topic getTopic()
/*     */     throws JMSException
/*     */   {
/* 168 */     assertOpen();
/*     */     
/* 170 */     return (Topic)this.theDestination;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getNoLocal()
/*     */     throws JMSException
/*     */   {
/* 177 */     assertOpen();
/* 178 */     return this.noLocal;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/TopicSubscriberWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */