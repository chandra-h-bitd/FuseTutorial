/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLSocketFactoryHandler
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/SSLSocketFactoryHandler.java";
/*     */   
/*     */   public static String[] parseSSLSocketFactory(String data)
/*     */     throws SocketFactoryParseException
/*     */   {
/*  92 */     String[] result = new String[2];
/*     */     
/*     */ 
/*  95 */     if (data == null) {
/*  96 */       throw new SocketFactoryParseException("null data passed to parseSSLSocketFactory");
/*     */     }
/*  98 */     if ((data.indexOf("(") == -1) && (data.indexOf(")") == -1))
/*     */     {
/* 100 */       validateClassName(data);
/*     */       
/* 102 */       result[0] = data;
/* 103 */       result[1] = null;
/*     */     }
/* 105 */     else if ((data.indexOf("(") != -1) && (data.indexOf(")") != -1))
/*     */     {
/*     */ 
/* 108 */       if (data.indexOf("(") == 0) {
/* 109 */         throw new SocketFactoryParseException("invalid SSLSocketFactory name: " + data);
/*     */       }
/*     */       
/* 112 */       if (data.lastIndexOf(")") != data.length() - 1) {
/* 113 */         throw new SocketFactoryParseException("invalid SSLSocketFactory name: " + data);
/*     */       }
/*     */       
/* 116 */       validateClassName(data.substring(0, data.indexOf("(")));
/*     */       
/* 118 */       result[0] = data.substring(0, data.indexOf("("));
/*     */       
/* 120 */       result[1] = data.substring(data.indexOf("(") + 1, data.length() - 1);
/*     */     }
/*     */     else
/*     */     {
/* 124 */       throw new SocketFactoryParseException("invalid SSLSocketFactory name: " + data);
/*     */     }
/*     */     
/* 127 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SSLSocketFactory instantiateSocketFactory(String socketFactoryData)
/*     */     throws JMSException
/*     */   {
/* 148 */     JCATraceAdapter.traceEntry(null, "SSLSocketFactoryHandler", "instantiateSocketFactory");
/*     */     try
/*     */     {
/* 151 */       SSLSocketFactory theFactory = null;
/*     */       
/*     */       try
/*     */       {
/* 155 */         String[] data = parseSSLSocketFactory(socketFactoryData);
/*     */         
/*     */ 
/* 158 */         ClassLoader classLoader = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */ 
/*     */           public Object run()
/*     */           {
/*     */ 
/* 164 */             ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 165 */             return cl;
/*     */           }
/*     */         });
/*     */         
/* 169 */         if (classLoader != null)
/*     */         {
/*     */           try
/*     */           {
/* 173 */             Class c = classLoader.loadClass(data[0]);
/* 174 */             if (!classLoader.loadClass("javax.net.ssl.SSLSocketFactory").isAssignableFrom(c))
/*     */             {
/* 176 */               HashMap inserts = new HashMap();
/* 177 */               inserts.put("JCA_SSL_SOCKET_FACTORY", data[0]);
/* 178 */               throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1030", inserts, null));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */             if (data[1] != null)
/*     */             {
/* 187 */               Class[] cl = { String.class };
/* 188 */               Constructor con = c.getConstructor(cl);
/*     */               
/* 190 */               Object[] args = { data[1] };
/*     */               
/* 192 */               theFactory = (SSLSocketFactory)con.newInstance(args);
/*     */             }
/*     */             else
/*     */             {
/* 196 */               theFactory = (SSLSocketFactory)c.newInstance();
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 203 */             throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1029", e));
/*     */ 
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 210 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1029", null));
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (SocketFactoryParseException p)
/*     */       {
/*     */ 
/* 218 */         HashMap inserts = new HashMap();
/* 219 */         inserts.put("JCA_PROPERTY_VALUE", socketFactoryData);
/* 220 */         JCAMessageBuilder.buildWarning("MQJCA4009", inserts);
/*     */         
/* 222 */         JCATraceAdapter.traceException(null, "SSLSocketFactoryHandler", "instantiateSocketFactory", p);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 227 */       return theFactory;
/*     */     }
/*     */     finally
/*     */     {
/* 231 */       JCATraceAdapter.traceExit(null, "SSLSocketFactoryHandler", "instantiateSocketFactory");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void validateClassName(String data)
/*     */     throws SocketFactoryParseException
/*     */   {
/* 245 */     if (data.indexOf(".") != -1) {
/* 246 */       String[] s = data.split("\\.");
/*     */       
/* 248 */       for (int i = 0; i < s.length; i++) {
/* 249 */         if (!isValidClassNameComponent(s[i])) {
/* 250 */           throw new SocketFactoryParseException("invalid class name: " + data);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 257 */     else if (!isValidClassNameComponent(data)) {
/* 258 */       throw new SocketFactoryParseException("invalid class name: " + data);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isValidClassNameComponent(String s)
/*     */   {
/* 271 */     if (s == null) {
/* 272 */       return false;
/*     */     }
/*     */     
/* 275 */     if ((s.length() == 0) || (!Character.isJavaIdentifierStart(s.charAt(0)))) {
/* 276 */       return false;
/*     */     }
/*     */     
/* 279 */     for (int i = 1; i < s.length(); i++) {
/* 280 */       if (!Character.isJavaIdentifierPart(s.charAt(i))) {
/* 281 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 285 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/SSLSocketFactoryHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */