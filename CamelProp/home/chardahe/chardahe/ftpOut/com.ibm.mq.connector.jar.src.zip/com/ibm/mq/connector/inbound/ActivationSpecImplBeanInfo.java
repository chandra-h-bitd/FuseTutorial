/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.AbstractConfigurationBeanInfo;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActivationSpecImplBeanInfo
/*     */   extends AbstractConfigurationBeanInfo
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ActivationSpecImplBeanInfo.java";
/*  77 */   static final Class beanClass = ActivationSpecImpl.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescriptor getBeanDescriptor()
/*     */   {
/*  87 */     JCATraceAdapter.traceEntry(this, "ActivationSpecImplBeanInfo", "getBeanDescriptor()");
/*     */     try
/*     */     {
/*  90 */       return new BeanDescriptor(beanClass);
/*     */     }
/*     */     finally {
/*  93 */       JCATraceAdapter.traceExit(this, "ActivationSpecImplBeanInfo", "getBeanDescriptor()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/* 106 */     JCATraceAdapter.traceEntry(this, "ActivationSpecImplBeanInfo", "getPropertyDescriptors()");
/*     */     
/*     */     try
/*     */     {
/* 110 */       PropertyDescriptor[] common = super.getPropertyDescriptors();
/*     */       
/*     */ 
/* 113 */       acknowledgeMode = new PropertyDescriptor("acknowledgeMode", beanClass);
/* 114 */       acknowledgeMode.setExpert(false);
/*     */       
/* 116 */       PropertyDescriptor brokerCCDurSubQueue = new PropertyDescriptor("brokerCCDurSubQueue", beanClass);
/*     */       
/* 118 */       brokerCCDurSubQueue.setExpert(true);
/*     */       
/* 120 */       PropertyDescriptor destination = new PropertyDescriptor("destination", beanClass);
/* 121 */       destination.setPreferred(true);
/*     */       
/* 123 */       PropertyDescriptor destinationType = new PropertyDescriptor("destinationType", beanClass);
/* 124 */       destinationType.setPreferred(true);
/*     */       
/* 126 */       PropertyDescriptor maxMessages = new PropertyDescriptor("maxMessages", beanClass);
/* 127 */       maxMessages.setExpert(true);
/*     */       
/* 129 */       PropertyDescriptor maxPoolDepth = new PropertyDescriptor("maxPoolDepth", beanClass);
/* 130 */       maxPoolDepth.setExpert(true);
/*     */       
/* 132 */       PropertyDescriptor messageSelector = new PropertyDescriptor("messageSelector", beanClass);
/* 133 */       messageSelector.setPreferred(true);
/*     */       
/* 135 */       PropertyDescriptor messageBatchSize = new PropertyDescriptor("messageBatchSize", beanClass);
/* 136 */       messageBatchSize.setExpert(true);
/*     */       
/* 138 */       PropertyDescriptor messageRetention = new PropertyDescriptor("messageRetention", beanClass);
/* 139 */       messageRetention.setExpert(true);
/*     */       
/* 141 */       PropertyDescriptor nonASFRollbackEnabled = new PropertyDescriptor("nonASFRollbackEnabled", beanClass);
/* 142 */       nonASFRollbackEnabled.setExpert(true);
/*     */       
/* 144 */       PropertyDescriptor nonASFTimeout = new PropertyDescriptor("nonASFTimeout", beanClass);
/* 145 */       nonASFTimeout.setExpert(true);
/*     */       
/* 147 */       PropertyDescriptor poolTimeout = new PropertyDescriptor("poolTimeout", beanClass);
/* 148 */       poolTimeout.setExpert(true);
/*     */       
/* 150 */       PropertyDescriptor startTimeout = new PropertyDescriptor("startTimeout", beanClass);
/* 151 */       startTimeout.setExpert(true);
/*     */       
/* 153 */       PropertyDescriptor subscriptionDurability = new PropertyDescriptor("subscriptionDurability", beanClass);
/*     */       
/* 155 */       subscriptionDurability.setExpert(true);
/*     */       
/* 157 */       PropertyDescriptor subscriptionName = new PropertyDescriptor("subscriptionName", beanClass);
/* 158 */       subscriptionName.setPreferred(true);
/*     */       
/* 160 */       PropertyDescriptor useJNDI = new PropertyDescriptor("useJNDI", beanClass);
/* 161 */       useJNDI.setPreferred(true);
/*     */       
/*     */ 
/* 164 */       PropertyDescriptor readAheadClosePolicy = new PropertyDescriptor("readAheadClosePolicy", beanClass);
/* 165 */       readAheadClosePolicy.setExpert(true);
/*     */       
/*     */ 
/* 168 */       PropertyDescriptor[] result = null;
/*     */       
/*     */       PropertyDescriptor[] rv;
/* 171 */       if (common != null)
/*     */       {
/* 173 */         rv = new PropertyDescriptor[] { acknowledgeMode, brokerCCDurSubQueue, destination, destinationType, maxMessages, maxPoolDepth, messageBatchSize, messageRetention, messageSelector, nonASFRollbackEnabled, nonASFTimeout, poolTimeout, startTimeout, subscriptionName, subscriptionDurability, useJNDI, readAheadClosePolicy };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */         result = new PropertyDescriptor[common.length + rv.length];
/* 180 */         System.arraycopy(common, 0, result, 0, common.length);
/* 181 */         System.arraycopy(rv, 0, result, common.length, rv.length);
/*     */       }
/*     */       
/* 184 */       return result;
/*     */     }
/*     */     catch (IntrospectionException e) {
/*     */       PropertyDescriptor acknowledgeMode;
/* 188 */       JCATraceAdapter.traceException(this, "ActivationSpecImplBeanInfo", "getPropertyDescriptors()", e);
/*     */       
/* 190 */       return null;
/*     */     }
/*     */     finally
/*     */     {
/* 194 */       JCATraceAdapter.traceExit(this, "ActivationSpecImplBeanInfo", "getPropertyDescriptors()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ActivationSpecImplBeanInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */