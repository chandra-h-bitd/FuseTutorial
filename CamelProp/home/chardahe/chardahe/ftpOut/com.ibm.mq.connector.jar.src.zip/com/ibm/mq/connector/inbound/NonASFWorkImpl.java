/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQXASession;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageConsumer;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonASFWorkImpl
/*     */   extends AbstractWorkImpl
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/NonASFWorkImpl.java";
/*  75 */   private Destination theDestination = null;
/*     */   
/*  77 */   private MessageConsumer theConsumer = null;
/*     */   
/*  79 */   private String theSelector = null;
/*     */   
/*  81 */   private int theTimeout = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NonASFWorkImpl(MessageEndpointDeployment med, Session s, Destination d, String selector, int timeout)
/*     */     throws JMSException
/*     */   {
/*  89 */     if (JCATraceAdapter.isOn) {
/*  90 */       JCATraceAdapter.traceEntry(this, "NonASFWorkImpl", "<init>", new Object[] { med, s, d, selector, Integer.valueOf(timeout) });
/*     */     }
/*     */     
/*     */ 
/*  94 */     this.theDeployment = med;
/*  95 */     this.theSession = s;
/*  96 */     this.theDestination = d;
/*  97 */     this.theSelector = selector;
/*  98 */     this.theTimeout = timeout;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 104 */       this.theConsumer = s.createConsumer(this.theDestination, this.theSelector);
/*     */     }
/*     */     finally
/*     */     {
/* 108 */       if (JCATraceAdapter.isOn) {
/* 109 */         JCATraceAdapter.traceExit(this, "NonASFWorkImpl", "<init>");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NonASFWorkImpl(MessageEndpointDeployment med, Session s, Topic t, String subscriptionName, String selector, int timeout)
/*     */     throws JMSException
/*     */   {
/* 120 */     if (JCATraceAdapter.isOn) {
/* 121 */       JCATraceAdapter.traceEntry(this, "NonASFWorkImpl", "<init>", new Object[] { med, s, t, subscriptionName, selector, Integer.valueOf(timeout) });
/*     */     }
/*     */     
/*     */ 
/* 125 */     this.theDeployment = med;
/* 126 */     this.theSession = s;
/* 127 */     this.theDestination = t;
/* 128 */     this.theSelector = selector;
/* 129 */     this.theTimeout = timeout;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 135 */       this.theConsumer = s.createDurableSubscriber(t, subscriptionName, this.theSelector, false);
/*     */     }
/*     */     finally
/*     */     {
/* 139 */       if (JCATraceAdapter.isOn) {
/* 140 */         JCATraceAdapter.traceExit(this, "NonASFWorkImpl", "<init>");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doDelivery(MessageEndpoint endpoint)
/*     */     throws JMSException
/*     */   {
/* 157 */     if (JCATraceAdapter.isOn) {
/* 158 */       JCATraceAdapter.traceEntry(this, "NonASFWorkImpl", "doDelivery(MessageEndpoint)", new Object[] { endpoint });
/*     */     }
/*     */     try
/*     */     {
/* 162 */       Message m = this.theConsumer.receive(this.theTimeout);
/* 163 */       if (m != null) {
/* 164 */         ((MessageListener)endpoint).onMessage(m);
/* 165 */         if ((!this.theDeployment.isTransacted()) && (this.theSession.getTransacted())) {
/* 166 */           this.theSession.commit();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RuntimeException re)
/*     */     {
/* 172 */       if ((!this.theDeployment.isTransacted()) && (this.theSession.getTransacted())) {
/* 173 */         this.theSession.rollback();
/*     */       }
/*     */       
/* 176 */       throw re;
/*     */     }
/*     */     finally
/*     */     {
/* 180 */       if (JCATraceAdapter.isOn) {
/* 181 */         JCATraceAdapter.traceExit(this, "NonASFWorkImpl", "doDelivery(...)");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanupDelivery() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stop()
/*     */   {
/* 202 */     if (JCATraceAdapter.isOn) {
/* 203 */       JCATraceAdapter.traceEntry(this, "NonASFWorkImpl", "stop()");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 213 */         this.theConsumer.close();
/*     */       }
/*     */       catch (JMSException je)
/*     */       {
/* 217 */         HashMap<String, String> inserts = new HashMap();
/* 218 */         inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/* 219 */         JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*     */         
/* 221 */         if (JCATraceAdapter.isOn) {
/* 222 */           JCATraceAdapter.traceException(this, "NonASFWorkImpl", "stop()", je);
/*     */         }
/*     */       }
/* 225 */       this.theSession.close();
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 229 */       HashMap<String, String> inserts = new HashMap();
/* 230 */       inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/* 231 */       JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*     */       
/* 233 */       if (JCATraceAdapter.isOn) {
/* 234 */         JCATraceAdapter.traceException(this, "NonASFWorkImpl", "stop()", je);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 239 */       if (JCATraceAdapter.isOn) {
/* 240 */         JCATraceAdapter.traceExit(this, "NonASFWorkImpl", "stop()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean sessionClosed()
/*     */   {
/* 249 */     boolean sessionClosed = ((this.theSession instanceof MQXASession)) && (((MQXASession)this.theSession).isClosed());
/* 250 */     if (JCATraceAdapter.isOn) {
/* 251 */       JCATraceAdapter.traceData(this, "NonASFWorkImpl", "sessionClosed", "returning value", Boolean.valueOf(sessionClosed));
/*     */     }
/* 253 */     return sessionClosed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 260 */     int identityHashCode = System.identityHashCode(this);
/* 261 */     return "NonASFWorkImpl[" + identityHashCode + " - " + Integer.toHexString(identityHashCode) + ", " + this.theDestination + ", timeout=" + this.theTimeout + "]";
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/NonASFWorkImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */