package com.ibm.mq.connector.xa;

public abstract interface XAObserver
{
  public static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  public static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/xa/XAObserver.java";
  
  public abstract void xaStateChanged(int paramInt);
}


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/xa/XAObserver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */