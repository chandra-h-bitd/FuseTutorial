/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageProducer;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueueSenderWrapper
/*     */   extends MessageProducerWrapper
/*     */   implements QueueSender
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/QueueSenderWrapper.java";
/*     */   
/*     */   protected QueueSenderWrapper(SessionWrapper sw, Session s, Queue q)
/*     */     throws JMSException
/*     */   {
/*  62 */     JCATraceAdapter.traceEntry(this, "QueueSenderWrapper", "<init>");
/*     */     
/*     */ 
/*  65 */     if ((q instanceof MQQueueProxy))
/*     */     {
/*  67 */       this.theDestination = ((MQQueueProxy)q).getMQQueue();
/*  68 */       JCATraceAdapter.traceInfo(this, "QueueSenderWrapper", "<init>", "extracted Queue: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  73 */       this.theDestination = q;
/*  74 */       JCATraceAdapter.traceInfo(this, "QueueSenderWrapper", "<init>", "using Queue: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/*  78 */     this.theSessionWrapper = sw;
/*     */     try
/*     */     {
/*  81 */       this.theProducer = s.createProducer(this.theDestination);
/*     */     }
/*     */     finally
/*     */     {
/*  85 */       JCATraceAdapter.traceExit(this, "QueueSenderWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Queue getQueue()
/*     */     throws JMSException
/*     */   {
/*  93 */     assertOpen();
/*     */     
/*  95 */     return (Queue)this.theDestination;
/*     */   }
/*     */   
/*     */ 
/*     */   public void send(Queue dest, Message msg)
/*     */     throws JMSException
/*     */   {
/* 102 */     assertOpen();
/*     */     
/* 104 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 105 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 108 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 110 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg);
/*     */     }
/*     */     else
/*     */     {
/* 114 */       this.theProducer.send(dest, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void send(Queue dest, Message msg, int deliveryMode, int priority, long timeToLive)
/*     */     throws JMSException
/*     */   {
/* 123 */     assertOpen();
/*     */     
/* 125 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 126 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 129 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 131 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg, deliveryMode, priority, timeToLive);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 136 */       this.theProducer.send(dest, msg, deliveryMode, priority, timeToLive);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/QueueSenderWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */