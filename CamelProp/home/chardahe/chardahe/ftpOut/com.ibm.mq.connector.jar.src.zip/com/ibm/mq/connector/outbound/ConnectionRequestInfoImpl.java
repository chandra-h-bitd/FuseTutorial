/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionRequestInfoImpl
/*     */   implements ConnectionRequestInfo
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ConnectionRequestInfoImpl.java";
/*  51 */   private String applUsername = null;
/*     */   
/*  53 */   private String applPassword = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  61 */     this.applUsername = username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUsername()
/*     */   {
/*  70 */     return this.applUsername;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/*  79 */     this.applPassword = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/*  88 */     return this.applPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  99 */     JCATraceAdapter.traceEntry(this, "ConnectionRequestInfoImplo", "equals()");
/*     */     try {
/* 101 */       boolean isEqual = true;
/* 102 */       ConnectionRequestInfoImpl other; if ((o instanceof ConnectionRequestInfoImpl)) {
/* 103 */         other = (ConnectionRequestInfoImpl)o;
/*     */         
/* 105 */         if (this.applUsername == null)
/*     */         {
/* 107 */           isEqual = other.getUsername() == null;
/*     */         }
/*     */         else
/*     */         {
/* 111 */           isEqual = this.applUsername.equals(other.getUsername());
/*     */         }
/*     */         
/* 114 */         if (isEqual) {
/* 115 */           if (this.applPassword == null)
/*     */           {
/* 117 */             isEqual = other.getPassword() == null;
/*     */           }
/*     */           else
/*     */           {
/* 121 */             isEqual = this.applPassword.equals(other.getPassword());
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 127 */         isEqual = false;
/*     */       }
/*     */       
/* 130 */       JCATraceAdapter.traceInfo(this, "ConnectionRequestInfo", "equals()", "isEqual: " + isEqual);
/*     */       
/* 132 */       return isEqual;
/*     */     }
/*     */     finally
/*     */     {
/* 136 */       JCATraceAdapter.traceExit(this, "ConnectionRequestInfoImplo", "equals()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 150 */     return 'Թ' + (this.applUsername != null ? this.applUsername.hashCode() : 0) + (this.applPassword != null ? this.applPassword.hashCode() : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 159 */     StringBuffer b = new StringBuffer();
/*     */     
/* 161 */     b.append("username: " + this.applUsername);
/*     */     
/* 163 */     b.append("password: " + (this.applPassword != null ? this.applPassword.length() + " characters" : "null"));
/*     */     
/*     */ 
/*     */ 
/* 167 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ConnectionRequestInfoImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */