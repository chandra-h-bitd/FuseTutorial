/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.JCARuntimeHelper;
/*     */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicConnectionFactoryImpl
/*     */   extends ConnectionFactoryImpl
/*     */   implements TopicConnectionFactory
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/TopicConnectionFactoryImpl.java";
/*     */   
/*     */   public TopicConnectionFactoryImpl(ManagedConnectionFactoryImpl mcf)
/*     */   {
/*  73 */     this(mcf, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicConnectionFactoryImpl(ManagedConnectionFactoryImpl mcf, ConnectionManager cm)
/*     */   {
/*  85 */     super(mcf, cm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection createConnection()
/*     */     throws JMSException
/*     */   {
/*  98 */     return createConnection(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection createConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 114 */     if (ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment() != 1) {
/* 115 */       return createTopicConnection(username, password);
/*     */     }
/*     */     
/*     */ 
/* 119 */     throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1026"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicConnection createTopicConnection()
/*     */     throws JMSException
/*     */   {
/* 128 */     return createTopicConnection(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicConnection createTopicConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 137 */     return (TopicConnection)createConnectionInternal(username, password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Connection createUnmanagedJMSConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 152 */     JCATraceAdapter.traceEntry(this, "TopicConnectionFactoryImpl", "createUnmanagedJMSConnection()");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 157 */       if (this.theCF == null) {
/* 158 */         this.theCF = this.theMCF.createConnectionFactory(3);
/*     */       }
/*     */       
/*     */ 
/* 162 */       return ((TopicConnectionFactory)this.theCF).createTopicConnection(username, password);
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 166 */       throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1011", je));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 171 */       JCATraceAdapter.traceExit(this, "TopicConnectionFactoryImpl", "createUnmanagedJMSConnection()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/TopicConnectionFactoryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */