/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.configuration.CleanupLevelEnum;
/*     */ import com.ibm.mq.connector.configuration.PutAsyncAllowedEnum;
/*     */ import com.ibm.mq.connector.configuration.ReadAheadAllowedEnum;
/*     */ import com.ibm.mq.connector.configuration.SubscriptionStoreEnum;
/*     */ import com.ibm.mq.connector.configuration.TransportTypeEnum;
/*     */ import com.ibm.mq.connector.inbound.ActivationSpecImpl;
/*     */ import com.ibm.mq.connector.outbound.ManagedConnectionFactoryConfiguration;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQRRSConnectionFactory;
/*     */ import com.ibm.mq.jms.MQRRSQueueConnectionFactory;
/*     */ import com.ibm.mq.jms.MQRRSTopicConnectionFactory;
/*     */ import com.ibm.msg.client.commonservices.trace.Trace;
/*     */ import com.ibm.msg.client.jms.JmsConnectionFactory;
/*     */ import com.ibm.msg.client.jms.JmsFactoryFactory;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionFactoryBuilder
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/ConnectionFactoryBuilder.java";
/*  77 */   private static ConnectionFactoryBuilder theBuilder = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int CONNECTION_FACTORY = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int QUEUE_CONNECTION_FACTORY = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int TOPIC_CONNECTION_FACTORY = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConnectionFactoryBuilder getInstance()
/*     */   {
/*  99 */     if (theBuilder == null) {
/* 100 */       theBuilder = new ConnectionFactoryBuilder();
/*     */     }
/*     */     
/* 103 */     return theBuilder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionFactory createConnectionFactory(AbstractConfiguration c, int type, boolean transacted)
/*     */     throws JMSException
/*     */   {
/* 120 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryBuilder", "createConnectionFactory()");
/*     */     
/*     */ 
/* 123 */     if ((type < 1) || (type > 3)) {
/* 124 */       throw new JMSException("invalid ConnectionFactory type");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 129 */       if ((c instanceof ManagedConnectionFactoryConfiguration)) {
/*     */         try {
/* 131 */           c.validate();
/*     */         }
/*     */         catch (InvalidPropertyException e)
/*     */         {
/* 135 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1012", e));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 140 */       JmsConnectionFactory theMQCF = constructJmsConnectionFactory(c, transacted, type);
/*     */       
/*     */ 
/* 143 */       if (theMQCF == null)
/*     */       {
/* 145 */         throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1012", null));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */       traceV6CrossDomainProperties(c);
/* 153 */       setV6CrossDomainProperties(theMQCF, c);
/*     */       
/* 155 */       if (type != 3) {
/* 156 */         traceV6PointToPointProperties(c);
/* 157 */         setV6PointToPointProperties(theMQCF, c);
/*     */       }
/*     */       
/* 160 */       if (type != 2) {
/* 161 */         traceV6PubSubProperties(c);
/* 162 */         setV6PubSubProperties(theMQCF, c);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 168 */       if ((c instanceof ActivationSpecImpl)) {
/* 169 */         traceV6InboundProperties((ActivationSpecImpl)c, type);
/* 170 */         setV6InboundProperties(theMQCF, (ActivationSpecImpl)c, type);
/*     */       }
/*     */       
/* 173 */       if ((c instanceof ManagedConnectionFactoryConfiguration)) {
/* 174 */         traceV6OutboundProperties((ManagedConnectionFactoryConfiguration)c, type);
/* 175 */         setV6OutboundProperties(theMQCF, (ManagedConnectionFactoryConfiguration)c, type);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */       if ((c.getProviderVersion().equalsIgnoreCase("UNSPECIFIED")) || (c.getProviderVersion().startsWith("7"))) {
/* 183 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory", "configuring a ConnectionFactory with provider version: " + c.getProviderVersion());
/* 184 */         traceV7GenericProperties(c, type);
/* 185 */         setV7GenericProperties(theMQCF, c, type);
/*     */         
/* 187 */         if ((c instanceof ManagedConnectionFactoryConfiguration)) {
/* 188 */           traceV7OutboundProperties((ManagedConnectionFactoryConfiguration)c, type);
/* 189 */           setV7OutboundProperties(theMQCF, (ManagedConnectionFactoryConfiguration)c, type);
/*     */         }
/*     */       }
/*     */       else {
/* 193 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory", "configuring a ConnectionFactory with provider version six");
/*     */         
/* 195 */         theMQCF.setStringProperty("XMSC_WMQ_PROVIDER_VERSION", c.getProviderVersion());
/*     */       }
/*     */       
/*     */       SSLSocketFactory s;
/*     */       
/* 200 */       if ((c.getSslSocketFactory() != null) && (c.getSslSocketFactory().trim().length() != 0))
/*     */       {
/* 202 */         s = SSLSocketFactoryHandler.instantiateSocketFactory(c.getSslSocketFactory());
/* 203 */         theMQCF.setObjectProperty("XMSC_WMQ_SSL_SOCKET_FACTORY", s);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 208 */       if ((c.getArbitraryProperties() != null) && (c.getArbitraryProperties().trim().length() != 0)) {
/* 209 */         setArbitraryProperties(c, theMQCF);
/*     */       }
/*     */       
/*     */ 
/* 213 */       theMQCF.setBooleanProperty("XMSC_WMQ_USE_CONNECTION_POOLING", false);
/*     */       
/* 215 */       theMQCF.setIntProperty("XMSC_WMQ_CLIENT_RECONNECT_OPTIONS", 33554432);
/*     */       
/*     */ 
/*     */ 
/* 219 */       return theMQCF;
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 223 */       JCATraceAdapter.traceException(this, "ConnectionFactoryBuilder", "createConnectionFactory()", je);
/* 224 */       throw je;
/*     */     }
/*     */     finally {
/* 227 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryBuilder", "createConnectionFactory()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JmsConnectionFactory constructJmsConnectionFactory(AbstractConfiguration c, boolean transacted, int type)
/*     */     throws JMSException
/*     */   {
/* 242 */     JmsFactoryFactory jmsFactory = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/* 243 */     JmsConnectionFactory theMQCF = null;
/*     */     
/* 245 */     if (transacted)
/*     */     {
/*     */ 
/* 248 */       int env = ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment();
/*     */       
/*     */ 
/* 251 */       TransportTypeEnum transportType = c.getTransportTypeEnum();
/* 252 */       if ((!$assertionsDisabled) && (transportType == TransportTypeEnum.BINDINGS_THEN_CLIENT)) { throw new AssertionError(Trace.ffstAssertion(this, "costructJmsConnectionFactory", "????????", new Object[] { "transport=>" + transportType, "config=>" + c, "transacted=>" + transacted }));
/*     */       }
/*     */       
/* 255 */       boolean tWASRRS = ((c instanceof ActivationSpecImpl)) && (transportType == TransportTypeEnum.BINDINGS) && ((env == 8) || (env == 16) || (env == 32));
/* 256 */       boolean libertyRRS = (transportType == TransportTypeEnum.BINDINGS) && (env == 184);
/* 257 */       boolean rrsRequired = (tWASRRS) || (libertyRRS);
/*     */       
/* 259 */       if (JCATraceAdapter.isOn) {
/* 260 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "tWASRRS=" + tWASRRS + " libertyRRS" + libertyRRS);
/*     */       }
/*     */       
/*     */ 
/* 264 */       if (rrsRequired)
/*     */       {
/*     */ 
/*     */ 
/* 268 */         int jmqiOptions = 0;
/*     */         
/*     */ 
/* 271 */         if (env == 32)
/*     */         {
/* 273 */           jmqiOptions |= 0x8;
/*     */         }
/*     */         
/* 276 */         switch (type) {
/*     */         case 2: 
/* 278 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating RRSQueueConnectionFactory");
/* 279 */           theMQCF = new MQRRSQueueConnectionFactory();
/* 280 */           break;
/*     */         case 3: 
/* 282 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating RRSTopicConnectionFactory");
/* 283 */           theMQCF = new MQRRSTopicConnectionFactory();
/* 284 */           break;
/*     */         default: 
/* 286 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating RRSConnectionFactory");
/* 287 */           theMQCF = new MQRRSConnectionFactory();
/*     */         }
/*     */         
/*     */         
/* 291 */         if (JCATraceAdapter.isOn) {
/* 292 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Setting JMQI Options to " + jmqiOptions);
/*     */         }
/* 294 */         theMQCF.setIntProperty("XMSC_WMQ_JMQI_OPTIONS", jmqiOptions);
/*     */       }
/*     */       else {
/* 297 */         switch (type) {
/*     */         case 2: 
/* 299 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating XAQueueConnectionFactory");
/* 300 */           theMQCF = jmsFactory.createXAQueueConnectionFactory();
/* 301 */           break;
/*     */         case 3: 
/* 303 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating XATopicConnectionFactory");
/* 304 */           theMQCF = jmsFactory.createXATopicConnectionFactory();
/* 305 */           break;
/*     */         default: 
/* 307 */           JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating XAConnectionFactory");
/* 308 */           theMQCF = jmsFactory.createXAConnectionFactory();
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 314 */       switch (type) {
/*     */       case 2: 
/* 316 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating non-XA QueueConnectionFactory");
/* 317 */         theMQCF = jmsFactory.createQueueConnectionFactory();
/* 318 */         break;
/*     */       case 3: 
/* 320 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating non-XA TopicConnectionFactory");
/* 321 */         theMQCF = jmsFactory.createTopicConnectionFactory();
/* 322 */         break;
/*     */       default: 
/* 324 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Creating non-XA ConnectionFactory");
/* 325 */         theMQCF = jmsFactory.createConnectionFactory();
/*     */       }
/*     */       
/*     */     }
/* 329 */     return theMQCF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV6CrossDomainProperties(JmsConnectionFactory theMQCF, AbstractConfiguration c)
/*     */     throws JMSException
/*     */   {
/* 342 */     theMQCF.setIntProperty("XMSC_WMQ_QMGR_CCSID", c.getCCSID());
/*     */     
/* 344 */     theMQCF.setStringProperty("XMSC_CLIENT_ID", c.getClientId());
/*     */     
/* 346 */     theMQCF.setIntProperty("failIfQuiesce", c.getFailIfQuiesce() ? 1 : 0);
/*     */     
/* 348 */     theMQCF.setStringProperty("XMSC_WMQ_HOST_NAME", c.getHostName());
/*     */     
/* 350 */     theMQCF.setStringProperty("XMSC_WMQ_LOCAL_ADDRESS", c.getLocalAddress());
/*     */     
/* 352 */     theMQCF.setIntProperty("XMSC_WMQ_POLLING_INTERVAL", c.getPollingInterval());
/*     */     
/* 354 */     theMQCF.setIntProperty("XMSC_WMQ_PORT", c.getPort());
/*     */     
/* 356 */     theMQCF.setStringProperty("XMSC_WMQ_QUEUE_MANAGER", c.getQueueManager());
/*     */     
/* 358 */     theMQCF.setStringProperty("XMSC_WMQ_RECEIVE_EXIT", c.getReceiveExit());
/*     */     
/* 360 */     theMQCF.setStringProperty("XMSC_WMQ_RECEIVE_EXIT_INIT", c.getReceiveExitInit());
/*     */     
/* 362 */     theMQCF.setStringProperty("XMSC_WMQ_SECURITY_EXIT", c.getSecurityExit());
/*     */     
/* 364 */     theMQCF.setStringProperty("XMSC_WMQ_SECURITY_EXIT_INIT", c.getSecurityExitInit());
/*     */     
/* 366 */     theMQCF.setStringProperty("XMSC_WMQ_SEND_EXIT", c.getSendExit());
/*     */     
/* 368 */     theMQCF.setStringProperty("XMSC_WMQ_SEND_EXIT_INIT", c.getSendExitInit());
/*     */     
/* 370 */     theMQCF.setStringProperty("XMSC_WMQ_SSL_CERT_STORES_STR", c.getSslCertStores());
/*     */     
/* 372 */     theMQCF.setStringProperty("XMSC_WMQ_SSL_CIPHER_SUITE", c.getSslCipherSuite());
/*     */     
/* 374 */     theMQCF.setBooleanProperty("XMSC_WMQ_SSL_FIPS_REQUIRED", c.getSslFipsRequired());
/*     */     
/* 376 */     theMQCF.setStringProperty("XMSC_WMQ_SSL_PEER_NAME", c.getSslPeerName());
/*     */     
/* 378 */     theMQCF.setIntProperty("XMSC_WMQ_SSL_KEY_RESETCOUNT", c.getSslResetCount());
/*     */     
/* 380 */     c.getTransportTypeEnum().setProperties(theMQCF, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV6CrossDomainProperties(AbstractConfiguration c)
/*     */   {
/* 392 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "QmgrName: " + c.getQueueManager());
/*     */     
/* 394 */     if (c.getTransportTypeEnum() == TransportTypeEnum.BINDINGS) {
/* 395 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "Bindings Connection");
/*     */     }
/*     */     else
/*     */     {
/* 399 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "Client Connection (" + c.getTransportTypeEnum() + ")");
/*     */       
/* 401 */       if (c.getCcdtURL() == null) {
/* 402 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "Host   : " + c.getHostName());
/* 403 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "Port   : " + c.getPort());
/* 404 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "Channel: " + c.getChannel());
/*     */         
/* 406 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SSLCipherSuite : " + c.getSslCipherSuite());
/*     */       }
/*     */       else
/*     */       {
/* 410 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "CCDT URL: " + c.getCcdtURL());
/*     */       }
/*     */       
/* 413 */       if (c.getSslCipherSuite() != null) {
/* 414 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SSLCertStores  : " + c.getSslCertStores());
/* 415 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SSLFipsRequired: " + c.getSslFipsRequired());
/* 416 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SSLPeerName    : " + c.getSslPeerName());
/* 417 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SSLResetCount  : " + c.getSslResetCount());
/*     */       }
/*     */       
/*     */ 
/* 421 */       if (c.getReceiveExit() != null) {
/* 422 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "ReceiveExit     : " + c.getReceiveExit());
/* 423 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "ReceiveExitInit : " + c.getReceiveExitInit());
/*     */       }
/*     */       
/* 426 */       if (c.getSendExit() != null) {
/* 427 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SendExit        : " + c.getSendExit());
/* 428 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SendExitInit    : " + c.getSendExitInit());
/*     */       }
/*     */       
/* 431 */       if (c.getSecurityExit() != null) {
/* 432 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SecurityExit     : " + c.getSecurityExit());
/* 433 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "SecurityExitInit : " + c.getSecurityExitInit());
/*     */       }
/*     */       
/*     */ 
/* 437 */       if (!"NONE".equals(c.getHeaderCompression())) {
/* 438 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "headerCompression:  " + c.getHeaderCompression());
/*     */       }
/*     */       
/* 441 */       if (!"NONE".equals(c.getMessageCompression())) {
/* 442 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "messageCompression: " + c.getMessageCompression());
/*     */       }
/*     */       
/* 445 */       if (c.getLocalAddress() != null) {
/* 446 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "localAddress    : " + c.getLocalAddress());
/*     */       }
/*     */       
/*     */ 
/* 450 */       if (c.getPollingInterval() != 5000) {
/* 451 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "pollingInterval  : " + c.getPollingInterval());
/*     */       }
/*     */     }
/*     */     
/* 455 */     if (!c.getFailIfQuiesce()) {
/* 456 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "failIfQuiesce      : disabled");
/*     */     }
/*     */     
/* 459 */     if (c.getPollingInterval() != 5000) {
/* 460 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6CrossDomainProperties()", "pollingInterval    : " + c.getPollingInterval());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV6PointToPointProperties(JmsConnectionFactory theMQCF, AbstractConfiguration c)
/*     */     throws JMSException
/*     */   {
/* 474 */     theMQCF.setIntProperty("XMSC_WMQ_RESCAN_INTERVAL", c.getRescanInterval());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV6PointToPointProperties(AbstractConfiguration c)
/*     */   {
/* 485 */     if (c.getRescanInterval() != 5000) {
/* 486 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PointToPointProperties()", "rescanInterval  : " + c.getRescanInterval());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV6PubSubProperties(JmsConnectionFactory theMQCF, AbstractConfiguration c)
/*     */     throws JMSException
/*     */   {
/* 500 */     theMQCF.setStringProperty("XMSC_WMQ_BROKER_CC_SUBQ", c.getBrokerCCSubQueue());
/*     */     
/* 502 */     theMQCF.setStringProperty("XMSC_WMQ_BROKER_CONTROLQ", c.getBrokerControlQueue());
/*     */     
/* 504 */     theMQCF.setStringProperty("XMSC_WMQ_BROKER_PUBQ", c.getBrokerPubQueue());
/*     */     
/* 506 */     theMQCF.setStringProperty("XMSC_WMQ_BROKER_QMGR", c.getBrokerQueueManager());
/*     */     
/*     */ 
/* 509 */     if ("1".equalsIgnoreCase(c.getBrokerVersion())) {
/* 510 */       theMQCF.setIntProperty("brokerVersion", 0);
/*     */     }
/*     */     else {
/* 513 */       theMQCF.setIntProperty("brokerVersion", 1);
/*     */     }
/*     */     
/* 516 */     theMQCF.setLongProperty("XMSC_WMQ_CLEANUP_INTERVAL", c.getCleanupInterval());
/*     */     
/*     */ 
/* 519 */     c.getCleanupLevelEnum().setProperty(theMQCF);
/*     */     
/*     */ 
/*     */ 
/* 523 */     if ("DISABLED".equalsIgnoreCase(c.getCloneSupport())) {
/* 524 */       theMQCF.setIntProperty("XMSC_WMQ_CLONE_SUPPORT", 0);
/*     */     }
/*     */     else {
/* 527 */       theMQCF.setIntProperty("XMSC_WMQ_CLONE_SUPPORT", 1);
/*     */     }
/*     */     
/*     */ 
/* 531 */     if ("CLIENT".equalsIgnoreCase(c.getMessageSelection())) {
/* 532 */       theMQCF.setIntProperty("XMSC_WMQ_MESSAGE_SELECTION", 0);
/*     */     }
/*     */     else {
/* 535 */       theMQCF.setIntProperty("XMSC_WMQ_MESSAGE_SELECTION", 1);
/*     */     }
/*     */     
/*     */ 
/* 539 */     if ("FALSE".equalsIgnoreCase(c.getSparseSubscriptions())) {
/* 540 */       theMQCF.setBooleanProperty("XMSC_WMQ_SPARSE_SUBSCRIPTIONS", false);
/*     */     }
/*     */     else {
/* 543 */       theMQCF.setBooleanProperty("XMSC_WMQ_SPARSE_SUBSCRIPTIONS", true);
/*     */     }
/*     */     
/* 546 */     c.getSubscriptionStoreEnum().setProperty(theMQCF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV6PubSubProperties(AbstractConfiguration c)
/*     */   {
/* 557 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "BrokerVersion: " + c.getBrokerVersion());
/*     */     
/* 559 */     if (!"XMSC_WMQ_BROKER_CC_SUBQ".equals(c.getBrokerCCSubQueue())) {
/* 560 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "BrokerCCSubQueue   : " + c.getBrokerCCSubQueue());
/*     */     }
/* 562 */     if (!"XMSC_WMQ_BROKER_CONTROLQ".equals(c.getBrokerControlQueue())) {
/* 563 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "BrokerControlQueue : " + c.getBrokerControlQueue());
/*     */     }
/* 565 */     if (!"XMSC_WMQ_BROKER_PUBQ".equals(c.getBrokerPubQueue())) {
/* 566 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "BrokerPubQueue     : " + c.getBrokerPubQueue());
/*     */     }
/* 568 */     if ((c.getBrokerQueueManager() != null) && (c.getBrokerQueueManager().trim().length() != 0)) {
/* 569 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "BrokerQueueManager : " + c.getBrokerQueueManager());
/*     */     }
/*     */     
/* 572 */     if (c.getCleanupInterval() != 3600000L) {
/* 573 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "cleanupInterval    : " + c.getCleanupInterval());
/*     */     }
/* 575 */     if (c.getCleanupLevelEnum() != CleanupLevelEnum.SAFE) {
/* 576 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "cleanupLevel       : " + c.getCleanupLevelEnum());
/*     */     }
/* 578 */     if (!"DISABLED".equalsIgnoreCase(c.getCloneSupport())) {
/* 579 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "cloneSupport       : " + c.getCloneSupport());
/*     */     }
/*     */     
/* 582 */     if (!"CLIENT".equalsIgnoreCase(c.getMessageSelection())) {
/* 583 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "messageSelection   : " + c.getMessageSelection());
/*     */     }
/* 585 */     if (!"FALSE".equalsIgnoreCase(c.getSparseSubscriptions())) {
/* 586 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "sparseSubscriptions: " + c.getSparseSubscriptions());
/*     */     }
/* 588 */     if (c.getStatusRefreshInterval() != 60000) {
/* 589 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "statusRefreshInterval: " + c.getStatusRefreshInterval());
/*     */     }
/* 591 */     if (c.getSubscriptionStoreEnum() != SubscriptionStoreEnum.MIGRATE) {
/* 592 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6PubSubProperties()", "subscriptionStore  : " + c.getSubscriptionStoreEnum());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV6InboundProperties(JmsConnectionFactory theMQCF, ActivationSpecImpl c, int type)
/*     */     throws JMSException
/*     */   {
/* 606 */     theMQCF.setIntProperty("XMSC_WMQ_MSG_BATCH_SIZE", c.getMessageBatchSize());
/*     */     
/* 608 */     if (type != 3) {
/* 609 */       if ("NO".equals(c.getMessageRetention())) {
/* 610 */         theMQCF.setIntProperty("XMSC_WMQ_MESSAGE_RETENTION", 0);
/*     */       }
/*     */       else {
/* 613 */         theMQCF.setIntProperty("XMSC_WMQ_MESSAGE_RETENTION", 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV6InboundProperties(ActivationSpecImpl c, int type)
/*     */   {
/* 627 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6InboundProperties()", "Setting properties from an ActivationSpec object ");
/*     */     
/*     */ 
/* 630 */     if (c.getMessageBatchSize() != 10) {
/* 631 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6InboundProperties()", "messageBatchSize: " + c.getMessageBatchSize());
/*     */     }
/*     */     
/* 634 */     if ((type != 3) && 
/* 635 */       (!"YES".equals(c.getMessageRetention()))) {
/* 636 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6InboundProperties()", "messageRetention: " + c.getMessageRetention());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV6OutboundProperties(JmsConnectionFactory theMQCF, ManagedConnectionFactoryConfiguration c, int type)
/*     */     throws JMSException
/*     */   {
/* 651 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "createConnectionFactory()", "Setting properties from a ManagedConnectionFactory object");
/*     */     
/* 653 */     if (type != 2)
/*     */     {
/* 655 */       theMQCF.setIntProperty("XMSC_WMQ_PUB_ACK_INTERVAL", c.getPubAckInterval());
/*     */     }
/*     */     
/* 658 */     if (type != 3)
/*     */     {
/* 660 */       theMQCF.setStringProperty("XMSC_WMQ_TEMPORARY_MODEL", c.getTemporaryModel());
/*     */       
/* 662 */       theMQCF.setStringProperty("XMSC_WMQ_TEMP_Q_PREFIX", c.getTempQPrefix());
/*     */       
/* 664 */       theMQCF.setBooleanProperty("XMSC_WMQ_TARGET_CLIENT_MATCHING", c.getTargetClientMatching());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV6OutboundProperties(ManagedConnectionFactoryConfiguration c, int type)
/*     */   {
/* 677 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6OutboundProperties()", "Setting properties from a ManagedConnectionFactory object");
/*     */     
/*     */ 
/* 680 */     if ((type != 2) && 
/* 681 */       (c.getPubAckInterval() != 25)) {
/* 682 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6OutboundProperties()", "pubAckInterval     : " + c.getPubAckInterval());
/*     */     }
/*     */     
/*     */ 
/* 686 */     if (type != 3)
/*     */     {
/* 688 */       if ((c.getTemporaryModel() != null) && (c.getTemporaryModel().trim().length() != 0)) {
/* 689 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6OutboundProperties()", "temporaryModel     : " + c.getTemporaryModel());
/*     */       }
/*     */       
/* 692 */       if ((c.getTempQPrefix() != null) && (c.getTempQPrefix().trim().length() != 0)) {
/* 693 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6OutboundProperties()", "tempQPrefix        : " + c.getTempQPrefix());
/*     */       }
/*     */       
/* 696 */       if (c.getTargetClientMatching() != true) {
/* 697 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV6OutboundProperties()", "targetClientMatching  : disabled");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV7GenericProperties(JmsConnectionFactory theMQCF, AbstractConfiguration c, int type)
/*     */     throws JMSException
/*     */   {
/* 713 */     if ("UNSPECIFIED".equalsIgnoreCase(c.getProviderVersion())) {
/* 714 */       theMQCF.setStringProperty("XMSC_WMQ_PROVIDER_VERSION", "unspecified");
/*     */     }
/*     */     else {
/* 717 */       theMQCF.setStringProperty("XMSC_WMQ_PROVIDER_VERSION", c.getProviderVersion());
/*     */     }
/*     */     
/*     */ 
/* 721 */     c.getReadAheadAllowedEnum().setProperty(theMQCF);
/*     */     
/*     */ 
/* 724 */     if ("YES".equals(c.getShareConvAllowedCanonical())) {
/* 725 */       theMQCF.setIntProperty("XMSC_WMQ_SHARE_CONV_ALLOWED", 1);
/*     */     }
/*     */     else {
/* 728 */       theMQCF.setIntProperty("XMSC_WMQ_SHARE_CONV_ALLOWED", 0);
/*     */     }
/* 730 */     if (type != 2)
/*     */     {
/* 732 */       if ("TOPIC".equals(c.getWildcardFormat())) {
/* 733 */         theMQCF.setIntProperty("wildcardFormat", 0);
/*     */       }
/*     */       else {
/* 736 */         theMQCF.setIntProperty("wildcardFormat", 1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 744 */     if (!"localhost(1414)".equalsIgnoreCase(c.getConnectionNameList())) {
/* 745 */       theMQCF.setStringProperty("XMSC_WMQ_CONNECTION_NAME_LIST", c.getConnectionNameList());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV7GenericProperties(AbstractConfiguration c, int type)
/*     */   {
/* 758 */     if (c.getApplicationName() != null) {
/* 759 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7GenericParameters()", "applicationName: " + c.getApplicationName());
/*     */     }
/*     */     
/* 762 */     if (c.getReadAheadAllowedEnum() != ReadAheadAllowedEnum.AS_DEST) {
/* 763 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7GenericParameters()", "readAheadAllowed: " + c.getReadAheadAllowedEnum());
/*     */     }
/*     */     
/* 766 */     if (!"YES".equals(c.getShareConvAllowedCanonical())) {
/* 767 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7GenericParameters()", "shareConvAllowed: " + c.getShareConvAllowedCanonical());
/*     */     }
/* 769 */     if (type != 2)
/*     */     {
/* 771 */       if (!"TOPIC".equals(c.getWildcardFormat())) {
/* 772 */         JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7GenericParameters()", "wildcardFormat: " + c.getWildcardFormat());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 777 */     if (!"localhost(1414)".equalsIgnoreCase(c.getConnectionNameList())) {
/* 778 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7GenericParameters()", "connectionNameList: " + c.getConnectionNameList());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setV7OutboundProperties(JmsConnectionFactory theMQCF, ManagedConnectionFactoryConfiguration c, int type)
/*     */     throws JMSException
/*     */   {
/* 793 */     c.getPutAsyncAllowedEnum().setProperty(theMQCF);
/*     */     
/*     */ 
/* 796 */     theMQCF.setIntProperty("XMSC_WMQ_SEND_CHECK_COUNT", c.getSendCheckCount());
/* 797 */     if (type != 2)
/*     */     {
/* 799 */       theMQCF.setStringProperty("XMSC_WMQ_TEMP_TOPIC_PREFIX", c.getTempTopicPrefix());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceV7OutboundProperties(ManagedConnectionFactoryConfiguration c, int type)
/*     */   {
/* 812 */     if (c.getPutAsyncAllowedEnum() != PutAsyncAllowedEnum.AS_DEST) {
/* 813 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7OutboundParameters()", "putAsyncAllowed: " + c.getPutAsyncAllowedEnum());
/*     */     }
/*     */     
/* 816 */     if (c.getSendCheckCount() != 0) {
/* 817 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7OutboundParameters()", "sendCheckCount: " + c.getSendCheckCount());
/*     */     }
/*     */     
/* 820 */     if ((type != 2) && 
/* 821 */       (c.getTempTopicPrefix() != null) && (c.getTempTopicPrefix().trim().length() != 0)) {
/* 822 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "traceV7OutboundParameters()", "tempTopicPrefix: " + c.getTempTopicPrefix());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setArbitraryProperties(AbstractConfiguration c, JmsConnectionFactory mqcf)
/*     */   {
/* 835 */     JCATraceAdapter.traceInfo(this, "ConnectionFactoryBuilder", "setArbitraryProperties()", "propeties string: " + c.getArbitraryProperties());
/* 836 */     CustomPropertyHandler.setCustomProperties(c, mqcf, false);
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/ConnectionFactoryBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */