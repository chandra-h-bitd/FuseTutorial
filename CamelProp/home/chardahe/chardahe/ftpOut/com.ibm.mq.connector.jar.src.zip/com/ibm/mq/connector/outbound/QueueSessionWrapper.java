/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.ArrayList;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueueSessionWrapper
/*     */   extends SessionWrapper
/*     */   implements QueueSession
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/QueueSessionWrapper.java";
/*     */   
/*     */   protected QueueSessionWrapper(QueueConnectionWrapper w, Session s)
/*     */     throws JMSException
/*     */   {
/*  66 */     super(w, s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QueueReceiver createReceiver(Queue arg0)
/*     */     throws JMSException
/*     */   {
/*  74 */     JCATraceAdapter.traceEntry(this, "QueueSessionWrapper", "createReceiver(...)");
/*     */     try {
/*  76 */       return createReceiver(arg0, null);
/*     */     }
/*     */     finally
/*     */     {
/*  80 */       JCATraceAdapter.traceExit(this, "QueueSessionWrapper", "createReceiver(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QueueReceiver createReceiver(Queue arg0, String arg1)
/*     */     throws JMSException
/*     */   {
/*  89 */     JCATraceAdapter.traceEntry(this, "QueueSessionWrapper", "createReceiver(...)");
/*     */     try
/*     */     {
/*  92 */       assertOpen();
/*     */       
/*  94 */       synchronized (this.theConnWrapper) {
/*  95 */         if (this.consumers == null) {
/*  96 */           this.consumers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 100 */       QueueReceiverWrapper qrw = new QueueReceiverWrapper(this, this.theSession, this.theConnWrapper.isManaged(), arg0, arg1);
/*     */       
/*     */ 
/* 103 */       this.consumers.add(qrw);
/*     */       
/* 105 */       return qrw;
/*     */     }
/*     */     finally
/*     */     {
/* 109 */       JCATraceAdapter.traceExit(this, "QueueSessionWrapper", "createReceiver(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QueueSender createSender(Queue arg0)
/*     */     throws JMSException
/*     */   {
/* 118 */     JCATraceAdapter.traceEntry(this, "QueueSessionWrapper", "createSender(...)");
/*     */     try
/*     */     {
/* 121 */       assertOpen();
/*     */       
/* 123 */       synchronized (this.theConnWrapper) {
/* 124 */         if (this.producers == null) {
/* 125 */           this.producers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 129 */       QueueSenderWrapper qsw = new QueueSenderWrapper(this, this.theSession, arg0);
/*     */       
/* 131 */       this.producers.add(qsw);
/*     */       
/* 133 */       return qsw;
/*     */     }
/*     */     finally
/*     */     {
/* 137 */       JCATraceAdapter.traceExit(this, "QueueSessionWrapper", "createSender(...)");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/QueueSessionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */