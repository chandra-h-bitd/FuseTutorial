package com.ibm.mq.connector;

import com.ibm.mq.jms.MessageReferenceHandler;
import com.ibm.msg.client.commonservices.cssystem.WASSupport.WASRuntimeHelper;
import java.util.Map;
import javax.jms.Connection;
import javax.jms.ConnectionConsumer;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageListener;
import javax.jms.ServerSessionPool;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.InvalidPropertyException;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

public abstract interface JCARuntimeHelper
  extends WASSupport.WASRuntimeHelper
{
  public static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2009 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  public static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/JCARuntimeHelper.java";
  public static final String ACTIVATION_SPEC = "ACTIVATION_SPEC";
  
  public abstract Map processArbitraryProperties(Map paramMap, ConnectionFactory paramConnectionFactory)
    throws InvalidPropertyException;
  
  public abstract Map processArbitraryProperties(Map paramMap, Destination paramDestination)
    throws InvalidPropertyException;
  
  public abstract void clearActivationSpecificationInformation(Object paramObject);
  
  public abstract MessageReferenceHandler getCraMessageReferenceHandler(MessageEndpointFactory paramMessageEndpointFactory, ActivationSpec paramActivationSpec, String paramString1, String paramString2)
    throws JMSException, javax.jms.IllegalStateException;
  
  public abstract String resolveConnection(Connection paramConnection);
  
  public abstract ConnectionConsumer getSrConnectionConsumer(MessageEndpointFactory paramMessageEndpointFactory, ActivationSpec paramActivationSpec, Connection paramConnection, Destination paramDestination, String paramString, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException, javax.jms.IllegalStateException;
  
  public abstract boolean isSystemMessageListener(MessageListener paramMessageListener);
  
  public abstract void deliveryFailed(Exception paramException, ActivationSpec paramActivationSpec, MessageEndpointFactory paramMessageEndpointFactory, boolean paramBoolean);
  
  public abstract void startRRSTransaction()
    throws java.lang.IllegalStateException, RollbackException, SystemException;
  
  public abstract void startLocalRRSTransaction()
    throws java.lang.IllegalStateException;
  
  public abstract void endLocalRRSTransaction()
    throws java.lang.IllegalStateException, RollbackException;
}


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/JCARuntimeHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */