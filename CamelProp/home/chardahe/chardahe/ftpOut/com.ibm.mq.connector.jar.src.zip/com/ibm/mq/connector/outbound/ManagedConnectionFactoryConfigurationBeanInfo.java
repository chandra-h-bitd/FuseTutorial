/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.AbstractConfigurationBeanInfo;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedConnectionFactoryConfigurationBeanInfo
/*     */   extends AbstractConfigurationBeanInfo
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedConnectionFactoryConfigurationBeanInfo.java";
/*  62 */   private static Class beanClass = ManagedConnectionFactoryConfiguration.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescriptor getBeanDescriptor()
/*     */   {
/*  72 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryConfigurationBeanInfo", "getBeanDescriptor()");
/*     */     
/*     */     try
/*     */     {
/*  76 */       return new BeanDescriptor(beanClass);
/*     */     }
/*     */     finally {
/*  79 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryConfigurationBeanInfo", "getBeanDescriptor()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/*  93 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  98 */       PropertyDescriptor[] common = super.getPropertyDescriptors();
/*     */       
/* 100 */       pubAckInterval = new PropertyDescriptor("pubAckInterval", beanClass);
/* 101 */       pubAckInterval.setExpert(true);
/*     */       
/* 103 */       PropertyDescriptor targetClientMatching = new PropertyDescriptor("targetClientMatching", beanClass);
/*     */       
/* 105 */       targetClientMatching.setExpert(true);
/*     */       
/* 107 */       PropertyDescriptor temporaryModel = new PropertyDescriptor("temporaryModel", beanClass);
/* 108 */       temporaryModel.setExpert(true);
/*     */       
/* 110 */       PropertyDescriptor tempQueuePrefix = new PropertyDescriptor("tempQPrefix", beanClass);
/* 111 */       tempQueuePrefix.setExpert(true);
/*     */       
/* 113 */       PropertyDescriptor putAsyncAllowed = new PropertyDescriptor("putAsyncAllowed", beanClass);
/* 114 */       putAsyncAllowed.setExpert(true);
/*     */       
/* 116 */       PropertyDescriptor sendCheckCount = new PropertyDescriptor("sendCheckCount", beanClass);
/* 117 */       sendCheckCount.setExpert(true);
/*     */       
/* 119 */       PropertyDescriptor tempTopicPrefix = new PropertyDescriptor("tempTopicPrefix", beanClass);
/* 120 */       tempTopicPrefix.setExpert(true);
/*     */       
/* 122 */       PropertyDescriptor[] result = null;
/*     */       
/*     */       PropertyDescriptor[] rv;
/* 125 */       if (common != null)
/*     */       {
/* 127 */         rv = new PropertyDescriptor[] { pubAckInterval, putAsyncAllowed, sendCheckCount, targetClientMatching, temporaryModel, tempQueuePrefix, tempTopicPrefix };
/*     */         
/*     */ 
/*     */ 
/* 131 */         result = new PropertyDescriptor[common.length + rv.length];
/* 132 */         System.arraycopy(common, 0, result, 0, common.length);
/* 133 */         System.arraycopy(rv, 0, result, common.length, rv.length);
/*     */       }
/* 135 */       return result;
/*     */     }
/*     */     catch (IntrospectionException e) {
/*     */       PropertyDescriptor pubAckInterval;
/* 139 */       JCATraceAdapter.traceException(this, "ManagedConnectionFactoryConfigurationBeanInfo", "getPropertyDescriptors()", e);
/*     */       
/* 141 */       return null;
/*     */     }
/*     */     finally
/*     */     {
/* 145 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedConnectionFactoryConfigurationBeanInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */