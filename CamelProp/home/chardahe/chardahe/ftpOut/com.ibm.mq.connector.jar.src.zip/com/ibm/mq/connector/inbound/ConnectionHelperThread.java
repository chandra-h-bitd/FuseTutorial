/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionHelperThread
/*     */   implements Runnable
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ConnectionHelperThread.java";
/*  54 */   private MessageEndpointDeployment theMED = null;
/*     */   
/*     */ 
/*  57 */   private int retryCount = 0;
/*     */   
/*     */ 
/*  60 */   private int retryInterval = 0;
/*     */   
/*     */ 
/*  63 */   private int reconnectAttempts = 0;
/*     */   
/*     */ 
/*  66 */   private boolean successful = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionHelperThread(int retryCount, int retryInterval, MessageEndpointDeployment med)
/*     */   {
/*  77 */     JCATraceAdapter.traceEntry(this, "ConnectionHelperThread()", "<init>");
/*     */     
/*     */ 
/*  80 */     this.theMED = med;
/*  81 */     this.retryCount = retryCount;
/*  82 */     this.retryInterval = retryInterval;
/*     */     
/*     */ 
/*  85 */     JCATraceAdapter.traceExit(this, "ConnectionHelperThread()", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*  96 */     if (JCATraceAdapter.isOn) {
/*  97 */       JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "ConnectionHelperThread running");
/*     */     }
/*     */     
/* 100 */     while ((!this.successful) && (this.reconnectAttempts < this.retryCount))
/*     */     {
/* 102 */       boolean failed = false;
/*     */       Throwable loopException;
/*     */       try {
/* 105 */         this.theMED.acquireConnection();
/*     */         
/* 107 */         if (JCATraceAdapter.isOn) {
/* 108 */           JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "connected " + this.theMED);
/*     */         }
/*     */         
/*     */       }
/*     */       catch (ResourceAdapterInternalException rfe)
/*     */       {
/* 114 */         failed = true;
/* 115 */         loopException = rfe; }
/* 116 */       while (loopException != null) {
/* 117 */         if (((loopException instanceof JMSException)) && (((JMSException)loopException).getErrorCode() == "MQJMS3023")) {
/* 118 */           failed = false;
/* 119 */           if (JCATraceAdapter.isOn) {
/* 120 */             JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "Already subscribed, not retrying");
/*     */           }
/*     */         }
/* 123 */         loopException = loopException.getCause();
/*     */       }
/*     */       
/*     */ 
/* 127 */       if (failed)
/*     */       {
/* 129 */         this.reconnectAttempts += 1;
/* 130 */         if (JCATraceAdapter.isOn) {
/* 131 */           JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "tried " + this.reconnectAttempts + " of " + this.retryCount + "reconnection attempts");
/*     */         }
/*     */         
/* 134 */         if (this.reconnectAttempts < this.retryCount)
/*     */         {
/* 136 */           if (JCATraceAdapter.isOn) {
/* 137 */             JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "ConnectionHelperThread sleeping for " + this.retryInterval + " milliseconds");
/*     */           }
/*     */           try
/*     */           {
/* 141 */             Thread.sleep(this.retryInterval);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/* 145 */             JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "ConnectionHelperThread interrupted");
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 150 */         if (JCATraceAdapter.isOn) {
/* 151 */           JCATraceAdapter.traceInfo(this, "ConnectionHelperThread", "run()", "connection successful");
/*     */         }
/*     */         
/* 154 */         this.successful = true;
/*     */       }
/*     */     }
/*     */     
/* 158 */     if (!this.successful)
/*     */     {
/* 160 */       JCAMessageBuilder.buildWarning("MQJCA4014");
/*     */     }
/*     */     else
/*     */     {
/* 164 */       this.theMED.connectionComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ConnectionHelperThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */