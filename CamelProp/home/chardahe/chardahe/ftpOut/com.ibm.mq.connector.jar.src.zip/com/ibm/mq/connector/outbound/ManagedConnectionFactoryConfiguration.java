/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.AbstractConfiguration;
/*     */ import com.ibm.mq.connector.configuration.PutAsyncAllowedEnum;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import java.util.HashMap;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ import javax.resource.spi.ResourceAdapter;
/*     */ import javax.resource.spi.ResourceAdapterAssociation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedConnectionFactoryConfiguration
/*     */   extends AbstractConfiguration
/*     */   implements ResourceAdapterAssociation
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedConnectionFactoryConfiguration.java";
/*     */   private static final long serialVersionUID = 4815162342L;
/*  65 */   private boolean targetClientMatching = true;
/*     */   
/*     */ 
/*  68 */   private int pubAckInterval = 25;
/*     */   
/*     */ 
/*  71 */   private String temporaryModel = "SYSTEM.DEFAULT.MODEL.QUEUE";
/*     */   
/*     */ 
/*  74 */   private String tempQPrefix = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private PutAsyncAllowedEnum putAsyncAllowed = PutAsyncAllowedEnum.AS_DEST;
/*     */   
/*     */ 
/*  86 */   private String badPutAsyncAllowedString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private int sendCheckCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private String tempTopicPrefix = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private ResourceAdapter theAssociatedResourceAdapter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceAdapter(ResourceAdapter ra)
/*     */   {
/* 116 */     if (this.theAssociatedResourceAdapter == null) {
/* 117 */       this.theAssociatedResourceAdapter = ra;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceAdapter getResourceAdapter()
/*     */   {
/* 128 */     return this.theAssociatedResourceAdapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetClientMatching(boolean targetClientMatching)
/*     */   {
/* 139 */     this.targetClientMatching = targetClientMatching;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetClientMatching(String targetClientMatching)
/*     */   {
/* 149 */     this.targetClientMatching = ((targetClientMatching != null) && (targetClientMatching.equalsIgnoreCase("true")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getTargetClientMatching()
/*     */   {
/* 156 */     return this.targetClientMatching;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPubAckInterval(int pubAckInterval)
/*     */   {
/* 163 */     this.pubAckInterval = pubAckInterval;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPubAckInterval(String s)
/*     */   {
/*     */     try
/*     */     {
/* 171 */       this.pubAckInterval = Integer.parseInt(s);
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/* 175 */       this.inserts.clear();
/* 176 */       this.inserts.put("JCA_CONFIG_PROPERTY", "pubAckInterval");
/* 177 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 178 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.pubAckInterval));
/*     */       
/* 180 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPubAckInterval()
/*     */   {
/* 188 */     return this.pubAckInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemporaryModel(String model)
/*     */   {
/* 197 */     this.temporaryModel = model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemporaryModel()
/*     */   {
/* 206 */     return this.temporaryModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTempQPrefix(String tempQPrefix)
/*     */   {
/* 213 */     this.tempQPrefix = tempQPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTempQPrefix()
/*     */   {
/* 220 */     return this.tempQPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPutAsyncAllowed(String putAsyncAllowedString)
/*     */   {
/* 234 */     PutAsyncAllowedEnum putAsyncAllowedValue = PutAsyncAllowedEnum.byTag(putAsyncAllowedString);
/* 235 */     if (putAsyncAllowedValue != null) {
/* 236 */       this.putAsyncAllowed = putAsyncAllowedValue;
/*     */     }
/*     */     else {
/* 239 */       this.badPutAsyncAllowedString = putAsyncAllowedString;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PutAsyncAllowedEnum getPutAsyncAllowedEnum()
/*     */   {
/* 249 */     return this.putAsyncAllowed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPutAsyncAllowed()
/*     */   {
/* 258 */     return this.putAsyncAllowed.getTag();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSendCheckCount(int sendCheckCount)
/*     */   {
/* 268 */     this.sendCheckCount = sendCheckCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSendCheckCount(String s)
/*     */   {
/*     */     try
/*     */     {
/* 278 */       setSendCheckCount(Integer.parseInt(s));
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/* 282 */       this.inserts.clear();
/* 283 */       this.inserts.put("JCA_CONFIG_PROPERTY", "sendCheckCount");
/* 284 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 285 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.sendCheckCount));
/*     */       
/* 287 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSendCheckCount()
/*     */   {
/* 297 */     return this.sendCheckCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTempTopicPrefix(String tempTopicPrefix)
/*     */   {
/* 306 */     this.tempTopicPrefix = tempTopicPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTempTopicPrefix()
/*     */   {
/* 315 */     return this.tempTopicPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate()
/*     */     throws InvalidPropertyException
/*     */   {
/* 331 */     super.validate();
/*     */     
/*     */ 
/* 334 */     if (this.pubAckInterval < 0)
/*     */     {
/* 336 */       this.inserts.clear();
/* 337 */       this.inserts.put("JCA_CONFIG_PROPERTY", "pubAckInterval");
/* 338 */       this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.pubAckInterval));
/*     */       
/* 340 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*     */     }
/*     */     
/*     */ 
/* 344 */     if (this.badPutAsyncAllowedString != null)
/*     */     {
/* 346 */       this.inserts.clear();
/* 347 */       this.inserts.put("JCA_CONFIG_PROPERTY", "putAsyncAllowed");
/* 348 */       this.inserts.put("JCA_CONFIG_VALUE", this.badPutAsyncAllowedString);
/*     */       
/* 350 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*     */     }
/*     */     
/* 353 */     if (this.sendCheckCount < 0)
/*     */     {
/* 355 */       this.inserts.clear();
/* 356 */       this.inserts.put("JCA_CONFIG_PROPERTY", "sendCheckCount");
/* 357 */       this.inserts.put("JCA_CONFIG_VALUE", new Integer(this.sendCheckCount));
/*     */       
/* 359 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", this.inserts, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean compareQueueManagers(AbstractConfiguration b)
/*     */   {
/* 379 */     boolean theSame = super.compareQueueManagers(b);
/*     */     
/* 381 */     if (theSame) {
/* 382 */       if ((b instanceof ManagedConnectionFactoryConfiguration))
/*     */       {
/*     */ 
/* 385 */         ManagedConnectionFactoryConfiguration mc = (ManagedConnectionFactoryConfiguration)b;
/* 386 */         theSame = (this.pubAckInterval == mc.getPubAckInterval()) && (this.putAsyncAllowed == mc.putAsyncAllowed) && (this.sendCheckCount == mc.getSendCheckCount()) && (this.targetClientMatching == mc.getTargetClientMatching()) && (this.temporaryModel != null ? this.temporaryModel.equalsIgnoreCase(mc.getTemporaryModel()) : mc.getTemporaryModel() == null) && (this.tempQPrefix != null ? this.tempQPrefix.equalsIgnoreCase(mc.getTempQPrefix()) : mc.getTempQPrefix() == null) && (this.tempTopicPrefix != null ? this.tempTopicPrefix.equalsIgnoreCase(mc.getTempTopicPrefix()) : mc.getTempTopicPrefix() == null);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 394 */         theSame = false;
/*     */       }
/*     */     }
/*     */     
/* 398 */     return theSame;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedConnectionFactoryConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */