/*     */ package com.ibm.mq.connector.configuration;
/*     */ 
/*     */ import com.ibm.mq.connector.AbstractConfiguration;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TransportTypeEnum
/*     */ {
/*  42 */   BINDINGS("BINDINGS", "XMSC_WMQ_CONNECTION_MODE", 0), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   BINDINGS_THEN_CLIENT("BINDINGS_THEN_CLIENT", "XMSC_WMQ_CONNECTION_MODE", 8), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   CLIENT("CLIENT", "XMSC_WMQ_CONNECTION_MODE", 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/configuration/TransportTypeEnum.java";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String tag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String property;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int propertyValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final ThreadLocal<HashMap<String, Object>> inserts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HashMap<String, TransportTypeEnum> lookup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TransportTypeEnum(String tag, String property, int propertyValue)
/*     */   {
/* 176 */     this.tag = tag;
/* 177 */     this.property = property;
/* 178 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String normalizeString(String s)
/*     */   {
/* 187 */     return s.trim().length() == 0 ? null : s == null ? null : s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void validateChannelProperties(AbstractConfiguration abstractConfiguration)
/*     */     throws InvalidPropertyException
/*     */   {
/* 195 */     if (abstractConfiguration.getPort() <= 0) {
/* 196 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", buildInserts("port", Integer.valueOf(abstractConfiguration.getPort())), null));
/*     */     }
/*     */     
/*     */ 
/* 200 */     if (abstractConfiguration.getHostName() == null) {
/* 201 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", buildInserts("hostName", "null"), null));
/*     */     }
/*     */     
/*     */ 
/* 205 */     if (abstractConfiguration.getSslResetCount() < 0) {
/* 206 */       throw ((InvalidPropertyException)JCAExceptionBuilder.buildException(2, "MQJCA3001", buildInserts("sslResetCount", Integer.valueOf(abstractConfiguration.getSslResetCount())), null));
/*     */     }
/*     */     
/*     */ 
/* 210 */     String sslSocketFactory = abstractConfiguration.getSslSocketFactory();
/*     */     
/* 212 */     if ((sslSocketFactory != null) && (sslSocketFactory.trim().length() != 0)) {
/* 213 */       abstractConfiguration.validateSslSocketFactory(sslSocketFactory);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HashMap<String, Object> buildInserts(String property, Object value)
/*     */   {
/* 230 */     HashMap<String, Object> result = (HashMap)inserts.get();
/*     */     
/* 232 */     result.put("JCA_CONFIG_PROPERTY", property);
/* 233 */     result.put("JCA_CONFIG_VALUE", value);
/* 234 */     return result;
/*     */   }
/*     */   
/*     */   static
/*     */   {
/* 220 */     inserts = new ThreadLocal()
/*     */     {
/*     */       protected HashMap<String, Object> initialValue()
/*     */       {
/* 224 */         return new HashMap(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */     };
/* 242 */     lookup = new HashMap();
/* 243 */     for (TransportTypeEnum e : values()) {
/* 244 */       lookup.put(e.tag, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TransportTypeEnum byTag(String tag)
/*     */   {
/* 254 */     return (TransportTypeEnum)lookup.get(tag.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperties(JmsPropertyContext context, AbstractConfiguration abstractConfiguration)
/*     */     throws JMSException
/*     */   {
/* 266 */     context.setIntProperty(this.property, this.propertyValue);
/* 267 */     setDependentProperties(context, abstractConfiguration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTag()
/*     */   {
/* 284 */     return this.tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 292 */     return this.tag;
/*     */   }
/*     */   
/*     */   private static void setCompressionProperties(JmsPropertyContext context, AbstractConfiguration abstractConfiguration) throws JMSException
/*     */   {
/* 297 */     context.setStringProperty("XMSC_WMQ_HEADER_COMP", abstractConfiguration.getHeaderCompression());
/* 298 */     context.setStringProperty("XMSC_WMQ_MSG_COMP", abstractConfiguration.getMessageCompression());
/*     */   }
/*     */   
/*     */   private static void setApplicationName(JmsPropertyContext context, AbstractConfiguration abstractConfiguration) throws JMSException
/*     */   {
/* 303 */     String applicationName = abstractConfiguration.getApplicationName();
/* 304 */     if (applicationName != null) {
/* 305 */       context.setStringProperty("XMSC_WMQ_APPNAME", applicationName);
/*     */     }
/*     */   }
/*     */   
/*     */   abstract void setDependentProperties(JmsPropertyContext paramJmsPropertyContext, AbstractConfiguration paramAbstractConfiguration)
/*     */     throws JMSException;
/*     */   
/*     */   public abstract void validate(AbstractConfiguration paramAbstractConfiguration)
/*     */     throws InvalidPropertyException;
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/configuration/TransportTypeEnum.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */