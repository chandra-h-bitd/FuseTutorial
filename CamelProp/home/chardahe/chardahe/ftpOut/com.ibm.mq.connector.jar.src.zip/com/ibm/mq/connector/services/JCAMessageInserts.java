package com.ibm.mq.connector.services;

public class JCAMessageInserts
{
  static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/JCAMessageInserts.java";
  public static final String CONFIG_PROPERTY = "JCA_CONFIG_PROPERTY";
  public static final String CONFIG_VALUE = "JCA_CONFIG_VALUE";
  public static final String CONFIG_DEFAULT = "JCA_CONFIG_DEFAULT";
  public static final String NLS_MESSAGE_ID = "JCA_NLS_MESSAGE_ID";
  public static final String PROPERTY_VALUE = "JCA_PROPERTY_VALUE";
  public static final String SSL_SOCKET_FACTORY = "JCA_SSL_SOCKET_FACTORY";
  public static final String CONNECTION_HANDLE = "JCA_CONNECTION_HANDLE";
  public static final String JMS_EXCEPTION = "JCA_JMS_EXCEPTION";
  public static final String CSI_EXCEPTION = "JCA_CSI_EXCEPTION";
  public static final String XA_EXCEPTION = "JCA_XA_EXCEPTION";
  public static final String MSG_ENDPOINT = "JCA_ENDPOINT";
  public static final String WORK_IMPL = "JCA_WORK_IMPL";
  public static final String METHOD_NAME = "JCA_METHOD_NAME";
}


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/JCAMessageInserts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */