/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.LocalTransaction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalTransactionImpl
/*     */   implements LocalTransaction
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/LocalTransactionImpl.java";
/*  55 */   private ManagedConnectionImpl theManagedConnection = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LocalTransactionImpl(ManagedConnectionImpl mc)
/*     */   {
/*  65 */     JCATraceAdapter.traceEntry(this, "LocalTransactionImpl", "<init>");
/*  66 */     this.theManagedConnection = mc;
/*  67 */     JCATraceAdapter.traceExit(this, "LocalTransactionImpl", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void begin()
/*     */     throws ResourceException
/*     */   {
/*  78 */     JCATraceAdapter.traceEntry(this, "LocalTransactionImpl", "begin()");
/*     */     try {
/*  80 */       this.theManagedConnection.beginLocalTransaction();
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/*  84 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*     */     }
/*     */     finally
/*     */     {
/*  88 */       JCATraceAdapter.traceExit(this, "LocalTransactionImpl", "begin()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void commit()
/*     */     throws ResourceException
/*     */   {
/*  98 */     JCATraceAdapter.traceEntry(this, "LocalTransactionImpl", "commit()");
/*     */     try {
/* 100 */       this.theManagedConnection.commitLocalTransaction();
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 104 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*     */     }
/*     */     finally
/*     */     {
/* 108 */       JCATraceAdapter.traceExit(this, "LocalTransactionImpl", "commit()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rollback()
/*     */     throws ResourceException
/*     */   {
/* 118 */     JCATraceAdapter.traceEntry(this, "LocalTransactionImpl", "rollback()");
/*     */     try {
/* 120 */       this.theManagedConnection.rollbackLocalTransaction();
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 124 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*     */     }
/*     */     finally
/*     */     {
/* 128 */       JCATraceAdapter.traceExit(this, "LocalTransactionImpl", "rollback()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/LocalTransactionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */