/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.io.Serializable;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.resource.Referenceable;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionFactoryImpl
/*     */   implements ConnectionFactory, Serializable, Referenceable
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ConnectionFactoryImpl.java";
/*  74 */   protected ConnectionManager theCM = null;
/*     */   
/*  76 */   protected ManagedConnectionFactoryImpl theMCF = null;
/*     */   
/*  78 */   protected ConnectionFactory theCF = null;
/*     */   
/*  80 */   private Reference theReference = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionFactoryImpl(ManagedConnectionFactoryImpl mcf)
/*     */   {
/*  91 */     this(mcf, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionFactoryImpl(ManagedConnectionFactoryImpl mcf, ConnectionManager cm)
/*     */   {
/* 103 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl()", "<init>");
/*     */     try {
/* 105 */       JCATraceAdapter.traceInfo(this, "ConnectionFactoryImpl()", "<init>", "ConnectionManager is " + (cm != null ? cm.toString() : "null"));
/*     */       
/*     */ 
/* 108 */       this.theMCF = mcf;
/*     */       
/* 110 */       this.theCM = cm;
/*     */     }
/*     */     finally
/*     */     {
/* 114 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl()", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Connection createConnection()
/*     */     throws JMSException
/*     */   {
/* 123 */     return createConnection(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection createConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 136 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "createConnection()");
/*     */     try {
/* 138 */       return createConnectionInternal(username, password);
/*     */     }
/*     */     finally
/*     */     {
/* 142 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "createConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */   final Connection createConnectionInternal(String username, String password) throws JMSException
/*     */   {
/* 148 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "createConnectionInternal()");
/*     */     try {
/*     */       Connection localConnection;
/* 151 */       if (this.theCM != null)
/*     */       {
/* 153 */         return createManagedJMSConnection(username, password);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 158 */       return createUnmanagedJMSConnection(username, password);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 163 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "createConnectionInternal()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Connection createManagedJMSConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 179 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "createManagedJMSConnection()");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 185 */       ConnectionRequestInfoImpl cri = null;
/*     */       
/*     */ 
/* 188 */       if (username != null) {
/* 189 */         cri = new ConnectionRequestInfoImpl();
/* 190 */         cri.setUsername(username);
/* 191 */         cri.setPassword(password);
/*     */       }
/*     */       
/* 194 */       return (Connection)this.theCM.allocateConnection(this.theMCF, cri);
/*     */ 
/*     */     }
/*     */     catch (ResourceException re)
/*     */     {
/* 199 */       Throwable cause = re.getCause();
/* 200 */       if (cause != null)
/*     */       {
/* 202 */         Package pkg = cause.getClass().getPackage();
/*     */         
/* 204 */         String pkgName = pkg != null ? pkg.getName() : null;
/* 205 */         if (pkgName == null)
/*     */         {
/*     */ 
/*     */ 
/* 209 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1011", cause));
/*     */         }
/*     */         
/* 212 */         if (pkgName.startsWith("javax.transaction")) {
/* 213 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1014", cause));
/*     */         }
/*     */         
/* 216 */         if (pkgName.startsWith("javax.jms"))
/*     */         {
/* 218 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA0001", cause));
/*     */         }
/*     */         
/* 221 */         if (pkgName.startsWith("com.ibm.mq"))
/*     */         {
/*     */ 
/* 224 */           throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA0002", cause));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 229 */         throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1011", cause));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */       throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1011", re));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 241 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "createManagedJMSConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Connection createUnmanagedJMSConnection(String username, String password)
/*     */     throws JMSException
/*     */   {
/* 257 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "createUnmanagedJMSConnection()");
/*     */     
/*     */     try
/*     */     {
/* 261 */       if (this.theCF == null) {
/* 262 */         this.theCF = this.theMCF.createConnectionFactory(1);
/*     */       }
/*     */       
/*     */ 
/* 266 */       return this.theCF.createConnection(username, password);
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 270 */       throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1011", je));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 275 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "createUnmanagedJMSConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(Reference ref)
/*     */   {
/* 284 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "setReference()");
/* 285 */     JCATraceAdapter.traceData(this, "ConnectionFactoryImpl", "setReference()", "reference: ", ref);
/*     */     
/* 287 */     this.theReference = ref;
/*     */     
/* 289 */     JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "setReference()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference getReference()
/*     */     throws NamingException
/*     */   {
/* 301 */     JCATraceAdapter.traceEntry(this, "ConnectionFactoryImpl", "getReference()");
/*     */     try
/*     */     {
/* 304 */       if (this.theReference == null) {
/* 305 */         throw new NamingException("ConnectionFactoryImpl reference is null");
/*     */       }
/*     */       
/* 308 */       return this.theReference;
/*     */     }
/*     */     finally
/*     */     {
/* 312 */       JCATraceAdapter.traceExit(this, "ConnectionFactoryImpl", "getReference()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ConnectionFactoryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */