/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.resource.spi.ConnectionEvent;
/*     */ import javax.resource.spi.ConnectionEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionEventHandler
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ConnectionEventHandler.java";
/*  56 */   private List listeners = null;
/*     */   
/*  58 */   private ManagedConnectionImpl theMC = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConnectionEventHandler(ManagedConnectionImpl mc)
/*     */   {
/*  67 */     JCATraceAdapter.traceEntry(this, "ConnectionEventHandler", "<init>");
/*     */     
/*  69 */     this.listeners = new ArrayList();
/*     */     
/*  71 */     this.theMC = mc;
/*     */     
/*  73 */     JCATraceAdapter.traceExit(this, "ConnectionEventHandler", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addListener(ConnectionEventListener cel)
/*     */   {
/*  82 */     JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "addListener()", "adding ConnectionEventListener: " + cel);
/*     */     
/*  84 */     this.listeners.add(cel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeListener(ConnectionEventListener cel)
/*     */   {
/*  93 */     JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "removeListener()", "removing ConnectionEventListener: " + cel);
/*     */     
/*  95 */     this.listeners.remove(cel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void fireEvent(int type, Object handle, Exception e)
/*     */   {
/* 107 */     JCATraceAdapter.traceEntry(this, "ConnectionEventHandler", "fireEvent(...)");
/*     */     
/*     */ 
/* 110 */     ConnectionEvent ce = null;
/* 111 */     if (e == null) {
/* 112 */       ce = new ConnectionEvent(this.theMC, type);
/*     */     }
/*     */     else {
/* 115 */       ce = new ConnectionEvent(this.theMC, type, e);
/*     */     }
/* 117 */     JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "event exception: " + e);
/*     */     
/*     */ 
/* 120 */     if (handle != null) {
/* 121 */       ce.setConnectionHandle(handle);
/*     */     }
/* 123 */     JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "ConnectionHandle: " + handle);
/*     */     
/*     */ 
/*     */ 
/* 127 */     Iterator i = this.listeners.iterator();
/* 128 */     while (i.hasNext()) {
/* 129 */       ConnectionEventListener c = (ConnectionEventListener)i.next();
/*     */       try {
/* 131 */         switch (type) {
/*     */         case 1: 
/* 133 */           JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "firing CONNECTION_CLOSED to " + c);
/*     */           
/* 135 */           c.connectionClosed(ce);
/* 136 */           break;
/*     */         
/*     */         case 5: 
/* 139 */           JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "firing CONNECTION_ERROR_OCCURRED to " + c);
/*     */           
/* 141 */           c.connectionErrorOccurred(ce);
/* 142 */           break;
/*     */         
/*     */         case 3: 
/* 145 */           JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "firing LOCAL_TRANSACTION_COMMITTED to " + c);
/*     */           
/* 147 */           c.localTransactionCommitted(ce);
/* 148 */           break;
/*     */         
/*     */         case 4: 
/* 151 */           JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "firing LOCAL_TRANSACTION_ROLLBACK to " + c);
/*     */           
/* 153 */           c.localTransactionRolledback(ce);
/* 154 */           break;
/*     */         
/*     */         case 2: 
/* 157 */           JCATraceAdapter.traceInfo(this, "ConnectionEventHandler", "fireEvent(...)", "firing LOCAL_TRANSACTION_STARTED to " + c);
/*     */           
/* 159 */           c.localTransactionStarted(ce);
/* 160 */           break;
/*     */         
/*     */         default: 
/* 163 */           JCATraceAdapter.traceNonNLSWarning(this, "ConnectionEventHandler", "fireEvent(...)", "unknown ConnectionEvent of type: " + type, null);
/*     */         
/*     */         }
/*     */         
/*     */       }
/*     */       catch (RuntimeException re)
/*     */       {
/* 170 */         JCATraceAdapter.traceNonNLSWarning(this, "ConnectionEventHandler", "fireEvent(...)", "connectionEventListener threw RuntimeException", re);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 175 */     JCATraceAdapter.traceExit(this, "ConnectionEventHandler", "fireEvent(...)");
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ConnectionEventHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */