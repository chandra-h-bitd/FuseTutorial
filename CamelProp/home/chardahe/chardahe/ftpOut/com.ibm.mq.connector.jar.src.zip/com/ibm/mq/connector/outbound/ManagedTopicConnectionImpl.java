/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.Set;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.XATopicConnection;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.SecurityException;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedTopicConnectionImpl
/*     */   extends ManagedConnectionImpl
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedTopicConnectionImpl.java";
/*     */   
/*     */   protected ManagedTopicConnectionImpl(Subject s, ConnectionRequestInfo cri, ManagedTopicConnectionFactoryImpl mcf)
/*     */     throws ResourceException
/*     */   {
/*  71 */     super(s, cri, mcf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getConnection(Subject subj, ConnectionRequestInfo cri)
/*     */     throws SecurityException
/*     */   {
/*  97 */     JCATraceAdapter.traceEntry(this, "ManagedTopicConnectionImpl", "getConnection(...)");
/*     */     try {
/*  99 */       if ((this.theConnectionRequestInfo != null) && (!this.theConnectionRequestInfo.equals(cri)))
/*     */       {
/* 101 */         JCATraceAdapter.traceInfo(this, "ManagedTopicConnectionImpl", "getConnection(...)", "connection request info mismatch");
/*     */         
/*     */ 
/* 104 */         throw ((SecurityException)JCAExceptionBuilder.buildException(5, "MQJCA1028"));
/*     */       }
/*     */       
/* 107 */       if (wrongSubject(subj))
/*     */       {
/* 109 */         JCATraceAdapter.traceInfo(this, "ManagedTopicConnectionImpl", "getConnection(...)", "Subject mismatch");
/*     */         
/*     */ 
/* 112 */         throw ((SecurityException)JCAExceptionBuilder.buildException(5, "MQJCA1028"));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 117 */       TopicConnectionWrapper handle = new TopicConnectionWrapper(this, (TopicConnection)getPhysicalConnection(), this.theMCF.isManaged());
/*     */       
/*     */ 
/* 120 */       this.connectionHandles.add(handle);
/*     */       
/* 122 */       return handle;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 127 */       JCATraceAdapter.traceExit(this, "ManagedTopicConnectionImpl", "getConnection(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getPhysicalSession()
/*     */     throws JMSException
/*     */   {
/* 140 */     JCATraceAdapter.traceEntry(this, "ManagedTopicConnectionImpl", "getPhysicalSession()");
/*     */     try
/*     */     {
/* 143 */       Session theSession = null;
/* 144 */       if (isTransactionStarted())
/*     */       {
/* 146 */         if (this.thePhysicalXASession == null) {
/* 147 */           this.thePhysicalXASession = ((XATopicConnection)this.thePhysicalConnection).createXATopicSession();
/*     */         }
/* 149 */         theSession = this.thePhysicalXASession;
/*     */       }
/*     */       else
/*     */       {
/* 153 */         if (this.thePhysicalSession == null) {
/* 154 */           this.thePhysicalSession = ((TopicConnection)this.thePhysicalConnection).createTopicSession(false, 1);
/*     */         }
/*     */         
/* 157 */         theSession = this.thePhysicalSession;
/*     */       }
/*     */       
/* 160 */       if (JCATraceAdapter.isOn) {
/* 161 */         JCATraceAdapter.traceInfo(this, "ManagedTopicConnectionImpl", "getPhysicalSession()", "returning: " + (theSession != null ? theSession.getClass().getName() : "null"));
/*     */       }
/*     */       
/* 164 */       return theSession;
/*     */     }
/*     */     finally {
/* 167 */       JCATraceAdapter.traceExit(this, "ManagedTopicConnectionImpl", "getPhysicalSession()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createTransactedNonXASession()
/*     */     throws JMSException
/*     */   {
/* 180 */     JCATraceAdapter.traceEntry(this, "ManagedTopicConnectionImpl", "createTransactedNonXASession()");
/*     */     
/*     */     try
/*     */     {
/* 184 */       JCATraceAdapter.traceInfo(this, "ManagedTopicConnectionImpl", "createTransactedNonXASession()", "creating new locally-transacted TopicSession");
/*     */       
/*     */ 
/* 187 */       this.thePhysicalSession = ((TopicConnection)this.thePhysicalConnection).createTopicSession(true, 1);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 192 */       JCATraceAdapter.traceExit(this, "ManagedTopicConnectionImpl", "createTransactedNonXASession()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedTopicConnectionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */