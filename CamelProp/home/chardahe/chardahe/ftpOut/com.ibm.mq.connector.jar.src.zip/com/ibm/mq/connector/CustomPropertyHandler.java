/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.inbound.ActivationSpecImpl;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.jms.JmsConnectionFactory;
/*     */ import com.ibm.msg.client.jms.JmsDestination;
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.jms.JMSException;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomPropertyHandler
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2009 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/CustomPropertyHandler.java";
/*     */   
/*     */   protected static Map parseCustomProperties(String properties)
/*     */     throws ParseException
/*     */   {
/*  88 */     HashMap result = new HashMap();
/*     */     
/*  90 */     String unparsedProperties = properties;
/*  91 */     while (unparsedProperties.length() > 0)
/*     */     {
/*     */ 
/*  94 */       int endOfPropertyName = unparsedProperties.indexOf('=');
/*  95 */       if (endOfPropertyName == -1) {
/*  96 */         throw new ParseException("Missing value from properties: " + properties);
/*     */       }
/*     */       
/*  99 */       String propertyName = unparsedProperties.substring(0, endOfPropertyName).trim();
/* 100 */       unparsedProperties = unparsedProperties.substring(endOfPropertyName + 1).trim();
/*     */       
/*     */ 
/* 103 */       if (unparsedProperties.startsWith("<null>"))
/*     */       {
/* 105 */         result.put(propertyName, null);
/* 106 */         unparsedProperties = unparsedProperties.substring("<null>".length());
/*     */       }
/* 108 */       else if (unparsedProperties.startsWith("\""))
/*     */       {
/*     */ 
/* 111 */         unparsedProperties = unparsedProperties.substring(1);
/*     */         
/*     */ 
/*     */ 
/* 115 */         String propertyValue = "";
/* 116 */         boolean propertyValueBuilt = false;
/* 117 */         while (!propertyValueBuilt) {
/* 118 */           int indexOfDoubleQuote = unparsedProperties.indexOf('"');
/*     */           
/* 120 */           if (indexOfDoubleQuote < 0) {
/* 121 */             throw new ParseException("Property value is not closed: " + properties);
/*     */           }
/* 123 */           if (indexOfDoubleQuote == 0) {
/* 124 */             unparsedProperties = unparsedProperties.substring(1);
/* 125 */             propertyValueBuilt = true;
/*     */           }
/* 127 */           else if (unparsedProperties.charAt(indexOfDoubleQuote - 1) == '\\')
/*     */           {
/*     */ 
/* 130 */             propertyValue = propertyValue + unparsedProperties.substring(0, indexOfDoubleQuote - 1);
/* 131 */             propertyValue = propertyValue + "\"";
/* 132 */             unparsedProperties = unparsedProperties.substring(indexOfDoubleQuote + 1);
/*     */           }
/*     */           else
/*     */           {
/* 136 */             propertyValue = propertyValue + unparsedProperties.substring(0, indexOfDoubleQuote);
/* 137 */             unparsedProperties = unparsedProperties.substring(indexOfDoubleQuote + 1).trim();
/* 138 */             propertyValueBuilt = true;
/*     */           }
/*     */         }
/* 141 */         result.put(propertyName, propertyValue);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 146 */         throw new ParseException("Malformed property value: " + properties);
/*     */       }
/*     */       
/*     */ 
/* 150 */       unparsedProperties = unparsedProperties.trim();
/* 151 */       if (unparsedProperties.startsWith(",")) {
/* 152 */         unparsedProperties = unparsedProperties.substring(1).trim();
/*     */       }
/* 154 */       else if (!unparsedProperties.equals("")) {
/* 155 */         throw new ParseException("Properties not seperated using a comma: " + properties);
/*     */       }
/*     */     }
/*     */     
/* 159 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCustomProperties(AbstractConfiguration c, JmsConnectionFactory ctx, boolean connectionExists)
/*     */   {
/* 176 */     JCATraceAdapter.traceEntry(null, "CustomPropertyHandler", "setCustomProperties(AbstractConfig, JmsConnectionFactory)");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 182 */       Map props = parseCustomProperties(c.getArbitraryProperties());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 187 */       if ((connectionExists) && ((c instanceof ActivationSpecImpl))) {
/* 188 */         props.put("ACTIVATION_SPEC", c);
/*     */       }
/*     */       
/* 191 */       props = ResourceAdapterImpl.getJCARuntimeHelper().processArbitraryProperties(props, ctx);
/*     */       
/*     */ 
/*     */ 
/* 195 */       if ((c instanceof ActivationSpecImpl)) {
/* 196 */         props.remove("ACTIVATION_SPEC");
/*     */       }
/*     */       
/* 199 */       setProperties(props, ctx);
/*     */     }
/*     */     catch (ParseException p)
/*     */     {
/* 203 */       HashMap inserts = new HashMap();
/* 204 */       inserts.put("JCA_PROPERTY_VALUE", c.getArbitraryProperties());
/*     */       
/* 206 */       JCAMessageBuilder.buildWarning("MQJCA4008", inserts);
/*     */       
/* 208 */       JCATraceAdapter.traceException(null, "CustomPropertyHandler", "setCustomProperties(AbstractConfig, JmsConnectionFactory)", p);
/*     */ 
/*     */     }
/*     */     catch (InvalidPropertyException ipe)
/*     */     {
/* 213 */       HashMap inserts = new HashMap();
/* 214 */       inserts.put("JCA_PROPERTY_VALUE", c.getArbitraryProperties());
/*     */       
/* 216 */       JCAMessageBuilder.buildWarning("MQJCA4008", inserts);
/*     */       
/* 218 */       JCATraceAdapter.traceException(null, "CustomPropertyHandler", "setCustomProperties(AbstractConfig, JmsConnectionFactory)", ipe);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 223 */       JCATraceAdapter.traceExit(null, "CustomPropertyHandler", "setCustomProperties(AbstractConfig, JmsConnectionFactory)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCustomProperties(String s, JmsDestination ctx)
/*     */   {
/* 239 */     JCATraceAdapter.traceEntry(null, "CustomPropertyHandler", "setCustomProperties(String, JmsDestination)");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 245 */       Map props = parseCustomProperties(s);
/*     */       
/* 247 */       props = ResourceAdapterImpl.getJCARuntimeHelper().processArbitraryProperties(props, ctx);
/*     */       
/* 249 */       setProperties(props, ctx);
/*     */     }
/*     */     catch (ParseException p)
/*     */     {
/* 253 */       HashMap inserts = new HashMap();
/* 254 */       inserts.put("JCA_PROPERTY_VALUE", s);
/*     */       
/* 256 */       JCAMessageBuilder.buildWarning("MQJCA4008", inserts);
/*     */       
/* 258 */       JCATraceAdapter.traceException(null, "CustomPropertyHandler", "setCustomProperties(String, JmsDestination)", p);
/*     */ 
/*     */     }
/*     */     catch (InvalidPropertyException ipe)
/*     */     {
/* 263 */       HashMap inserts = new HashMap();
/* 264 */       inserts.put("JCA_PROPERTY_VALUE", s);
/*     */       
/* 266 */       JCAMessageBuilder.buildWarning("MQJCA4008", inserts);
/*     */       
/* 268 */       JCATraceAdapter.traceException(null, "CustomPropertyHandler", "setCustomProperties(String, JmsDestination)", ipe);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 273 */       JCATraceAdapter.traceExit(null, "CustomPropertyHandler", "setCustomProperties(String, JmsDestination)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setProperties(Map props, JmsPropertyContext ctx)
/*     */   {
/* 287 */     if (ctx != null)
/*     */     {
/* 289 */       Set s = props.keySet();
/* 290 */       Iterator i = s.iterator();
/* 291 */       while (i.hasNext())
/*     */       {
/* 293 */         String name = (String)i.next();
/* 294 */         String value = (String)props.get(name);
/*     */         
/* 296 */         JCATraceAdapter.traceInfo(CustomPropertyHandler.class, "CustomPropertyHandler", "setProperties", "attempting to set name: " + name + ", value: " + value);
/*     */         
/*     */         try
/*     */         {
/* 300 */           ctx.setObjectProperty(name, value);
/*     */         }
/*     */         catch (JMSException je)
/*     */         {
/* 304 */           HashMap inserts = new HashMap();
/* 305 */           inserts.put("JCA_CONFIG_PROPERTY", name);
/* 306 */           inserts.put("JCA_CONFIG_VALUE", value);
/*     */           
/* 308 */           JCAMessageBuilder.buildWarning("MQJCA4007", inserts);
/*     */           
/* 310 */           JCATraceAdapter.traceException(null, "CustomPropertyHandler", "setProperties", je);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/CustomPropertyHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */