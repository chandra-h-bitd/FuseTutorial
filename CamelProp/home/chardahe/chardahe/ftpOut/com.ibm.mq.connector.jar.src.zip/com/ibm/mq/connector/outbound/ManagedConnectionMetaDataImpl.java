/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedConnectionMetaDataImpl
/*     */   implements ManagedConnectionMetaData
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedConnectionMetaDataImpl.java";
/*     */   private static final String productName = "WebSphere MQ";
/*     */   private static final String productVersion = "%I% %E% %U%";
/*  55 */   private String userName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int maxConnections = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnectionMetaDataImpl(String u)
/*     */   {
/*  69 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionMetaDataImpl", "<init>");
/*     */     
/*  71 */     this.userName = u;
/*     */     
/*  73 */     JCATraceAdapter.traceExit(this, "ManagedConnectionMetaDataImpl", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEISProductName()
/*     */   {
/*  82 */     return "WebSphere MQ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEISProductVersion()
/*     */   {
/*  91 */     return "%I% %E% %U%";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxConnections()
/*     */   {
/* 103 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionMetaData", "getMaxConnections()", "Returning maxConnectionLimit 0");
/*     */     
/* 105 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 116 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionMetaData", "getUserName()", "userName: " + this.userName);
/*     */     
/* 118 */     return this.userName;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedConnectionMetaDataImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */