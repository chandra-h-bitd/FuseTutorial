/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.commonservices.propertystore.PropertyStore;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionConsumer;
/*     */ import javax.jms.ConnectionMetaData;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.ExceptionListener;
/*     */ import javax.jms.IllegalStateException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ServerSessionPool;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionWrapper
/*     */   implements Connection, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ConnectionWrapper.java";
/*  78 */   protected boolean isClosed = true;
/*     */   
/*     */ 
/*  81 */   protected ManagedConnectionImpl theManagedConnection = null;
/*     */   
/*     */ 
/*  84 */   protected Connection theConnection = null;
/*     */   
/*     */ 
/*  87 */   protected SessionWrapper theSessionWrapper = null;
/*     */   
/*     */ 
/*  90 */   protected boolean isManaged = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionWrapper(ManagedConnectionImpl mc, Connection con, boolean isManaged)
/*     */   {
/* 104 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "<init>");
/*     */     
/* 106 */     this.theManagedConnection = mc;
/* 107 */     this.theConnection = con;
/* 108 */     this.isManaged = isManaged;
/*     */     
/* 110 */     this.isClosed = false;
/*     */     
/* 112 */     JCATraceAdapter.traceExit(this, "ConnectionWrapper", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Session createSession(boolean arg0, int arg1)
/*     */     throws JMSException
/*     */   {
/* 120 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "createSession(boolean, int)", new Object[] { new Boolean(arg0), new Integer(arg1) });
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 125 */       assertOpen();
/* 126 */       if (this.theSessionWrapper == null)
/*     */       {
/* 128 */         this.theSessionWrapper = new SessionWrapper(this, this.theManagedConnection.getPhysicalSession());
/*     */       }
/*     */       else
/*     */       {
/* 132 */         throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA1018"));
/*     */       }
/*     */       
/* 135 */       JCATraceAdapter.traceData(this, "ConnectionWrapper", "createSession(boolean, int)", "Session", this.theSessionWrapper);
/*     */       
/* 137 */       return this.theSessionWrapper;
/*     */     }
/*     */     finally
/*     */     {
/* 141 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "createSession(boolean, int)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClientID()
/*     */     throws JMSException
/*     */   {
/* 151 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "getClientID()");
/*     */     try
/*     */     {
/* 154 */       assertOpen();
/*     */       
/* 156 */       String clientID = this.theConnection.getClientID();
/* 157 */       JCATraceAdapter.traceData(this, "ConnectionWrapper", "getClientID()", "ClientID", clientID);
/*     */       
/* 159 */       return clientID;
/*     */     }
/*     */     finally
/*     */     {
/* 163 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "getClientID()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setClientID(String arg0)
/*     */     throws JMSException
/*     */   {
/* 172 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "setClientID(String)", new Object[] { arg0 });
/*     */     try
/*     */     {
/* 175 */       if (jcaMethodAllowed("setClientID"))
/*     */       {
/* 177 */         assertOpen();
/*     */         
/* 179 */         this.theConnection.setClientID(arg0);
/*     */       }
/*     */       else
/*     */       {
/* 183 */         HashMap insert = new HashMap();
/* 184 */         insert.put("JCA_METHOD_NAME", "setClientID(String)");
/* 185 */         throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1031", insert, null));
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 192 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "setClientID(String)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ConnectionMetaData getMetaData()
/*     */     throws JMSException
/*     */   {
/* 201 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "getMetaData()");
/*     */     try
/*     */     {
/* 204 */       assertOpen();
/*     */       
/* 206 */       ConnectionMetaData metaData = this.theConnection.getMetaData();
/* 207 */       JCATraceAdapter.traceData(this, "ConnectionWrapper", "getMetaData()", "MetaData", metaData);
/*     */       
/* 209 */       return metaData;
/*     */     }
/*     */     finally {
/* 212 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "getMetaData()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ExceptionListener getExceptionListener()
/*     */     throws JMSException
/*     */   {
/* 221 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "getExceptionListener()");
/*     */     try
/*     */     {
/* 224 */       assertOpen();
/*     */       
/* 226 */       ExceptionListener listener = this.theConnection.getExceptionListener();
/* 227 */       JCATraceAdapter.traceData(this, "ConnectionWrapper", "getExceptionListener()", "ExceptionListener", listener);
/*     */       
/* 229 */       return listener;
/*     */     }
/*     */     finally {
/* 232 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "getExceptionListener()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExceptionListener(ExceptionListener arg0)
/*     */     throws JMSException
/*     */   {
/* 241 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "setExceptionListener(ExceptionListener)", new Object[] { arg0 });
/*     */     try
/*     */     {
/* 244 */       if (jcaMethodAllowed("setExceptionListener")) {
/* 245 */         if (!this.isManaged)
/*     */         {
/* 247 */           assertOpen();
/*     */           
/* 249 */           this.theConnection.setExceptionListener(arg0);
/*     */         }
/*     */         else
/*     */         {
/* 253 */           HashMap insert = new HashMap();
/* 254 */           insert.put("JCA_METHOD_NAME", "setExceptionListener()");
/*     */           
/* 256 */           throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1031", insert, null));
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/*     */     finally
/*     */     {
/* 264 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "setExceptionListener(ExceptionListener)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws JMSException
/*     */   {
/* 274 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "start()");
/*     */     try
/*     */     {
/* 277 */       assertOpen();
/*     */       
/* 279 */       this.theConnection.start();
/*     */     }
/*     */     finally
/*     */     {
/* 283 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "start()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws JMSException
/*     */   {
/* 292 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "stop()");
/*     */     try {
/* 294 */       if (jcaMethodAllowed("stop"))
/*     */       {
/*     */ 
/* 297 */         assertOpen();
/*     */         
/* 299 */         this.theConnection.stop();
/*     */       }
/*     */       else
/*     */       {
/* 303 */         HashMap insert = new HashMap();
/* 304 */         insert.put("JCA_METHOD_NAME", "stop()");
/* 305 */         throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1031", insert, null));
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 313 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "stop()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 322 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "close()");
/*     */     try
/*     */     {
/* 325 */       this.isClosed = true;
/*     */       
/* 327 */       if (this.theSessionWrapper != null)
/*     */       {
/* 329 */         this.theSessionWrapper.close();
/*     */       }
/*     */       
/* 332 */       this.theManagedConnection.fireConnectionClosed(this);
/*     */ 
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/*     */ 
/* 338 */       this.theManagedConnection.fireConnectionException(this, je);
/*     */     }
/*     */     finally
/*     */     {
/* 342 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "close()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionConsumer createConnectionConsumer(Destination arg0, String arg1, ServerSessionPool arg2, int arg3)
/*     */     throws JMSException
/*     */   {
/* 353 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "createConnectionConsumer(Destination,String,ServerSessionPool,int)", new Object[] { arg0, arg1, arg2, new Integer(arg3) });
/*     */     
/*     */     try
/*     */     {
/* 357 */       if (jcaMethodAllowed("createConnectionConsumer"))
/*     */       {
/* 359 */         assertOpen();
/*     */         
/* 361 */         ConnectionConsumer consumer = this.theConnection.createConnectionConsumer(arg0, arg1, arg2, arg3);
/*     */         
/* 363 */         JCATraceAdapter.traceData(this, "ConnectionWrapper", "createConnectionConsumer", "ConnectionConsumer", consumer);
/*     */         
/* 365 */         return consumer;
/*     */       }
/*     */       
/*     */ 
/* 369 */       HashMap insert = new HashMap();
/* 370 */       insert.put("JCA_METHOD_NAME", "createConnectionConsumer()");
/* 371 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1031", insert, null));
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 378 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "createConnectionConsumer(Destination,String,ServerSessionPool,int)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionConsumer createDurableConnectionConsumer(Topic arg0, String arg1, String arg2, ServerSessionPool arg3, int arg4)
/*     */     throws JMSException
/*     */   {
/* 390 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "createDurableConnectionConsumer(Topic,String,String,ServerSessionPool,int)", new Object[] { arg0, arg1, arg2, arg3, new Integer(arg4) });
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 395 */       if (jcaMethodAllowed("createDurableConnectionConsumer"))
/*     */       {
/* 397 */         assertOpen();
/* 398 */         ConnectionConsumer consumer = this.theConnection.createDurableConnectionConsumer(arg0, arg1, arg2, arg3, arg4);
/*     */         
/* 400 */         JCATraceAdapter.traceData(this, "ConnectionWrapper", "createDurableConnectionConsumer()", "DurableConnectionConsumer", consumer);
/*     */         
/*     */ 
/* 403 */         return consumer;
/*     */       }
/*     */       
/*     */ 
/* 407 */       HashMap insert = new HashMap();
/* 408 */       insert.put("JCA_METHOD_NAME", "createDurableConnectionConsumer()");
/* 409 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1031", insert, null));
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 416 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "createDurableConnectionConsumer(Topic,String,String,ServerSessionPool,int)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void releaseSession(SessionWrapper s)
/*     */   {
/* 429 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "releaseSession(SessionWrapper)", new Object[] { s });
/*     */     
/* 431 */     if (s.equals(this.theSessionWrapper)) {
/* 432 */       this.theSessionWrapper = null;
/*     */     }
/*     */     
/* 435 */     JCATraceAdapter.traceExit(this, "ConnectionWrapper", "releaseSession(SessionWrapper)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reassociate(ManagedConnectionImpl mc)
/*     */     throws JMSException
/*     */   {
/* 449 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "reassociate(ManagedConnectionImpl)", new Object[] { mc });
/*     */     
/*     */ 
/* 452 */     this.theManagedConnection.disassociate(this);
/*     */     
/* 454 */     this.theManagedConnection = mc;
/* 455 */     this.theConnection = mc.getPhysicalConnection();
/* 456 */     this.theSessionWrapper.reassociate(mc.getPhysicalSession());
/*     */     
/* 458 */     JCATraceAdapter.traceExit(this, "ConnectionWrapper", "reassociate(ManagedConnectionImpl)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 468 */     if (this.isClosed)
/*     */     {
/* 470 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1019"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finalize()
/*     */   {
/* 480 */     if (!this.isClosed) {
/* 481 */       close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isManaged()
/*     */   {
/* 491 */     return this.isManaged;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean jcaMethodAllowed(String methodName)
/*     */   {
/* 501 */     JCATraceAdapter.traceEntry(this, "ConnectionWrapper", "jcaMethodAllowed(String)", new Object[] { methodName });
/*     */     
/*     */ 
/* 504 */     boolean isAllowed = true;
/*     */     try
/*     */     {
/* 507 */       if (this.isManaged)
/*     */       {
/*     */ 
/* 510 */         boolean performClientContainerCheck = PropertyStore.getBooleanPropertyObject("com.ibm.mq.connector.performJavaEEContainerChecks").booleanValue();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 516 */         JCATraceAdapter.traceData(this, "ConnectionWrapper", methodName, "performJEEContainerChecks", new Boolean(performClientContainerCheck));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 521 */         if (performClientContainerCheck)
/*     */         {
/* 523 */           isAllowed = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 528 */       JCATraceAdapter.traceExit(this, "ConnectionWrapper", "jcaMethodAllowed(String)");
/*     */     }
/*     */     
/* 531 */     return isAllowed;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ConnectionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */