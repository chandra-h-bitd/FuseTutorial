/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageEndpointWrapper
/*     */   implements MessageListener
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/MessageEndpointWrapper.java";
/*  75 */   private MessageEndpoint theEndpoint = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MessageEndpointWrapper()
/*     */   {
/*  85 */     JCATraceAdapter.traceEntry(this, "MessageEndpointWrapper()", "<init>");
/*     */     
/*     */ 
/*  88 */     JCATraceAdapter.traceExit(this, "MessageEndpointWrapper()", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEndpoint(MessageEndpoint endpoint)
/*     */   {
/*  96 */     if (JCATraceAdapter.isOn) {
/*  97 */       JCATraceAdapter.traceEntry(this, "MessageEndpointWrapper", "setEndpoint()");
/*  98 */       JCATraceAdapter.traceInfo(this, "MessageEndpointWrapper", "setEndpoint()", "endpoint: " + endpoint);
/*     */     }
/*     */     
/* 101 */     this.theEndpoint = endpoint;
/*     */     
/* 103 */     if (JCATraceAdapter.isOn) {
/* 104 */       JCATraceAdapter.traceExit(this, "MessageEndpointWrapper", "setEndpoint()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MessageEndpoint getEndpoint()
/*     */   {
/* 112 */     return this.theEndpoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onMessage(Message msg)
/*     */   {
/* 123 */     if (JCATraceAdapter.isOn) {
/* 124 */       JCATraceAdapter.traceEntry(this, "MessageEndpointWrapper", "onMessage(...)");
/*     */     }
/*     */     try {
/* 127 */       if ((this.theEndpoint instanceof MessageListener))
/*     */       {
/* 129 */         if (JCATraceAdapter.isOn) {
/* 130 */           JCATraceAdapter.traceInfo(this, "MessageEndpointWrapper", "onMessage(...)", "calling Endpoint.onMessage(...)");
/*     */           
/* 132 */           JCATraceAdapter.traceData(this, "MessageEndpointWrapper", "onMessage(...)", "delivering", msg);
/*     */         }
/*     */         
/*     */ 
/* 136 */         ((MessageListener)this.theEndpoint).onMessage(msg);
/* 137 */         if (JCATraceAdapter.isOn) {
/* 138 */           JCATraceAdapter.traceInfo(this, "MessageEndpointWrapper", "onMessage(...)", "Message delivered");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 145 */         JCAMessageBuilder.buildWarning("MQJCA1003");
/*     */         
/* 147 */         throw new RuntimeException("no onMessage() method");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 152 */       if (JCATraceAdapter.isOn) {
/* 153 */         JCATraceAdapter.traceExit(this, "MessageEndpointWrapper", "onMessage(...)");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/MessageEndpointWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */