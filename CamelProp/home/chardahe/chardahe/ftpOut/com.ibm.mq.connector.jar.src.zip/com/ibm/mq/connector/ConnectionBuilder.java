/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.outbound.ConnectionRequestInfoImpl;
/*     */ import com.ibm.mq.connector.outbound.ManagedConnectionFactoryImpl;
/*     */ import com.ibm.mq.connector.outbound.ManagedConnectionImpl;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.jms.XAConnectionFactory;
/*     */ import javax.jms.XAQueueConnectionFactory;
/*     */ import javax.jms.XATopicConnectionFactory;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.security.PasswordCredential;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionBuilder
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/ConnectionBuilder.java";
/*     */   
/*     */   public static Connection createConnection(ConnectionFactory cf, final ManagedConnectionFactoryImpl mcf, ManagedConnectionImpl mc, Subject subj, ConnectionRequestInfo cri)
/*     */     throws ResourceException
/*     */   {
/*  95 */     JCATraceAdapter.traceEntry(null, "ConnectionBuilder", "createConnection()");
/*     */     
/*  97 */     JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "ConnectionFactory class: " + (cf != null ? cf.getClass().getName() : "null"));
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 103 */       String user = null;
/* 104 */       String pwd = null;
/*     */       
/* 106 */       if (cri != null) {
/* 107 */         user = ((ConnectionRequestInfoImpl)cri).getUsername();
/* 108 */         pwd = ((ConnectionRequestInfoImpl)cri).getPassword();
/*     */ 
/*     */       }
/* 111 */       else if (subj != null)
/*     */       {
/* 113 */         PasswordCredential passwordCredentials = (PasswordCredential)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 117 */             JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "resolving Subject: " + this.val$subj);
/*     */             
/*     */ 
/* 120 */             PasswordCredential thePC = null;
/*     */             
/* 122 */             Set s = this.val$subj.getPrivateCredentials(PasswordCredential.class);
/*     */             
/* 124 */             Iterator i = s.iterator();
/* 125 */             while ((thePC == null) && (i.hasNext())) {
/* 126 */               PasswordCredential pc = (PasswordCredential)i.next();
/*     */               
/* 128 */               if (pc.getManagedConnectionFactory().equals(mcf)) {
/* 129 */                 thePC = pc;
/*     */               }
/*     */             }
/*     */             
/* 133 */             return thePC;
/*     */           }
/*     */           
/* 136 */         });
/* 137 */         JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "passwordCredentials are " + (passwordCredentials != null ? "non-null" : "null"));
/*     */         
/*     */ 
/*     */ 
/* 141 */         if (passwordCredentials != null) {
/* 142 */           user = passwordCredentials.getUserName();
/* 143 */           pwd = new String(passwordCredentials.getPassword());
/*     */         }
/*     */       }
/*     */       else {
/* 147 */         JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "supplied Subject is null");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 152 */       if (user == null) {
/* 153 */         user = mcf.getUsername();
/* 154 */         pwd = mcf.getPassword();
/*     */       }
/*     */       
/* 157 */       JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "username: " + user);
/*     */       
/* 159 */       JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "password: " + (pwd != null ? pwd.length() + " characters" : "null"));
/*     */       
/*     */ 
/* 162 */       mc.setUserName(user);
/*     */       
/* 164 */       Connection c = null;
/* 165 */       if ((cf instanceof XAConnectionFactory))
/*     */       {
/* 167 */         if ((cf instanceof XAQueueConnectionFactory))
/*     */         {
/* 169 */           c = ((XAQueueConnectionFactory)cf).createXAQueueConnection(user, pwd);
/*     */         }
/* 171 */         else if ((cf instanceof XATopicConnectionFactory))
/*     */         {
/* 173 */           c = ((XATopicConnectionFactory)cf).createXATopicConnection(user, pwd);
/*     */         }
/*     */         else
/*     */         {
/* 177 */           c = ((XAConnectionFactory)cf).createXAConnection(user, pwd);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 182 */       else if ((cf instanceof QueueConnectionFactory))
/*     */       {
/* 184 */         c = ((QueueConnectionFactory)cf).createQueueConnection(user, pwd);
/*     */       }
/* 186 */       else if ((cf instanceof TopicConnectionFactory))
/*     */       {
/* 188 */         c = ((TopicConnectionFactory)cf).createTopicConnection(user, pwd);
/*     */       }
/*     */       else
/*     */       {
/* 192 */         c = cf.createConnection(user, pwd);
/*     */       }
/*     */       
/*     */ 
/* 196 */       JCATraceAdapter.traceInfo(ConnectionBuilder.class, "ConnectionBuilder", "createConnection()", "Connection class: " + (c != null ? c.getClass().getName() : "null"));
/*     */       
/* 198 */       return c;
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 202 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1011", je));
/*     */     }
/*     */     finally
/*     */     {
/* 206 */       JCATraceAdapter.traceExit(null, "ConnectionBuilder", "createConnection()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/ConnectionBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */