/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.Enumeration;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.IllegalStateException;
/*     */ import javax.jms.InvalidDestinationException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueBrowser;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueueBrowserWrapper
/*     */   implements QueueBrowser
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/QueueBrowserWrapper.java";
/*  58 */   protected Destination theDestination = null;
/*     */   
/*  60 */   protected QueueBrowser theBrowser = null;
/*     */   
/*  62 */   protected boolean isOpen = true;
/*     */   
/*  64 */   protected SessionWrapper theSessionWrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected QueueBrowserWrapper(SessionWrapper sw, Session s, Destination d)
/*     */     throws JMSException
/*     */   {
/*  75 */     this(sw, s, d, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected QueueBrowserWrapper(SessionWrapper sw, Session s, Destination d, String sel)
/*     */     throws JMSException
/*     */   {
/*  90 */     JCATraceAdapter.traceEntry(this, "QueueBrowserWrapper", "<init>");
/*     */     
/*     */ 
/*  93 */     if ((d instanceof Topic)) {
/*  94 */       throw ((JMSException)JCAExceptionBuilder.buildException(3, "MQJCA0001", new InvalidDestinationException("Topic supplied to queue browser constructor")));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 100 */     if ((d instanceof MQQueueProxy))
/*     */     {
/* 102 */       this.theDestination = ((MQDestinationProxy)d).getMQDestination();
/* 103 */       JCATraceAdapter.traceInfo(this, "QueueBrowserWrapper", "<init>", "extracted Destination: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 108 */       this.theDestination = d;
/* 109 */       JCATraceAdapter.traceInfo(this, "QueueBrowserWrapper", "<init>", "using Destination: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/* 113 */     this.theSessionWrapper = sw;
/*     */     
/* 115 */     JCATraceAdapter.traceInfo(this, "QueueBrowserWrapper", "<init>", "selector: " + sel);
/*     */     try
/*     */     {
/* 118 */       this.theBrowser = s.createBrowser((Queue)this.theDestination, sel);
/*     */     }
/*     */     finally
/*     */     {
/* 122 */       JCATraceAdapter.traceExit(this, "QueueBrowserWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws JMSException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       this.theBrowser.close();
/* 132 */       this.isOpen = false;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 138 */       this.theSessionWrapper.hasClosed(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Enumeration getEnumeration()
/*     */     throws JMSException
/*     */   {
/* 146 */     assertOpen();
/* 147 */     return this.theBrowser.getEnumeration();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMessageSelector()
/*     */     throws JMSException
/*     */   {
/* 154 */     assertOpen();
/* 155 */     return this.theBrowser.getMessageSelector();
/*     */   }
/*     */   
/*     */ 
/*     */   public Queue getQueue()
/*     */     throws JMSException
/*     */   {
/* 162 */     assertOpen();
/*     */     
/* 164 */     return (Queue)this.theDestination;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 173 */     if (!this.isOpen)
/*     */     {
/* 175 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1021"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/QueueBrowserWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */