package com.ibm.mq.connector.services;

public final class MQJCA_Messages
{
  static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/MQJCA_Messages.java";
  public static final String MQJCA_PRODUCT_PREFIX = "MQJCA";
  public static final String MQJCA_E_UNKNOWN = "MQJCA0000";
  public static final String MQJCA_E_JMS_EXCEPTION = "MQJCA0001";
  public static final String MQJCA_E_WMQ_EXCEPTION = "MQJCA0002";
  public static final String MQJCA_E_NAMING_EXCEPTION = "MQJCA0003";
  public static final String MQJCA_E_INBOUND_UNAVAILABLE = "MQJCA1001";
  public static final String MQJCA_E_UNKNOWN_ACT_SPEC = "MQJCA1002";
  public static final String MQJCA_E_NO_DELIVERY_METHOD = "MQJCA1003";
  public static final String MQJCA_E_XA_UNAVAILABLE = "MQJCA1004";
  public static final String MQJCA_E_JCA_CLASSES_NOT_FOUND = "MQJCA1005";
  public static final String MQJCA_E_JCA_CLASSES_INCORRECT = "MQJCA1006";
  public static final String MQJCA_E_JMS_CLASSES_NOT_FOUND = "MQJCA1007";
  public static final String MQJCA_E_JMS_CLASSES_INCORRECT = "MQJCA1008";
  public static final String MQJCA_E_JMS_CONN_FAILED = "MQJCA1011";
  public static final String MQJCA_E_JMS_MQCF_FAILED = "MQJCA1012";
  public static final String MQJCA_E_XARESOURCE_UNAVAILABLE = "MQJCA1013";
  public static final String MQJCA_E_TRAN_BEGIN_FAILED = "MQJCA1014";
  public static final String MQJCA_E_TRAN_COMMIT_FAILED = "MQJCA1015";
  public static final String MQJCA_E_TRAN_ROLLBACK_FAILED = "MQJCA1016";
  public static final String MQJCA_E_MULTIPLE_SESSIONS_UNAVAILABLE = "MQJCA1018";
  public static final String MQJCA_E_JMS_CONNECTION_CLOSED = "MQJCA1019";
  public static final String MQJCA_E_JMS_SESSION_CLOSED = "MQJCA1020";
  public static final String MQJCA_E_JMS_PRODUCER_CLOSED = "MQJCA1021";
  public static final String MQJCA_E_JMS_CONSUMER_CLOSED = "MQJCA1022";
  public static final String MQJCA_E_JMS_SESSION_FAILED = "MQJCA1023";
  public static final String MQJCA_E_JMS_ASF_UNAVAILABLE = "MQJCA1024";
  public static final String MQJCA_E_JMS_ASYNC_UNAVAILABLE = "MQJCA1025";
  public static final String MQJCA_E_JMS_CROSS_DOMAIN = "MQJCA1026";
  public static final String MQJCA_E_REAUTHENTICATION = "MQJCA1028";
  public static final String MQJCA_E_SSL_SOCKET_FACTORY_FAILED = "MQJCA1029";
  public static final String MQJCA_E_NOT_SSL_SOCKET_FACTORY = "MQJCA1030";
  public static final String MQJCA_E_CLIENT_CON_ONLY = "MQJCA1031";
  public static final String MQJCA_AS_NULL_DESTINATION = "MQJCA2002";
  public static final String MQJCA_AS_INVALID_DESTINATION_TYPE = "MQJCA2003";
  public static final String MQJCA_AS_NULL_SUBSCRIPTION_NAME = "MQJCA2004";
  public static final String MQJCA_AS_INVALID_DURABLE_DEST_TYPE = "MQJCA2005";
  public static final String MQJCA_AS_NULL_DUR_SUB_QUEUE = "MQJCA2006";
  public static final String MQJCA_AS_NON_ASF_ENV_ERROR = "MQJCA2007";
  public static final String MQJCA_E_CFG_INVALID_VALUE = "MQJCA3001";
  public static final String MQJCA_E_NO_CLIENT_OR_CCDTURL = "MQJCA3002";
  public static final String MQJCA_E_BOTH_CLIENT_AND_CCDTURL = "MQJCA3003";
  public static final String MQJCA_E_NO_CHANNEL_IN_BC = "MQJCA3004";
  public static final String MQJCA_E_CCDTURL_IN_BC = "MQJCA3005";
  public static final String MQJCA_W_UNKNOWN = "MQJCA4000";
  public static final String MQJCA_W_UNKNOWN_EXCEPTION_TYPE = "MQJCA4001";
  public static final String MQJCA_W_INBOUND_STARTUP_FAILED = "MQJCA4002";
  public static final String MQJCA_W_JMS_EXCEPTION = "MQJCA4003";
  public static final String MQJCA_W_DELIVERY_FAILED = "MQJCA4004";
  public static final String MQJCA_W_PARSE_FAILED = "MQJCA4006";
  public static final String MQJCA_W_SET_FAILED = "MQJCA4007";
  public static final String MQJCA_W_INVALID_PROPERTIES = "MQJCA4008";
  public static final String MQJCA_W_INVALID_SSL_SOCKET_FACTORY = "MQJCA4009";
  public static final String MQJCA_W_MC_DESTROY_FAILED = "MQJCA4011";
  public static final String MQJCA_W_JMS_ASF_UNAVAILABLE = "MQJCA4012";
  public static final String MQJCA_W_JMS_CONNECTION_BROKEN = "MQJCA4013";
  public static final String MQJCA_W_RECONNECTION_FAILED = "MQJCA4014";
  public static final String MQJCA_W_POOL_THREAD_SHUTDOWN = "MQJCA4015";
  public static final String MQJCA_W_UNKNOWN_CONN_HANDLE = "MQJCA4016";
  public static final String MQJCA_W_LOG_WRITER_DISABLED = "MQJCA4017";
  public static final String MQJCA_W_AFTER_DELIVERY_FAILED = "MQJCA4018";
  public static final String MQJCA_W_JMS_RECONNECTED = "MQJCA4019";
  public static final String MQJCA_W_STARTUP_RECONNECTION_ENABLED = "MQJCA4020";
  public static final String MQJCA_W_RECONNECTING = "MQJCA4021";
  public static final String MQJCA_W_WAITING_TO_RECONNECT = "MQJCA4022";
  public static final String MQJCA_W_STARTUP_RECONNECTION_FAILED = "MQJCA4023";
  public static final String MQJCA_W_CAUSED_BY = "MQJCA4024";
  public static final String MQJCA_W_STARTUP_RECONNECTION_FAILED_NO_EXCEPTION = "MQJCA4025";
  public static final String MQJCA_W_BACKED_OUT = "MQJCA4026";
  public static final String MQJCA_W_HEURCOM = "MQJCA4027";
  public static final String MQJCA_W_NON_ASF_FAILED = "MQJCA4028";
}


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/MQJCA_Messages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */