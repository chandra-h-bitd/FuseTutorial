/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.ArrayList;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicPublisher;
/*     */ import javax.jms.TopicSession;
/*     */ import javax.jms.TopicSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicSessionWrapper
/*     */   extends SessionWrapper
/*     */   implements TopicSession
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/TopicSessionWrapper.java";
/*     */   
/*     */   protected TopicSessionWrapper(TopicConnectionWrapper w, Session s)
/*     */     throws JMSException
/*     */   {
/*  66 */     super(w, s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TopicSubscriber createSubscriber(Topic arg0)
/*     */     throws JMSException
/*     */   {
/*  74 */     JCATraceAdapter.traceEntry(this, "TopicSessionWrapper", "createSubscriber(...)");
/*     */     try {
/*  76 */       return createSubscriber(arg0, "", false);
/*     */     }
/*     */     finally
/*     */     {
/*  80 */       JCATraceAdapter.traceExit(this, "TopicSessionWrapper", "createSubscriber(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicSubscriber createSubscriber(Topic arg0, String arg1, boolean arg2)
/*     */     throws JMSException
/*     */   {
/*  90 */     JCATraceAdapter.traceEntry(this, "TopicSessionWrapper", "createSubscriber(...)");
/*     */     try
/*     */     {
/*  93 */       assertOpen();
/*     */       
/*  95 */       synchronized (this.theConnWrapper) {
/*  96 */         if (this.consumers == null) {
/*  97 */           this.consumers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 101 */       TopicSubscriberWrapper tsw = new TopicSubscriberWrapper(this, this.theSession, this.theConnWrapper.isManaged(), arg0, arg1, arg2);
/*     */       
/*     */ 
/* 104 */       this.consumers.add(tsw);
/*     */       
/* 106 */       return tsw;
/*     */     }
/*     */     finally
/*     */     {
/* 110 */       JCATraceAdapter.traceExit(this, "TopicSessionWrapper", "createSubscriber(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TopicPublisher createPublisher(Topic arg0)
/*     */     throws JMSException
/*     */   {
/* 119 */     JCATraceAdapter.traceEntry(this, "TopicSessionWrapper", "createPublisher(...)");
/*     */     try
/*     */     {
/* 122 */       assertOpen();
/*     */       
/* 124 */       synchronized (this.theConnWrapper) {
/* 125 */         if (this.producers == null) {
/* 126 */           this.producers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 130 */       TopicPublisherWrapper tpw = new TopicPublisherWrapper(this, this.theSession, arg0);
/*     */       
/* 132 */       this.producers.add(tpw);
/*     */       
/* 134 */       return tpw;
/*     */     }
/*     */     finally
/*     */     {
/* 138 */       JCATraceAdapter.traceExit(this, "TopicSessionWrapper", "createPublisher(...)");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/TopicSessionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */