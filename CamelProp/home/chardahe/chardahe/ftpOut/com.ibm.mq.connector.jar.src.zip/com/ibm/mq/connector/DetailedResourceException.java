/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.msg.client.jms.JmsExceptionDetail;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.resource.ResourceException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DetailedResourceException
/*     */   extends ResourceException
/*     */   implements JmsExceptionDetail
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/DetailedResourceException.java";
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private String explanation;
/*     */   private String useraction;
/*     */   private Map inserts;
/*     */   
/*     */   public DetailedResourceException(String message, String id, String explanation, String useraction, Map inserts)
/*     */   {
/*  81 */     super(message, id);
/*     */     
/*  83 */     this.explanation = explanation;
/*  84 */     this.useraction = useraction;
/*  85 */     this.inserts = inserts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExplanation()
/*     */   {
/*  96 */     return this.explanation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserAction()
/*     */   {
/* 107 */     return this.useraction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue(String insertKey)
/*     */   {
/* 123 */     if (null == this.inserts) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     return (String)this.inserts.get(insertKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getKeys()
/*     */   {
/* 141 */     if (null == this.inserts) {
/* 142 */       return null;
/*     */     }
/*     */     
/* 145 */     return this.inserts.keySet().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 154 */     String result = super.toString();
/*     */     
/* 156 */     if (this.explanation != null) {
/* 157 */       result = result + " " + this.explanation;
/*     */     }
/*     */     
/* 160 */     if (this.useraction != null) {
/* 161 */       result = result + " " + this.useraction;
/*     */     }
/*     */     
/* 164 */     return result;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/DetailedResourceException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */