/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.IllegalStateException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageProducer;
/*     */ import javax.jms.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageProducerWrapper
/*     */   implements MessageProducer
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/MessageProducerWrapper.java";
/*  60 */   protected Destination theDestination = null;
/*     */   
/*  62 */   protected MessageProducer theProducer = null;
/*     */   
/*  64 */   protected boolean isOpen = true;
/*     */   
/*  66 */   protected SessionWrapper theSessionWrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageProducerWrapper() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageProducerWrapper(SessionWrapper sw, Session s, Destination d)
/*     */     throws JMSException
/*     */   {
/*  85 */     JCATraceAdapter.traceEntry(this, "MessageProducerWrapper", "<init>");
/*     */     
/*     */ 
/*  88 */     if ((d instanceof MQDestinationProxy))
/*     */     {
/*  90 */       this.theDestination = ((MQDestinationProxy)d).getMQDestination();
/*  91 */       JCATraceAdapter.traceInfo(this, "MessageProducerWrapper", "<init>", "extracted Destination: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  96 */       this.theDestination = d;
/*  97 */       JCATraceAdapter.traceInfo(this, "MessageProducerWrapper", "<init>", "using Destination: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/* 101 */     this.theSessionWrapper = sw;
/*     */     try
/*     */     {
/* 104 */       this.theProducer = s.createProducer(this.theDestination);
/*     */     }
/*     */     finally
/*     */     {
/* 108 */       JCATraceAdapter.traceExit(this, "MessageProducerWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDisableMessageID(boolean disableMsgId)
/*     */     throws JMSException
/*     */   {
/* 116 */     assertOpen();
/* 117 */     this.theProducer.setDisableMessageID(disableMsgId);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getDisableMessageID()
/*     */     throws JMSException
/*     */   {
/* 124 */     assertOpen();
/* 125 */     return this.theProducer.getDisableMessageID();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDisableMessageTimestamp(boolean disableTimestamp)
/*     */     throws JMSException
/*     */   {
/* 132 */     assertOpen();
/* 133 */     this.theProducer.setDisableMessageTimestamp(disableTimestamp);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getDisableMessageTimestamp()
/*     */     throws JMSException
/*     */   {
/* 140 */     assertOpen();
/* 141 */     return this.theProducer.getDisableMessageTimestamp();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDeliveryMode(int deliveryMode)
/*     */     throws JMSException
/*     */   {
/* 148 */     assertOpen();
/* 149 */     this.theProducer.setDeliveryMode(deliveryMode);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getDeliveryMode()
/*     */     throws JMSException
/*     */   {
/* 156 */     assertOpen();
/* 157 */     return this.theProducer.getDeliveryMode();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPriority(int priority)
/*     */     throws JMSException
/*     */   {
/* 164 */     assertOpen();
/* 165 */     this.theProducer.setPriority(priority);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getPriority()
/*     */     throws JMSException
/*     */   {
/* 172 */     assertOpen();
/* 173 */     return this.theProducer.getPriority();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTimeToLive(long arg0)
/*     */     throws JMSException
/*     */   {
/* 180 */     assertOpen();
/* 181 */     this.theProducer.setTimeToLive(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */   public long getTimeToLive()
/*     */     throws JMSException
/*     */   {
/* 188 */     assertOpen();
/* 189 */     return this.theProducer.getTimeToLive();
/*     */   }
/*     */   
/*     */ 
/*     */   public Destination getDestination()
/*     */     throws JMSException
/*     */   {
/* 196 */     assertOpen();
/* 197 */     return this.theProducer.getDestination();
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws JMSException
/*     */   {
/*     */     try
/*     */     {
/* 205 */       this.theProducer.close();
/* 206 */       this.isOpen = false;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 212 */       this.theSessionWrapper.hasClosed(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void send(Message msg)
/*     */     throws JMSException
/*     */   {
/* 220 */     assertOpen();
/*     */     
/* 222 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 223 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 226 */     this.theProducer.send(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void send(Message msg, int deliveryMode, int priority, long timeToLive)
/*     */     throws JMSException
/*     */   {
/* 234 */     assertOpen();
/*     */     
/* 236 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 237 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 240 */     this.theProducer.send(msg, deliveryMode, priority, timeToLive);
/*     */   }
/*     */   
/*     */ 
/*     */   public void send(Destination dest, Message msg)
/*     */     throws JMSException
/*     */   {
/* 247 */     assertOpen();
/*     */     
/* 249 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 250 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 253 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 255 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg);
/*     */     }
/*     */     else
/*     */     {
/* 259 */       this.theProducer.send(dest, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void send(Destination dest, Message msg, int deliveryMode, int priority, long timeToLive)
/*     */     throws JMSException
/*     */   {
/* 268 */     assertOpen();
/*     */     
/* 270 */     if ((msg != null) && ((msg.getJMSReplyTo() instanceof MQDestinationProxy))) {
/* 271 */       msg.setJMSReplyTo(((MQDestinationProxy)msg.getJMSReplyTo()).getMQDestination());
/*     */     }
/*     */     
/* 274 */     if ((dest instanceof MQDestinationProxy))
/*     */     {
/* 276 */       this.theProducer.send(((MQDestinationProxy)dest).getMQDestination(), msg, deliveryMode, priority, timeToLive);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 281 */       this.theProducer.send(dest, msg, deliveryMode, priority, timeToLive);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 291 */     if (!this.isOpen)
/*     */     {
/* 293 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1021"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/MessageProducerWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */