/*      */ package com.ibm.mq.connector.outbound;
/*      */ 
/*      */ import com.ibm.mq.connector.CustomPropertyHandler;
/*      */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*      */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*      */ import com.ibm.msg.client.commonservices.componentmanager.ComponentManager;
/*      */ import com.ibm.msg.client.commonservices.j2se.J2SEComponent;
/*      */ import com.ibm.msg.client.jms.JmsDestination;
/*      */ import com.ibm.msg.client.wmq.factories.WMQComponent;
/*      */ import java.io.Serializable;
/*      */ import java.util.HashMap;
/*      */ import javax.jms.Destination;
/*      */ import javax.jms.JMSException;
/*      */ import javax.naming.Referenceable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MQDestinationProxy
/*      */   implements Destination, Referenceable, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -7446019889401010234L;
/*      */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*      */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/MQDestinationProxy.java";
/*      */   public static final String MQJCA_EXP_UNLIMITED = "UNLIM";
/*      */   public static final String MQJCA_EXP_UNLIMITED_OBSOLETE = "UNLIMITED";
/*      */   public static final String MQJCA_EXP_APP = "APP";
/*      */   public static final String MQJCA_PER_APP = "APP";
/*      */   public static final String MQJCA_PER_NON = "NON";
/*      */   public static final String MQJCA_PER_NPHIGH = "HIGH";
/*      */   public static final String MQJCA_PER_PER = "PERS";
/*      */   public static final String MQJCA_PER_QDEF = "QDEF";
/*      */   public static final String MQJCA_PRI_APP = "APP";
/*      */   public static final String MQJCA_PRI_QDEF = "QDEF";
/*      */   public static final String MQJCA_JMS_COMPLIANT = "JMS";
/*      */   public static final String MQJCA_NONJMS_MQ = "MQ";
/*      */   public static final String MQJCA_READ_AHEAD_DELIVERALL = "ALL";
/*      */   public static final String MQJCA_READ_AHEAD_DELIVERCURRENT = "CURRENT";
/*      */   public static final String MQJCA_RECEIVE_CONVERSION_QMGR = "QMGR";
/*      */   public static final String MQJCA_RECEIVE_CONVERSION_CLIENT_MSG = "CLIENT_MSG";
/*      */   public static final String MQJCA_READ_AHEAD_AS_DEST = "DESTINATION";
/*      */   public static final String MQJCA_READ_AHEAD_AS_QDEF = "QUEUE";
/*      */   public static final String MQJCA_READ_AHEAD_AS_TOPIC = "TOPIC";
/*      */   public static final String MQJCA_READ_AHEAD_DISABLED = "DISABLED";
/*      */   public static final String MQJCA_READ_AHEAD_ENABLED = "ENABLED";
/*      */   public static final String MQJCA_PUT_ASYNC_AS_DEST = "DESTINATION";
/*      */   public static final String MQJCA_PUT_ASYNC_AS_QDEF = "QUEUE";
/*      */   public static final String MQJCA_PUT_ASYNC_AS_TOPIC = "TOPIC";
/*      */   public static final String MQJCA_PUT_ASYNC_DISABLED = "DISABLED";
/*      */   public static final String MQJCA_PUT_ASYNC_ENABLED = "ENABLED";
/*      */   private static final String NATIVE = "NATIVE";
/*      */   private static final char NORMAL = 'N';
/*      */   private static final char REVERSED = 'R';
/*      */   private static final char S390 = '3';
/*      */   private static final char UNKNOWN = '?';
/*  170 */   protected final HashMap<String, String> inserts = new HashMap();
/*      */   
/*      */ 
/*  173 */   protected String arbitraryProperties = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   private String readAheadAllowedStringValue = "DESTINATION";
/*  180 */   private String putAsyncAllowedStringValue = "DESTINATION";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */   protected JmsDestination theDestination = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  199 */     ComponentManager compmgr = ComponentManager.getInstance();
/*  200 */     compmgr.registerComponent(new J2SEComponent());
/*  201 */     compmgr.registerComponent(new WMQComponent());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadAheadAllowed(String s)
/*      */     throws JMSException
/*      */   {
/*  223 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setReadAheadAllowed(String)");
/*      */     try {
/*  225 */       s = s.trim();
/*      */       
/*  227 */       if (s == null)
/*      */       {
/*  229 */         this.inserts.clear();
/*  230 */         this.inserts.put("JCA_CONFIG_PROPERTY", "readAheadAllowed");
/*  231 */         this.inserts.put("JCA_CONFIG_VALUE", "null");
/*  232 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("readAheadAllowed")));
/*      */         
/*      */ 
/*  235 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*  237 */       else if (s.equalsIgnoreCase("DESTINATION"))
/*      */       {
/*  239 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReadAheadAllowed(String)", "readAheadAllowed: ", "DESTINATION");
/*      */         
/*  241 */         this.theDestination.setIntProperty("readAheadAllowed", -1);
/*  242 */         this.readAheadAllowedStringValue = s;
/*      */       }
/*  244 */       else if (s.equalsIgnoreCase("QUEUE"))
/*      */       {
/*  246 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReadAheadAllowed(String)", "readAheadAllowed: ", "QUEUE");
/*      */         
/*  248 */         this.theDestination.setIntProperty("readAheadAllowed", -1);
/*  249 */         this.readAheadAllowedStringValue = s;
/*      */       }
/*  251 */       else if (s.equalsIgnoreCase("TOPIC"))
/*      */       {
/*  253 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReadAheadAllowed(String)", "readAheadAllowed: ", "TOPIC");
/*      */         
/*  255 */         this.theDestination.setIntProperty("readAheadAllowed", -1);
/*  256 */         this.readAheadAllowedStringValue = s;
/*      */       }
/*  258 */       else if (s.equalsIgnoreCase("DISABLED"))
/*      */       {
/*  260 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReadAheadAllowed(String)", "readAheadAllowed: ", "DISABLED");
/*      */         
/*  262 */         this.theDestination.setIntProperty("readAheadAllowed", 0);
/*      */       }
/*  264 */       else if (s.equalsIgnoreCase("ENABLED"))
/*      */       {
/*  266 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReadAheadAllowed(String)", "readAheadAllowed: ", "ENABLED");
/*      */         
/*  268 */         this.theDestination.setIntProperty("readAheadAllowed", 1);
/*      */       }
/*      */       else
/*      */       {
/*  272 */         this.inserts.clear();
/*  273 */         this.inserts.put("JCA_CONFIG_PROPERTY", "readAheadAllowed");
/*  274 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/*  275 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("readAheadAllowed")));
/*      */         
/*      */ 
/*  278 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  283 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setReadAheadAllowed(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReadAheadAllowed()
/*      */     throws JMSException
/*      */   {
/*  297 */     String retval = null;
/*  298 */     switch (this.theDestination.getIntProperty("readAheadAllowed"))
/*      */     {
/*      */     case -1: 
/*  301 */       retval = this.readAheadAllowedStringValue;
/*  302 */       break;
/*      */     case 0: 
/*  304 */       retval = "DISABLED";
/*  305 */       break;
/*      */     case 1: 
/*  307 */       retval = "ENABLED";
/*      */     }
/*      */     
/*  310 */     JCATraceAdapter.traceData(this, "MQDestinationProxy", "getReadAheadAllowed()", "readAheadAllowed: ", retval);
/*  311 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPutAsyncAllowed(String s)
/*      */     throws JMSException
/*      */   {
/*  327 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setPutAsyncAllowed(String)");
/*      */     try {
/*  329 */       s = s.trim();
/*      */       
/*  331 */       if (s == null)
/*      */       {
/*  333 */         this.inserts.clear();
/*  334 */         this.inserts.put("JCA_CONFIG_PROPERTY", "putAsyncAllowed");
/*  335 */         this.inserts.put("JCA_CONFIG_VALUE", "null");
/*  336 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("putAsyncAllowed")));
/*      */         
/*      */ 
/*  339 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*  341 */       else if (s.equalsIgnoreCase("DESTINATION"))
/*      */       {
/*  343 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPutAsyncAllowed(String)", "putAsyncAllowed: ", "DESTINATION");
/*      */         
/*  345 */         this.theDestination.setIntProperty("putAsyncAllowed", -1);
/*  346 */         this.putAsyncAllowedStringValue = s;
/*      */       }
/*  348 */       else if (s.equalsIgnoreCase("QUEUE"))
/*      */       {
/*  350 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPutAsyncAllowed(String)", "putAsyncAllowed: ", "QUEUE");
/*      */         
/*  352 */         this.theDestination.setIntProperty("putAsyncAllowed", -1);
/*  353 */         this.putAsyncAllowedStringValue = s;
/*      */       }
/*  355 */       else if (s.equalsIgnoreCase("TOPIC"))
/*      */       {
/*  357 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPutAsyncAllowed(String)", "putAsyncAllowed: ", "TOPIC");
/*      */         
/*  359 */         this.theDestination.setIntProperty("putAsyncAllowed", -1);
/*  360 */         this.putAsyncAllowedStringValue = s;
/*      */       }
/*  362 */       else if (s.equalsIgnoreCase("DISABLED"))
/*      */       {
/*  364 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPutAsyncAllowed(String)", "putAsyncAllowed: ", "DISABLED");
/*      */         
/*  366 */         this.theDestination.setIntProperty("putAsyncAllowed", 0);
/*      */       }
/*  368 */       else if (s.equalsIgnoreCase("ENABLED"))
/*      */       {
/*  370 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPutAsyncAllowed(String)", "putAsyncAllowed: ", "ENABLED");
/*      */         
/*  372 */         this.theDestination.setIntProperty("putAsyncAllowed", 1);
/*      */       }
/*      */       else
/*      */       {
/*  376 */         this.inserts.clear();
/*  377 */         this.inserts.put("JCA_CONFIG_PROPERTY", "putAsyncAllowed");
/*  378 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/*  379 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("putAsyncAllowed")));
/*      */         
/*      */ 
/*  382 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  387 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setPutAsyncAllowed(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPutAsyncAllowed()
/*      */     throws JMSException
/*      */   {
/*  400 */     String retval = null;
/*  401 */     switch (this.theDestination.getIntProperty("putAsyncAllowed"))
/*      */     {
/*      */     case -1: 
/*  404 */       retval = this.putAsyncAllowedStringValue;
/*  405 */       break;
/*      */     case 0: 
/*  407 */       retval = "DISABLED";
/*  408 */       break;
/*      */     case 1: 
/*  410 */       retval = "ENABLED";
/*      */     }
/*      */     
/*  413 */     JCATraceAdapter.traceData(this, "MQDestinationProxy", "getPutAsyncAllowed()", "putAsyncAllowed: ", retval);
/*  414 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getArbitraryProperties()
/*      */   {
/*  424 */     return this.arbitraryProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArbitraryProperties(String s)
/*      */   {
/*  436 */     this.arbitraryProperties = s;
/*      */     
/*  438 */     CustomPropertyHandler.setCustomProperties(s, this.theDestination);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCCSID()
/*      */     throws JMSException
/*      */   {
/*  447 */     return Integer.toString(this.theDestination.getIntProperty("CCSID"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCCSID(String s)
/*      */     throws JMSException
/*      */   {
/*  458 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setCCSID(String)");
/*      */     try {
/*  460 */       this.theDestination.setIntProperty("CCSID", Integer.parseInt(s.trim()));
/*  461 */       JCATraceAdapter.traceData(this, "MQDestinationProxy", "setCCSID(String)", "CCSID: ", s);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  465 */       this.inserts.clear();
/*  466 */       this.inserts.put("JCA_CONFIG_PROPERTY", "CCSID");
/*  467 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  468 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("CCSID")));
/*      */       
/*  470 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */     finally
/*      */     {
/*  474 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setCCSID(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */     throws JMSException
/*      */   {
/*  485 */     int i = this.theDestination.getIntProperty("encoding");
/*  486 */     return parseEncoding(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEncoding(String arg0)
/*      */     throws JMSException
/*      */   {
/*  497 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setEncoding(String)");
/*      */     
/*  499 */     int i = parseEncoding(arg0.trim());
/*  500 */     this.theDestination.setIntProperty("encoding", i);
/*      */     
/*  502 */     JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setEncoding(String)");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExpiry()
/*      */     throws JMSException
/*      */   {
/*  511 */     String retval = null;
/*      */     
/*  513 */     long l = this.theDestination.getLongProperty("timeToLive");
/*  514 */     if (l > 0L) {
/*  515 */       retval = Long.toString(l);
/*      */     }
/*  517 */     else if (l == 0L) {
/*  518 */       retval = "UNLIM";
/*      */     }
/*      */     else {
/*  521 */       retval = "APP";
/*      */     }
/*  523 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExpiry(String expiry)
/*      */     throws JMSException
/*      */   {
/*  535 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setExpiry(String)");
/*  536 */     String s = expiry.trim();
/*      */     try {
/*  538 */       if (("UNLIM".equalsIgnoreCase(s)) || ("UNLIMITED".equalsIgnoreCase(s))) {
/*  539 */         this.theDestination.setLongProperty("timeToLive", 0L);
/*      */       }
/*  541 */       else if ("APP".equalsIgnoreCase(s)) {
/*  542 */         this.theDestination.setLongProperty("timeToLive", -2L);
/*      */       }
/*      */       else {
/*  545 */         this.theDestination.setLongProperty("timeToLive", Long.parseLong(s));
/*      */       }
/*  547 */       JCATraceAdapter.traceData(this, "MQDestinationProxy", "setExpiry(String)", "expiry: ", s);
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  551 */       this.inserts.clear();
/*  552 */       this.inserts.put("JCA_CONFIG_PROPERTY", "expiry");
/*  553 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  554 */       this.inserts.put("JCA_CONFIG_DEFAULT", Long.toString(this.theDestination.getLongProperty("timeToLive")));
/*      */       
/*  556 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */     finally
/*      */     {
/*  560 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setExpiry(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFailIfQuiesce()
/*      */     throws JMSException
/*      */   {
/*  570 */     return this.theDestination.getIntProperty("failIfQuiesce") == 1 ? "true" : "false";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailIfQuiesce(String arg0)
/*      */     throws JMSException
/*      */   {
/*  581 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setFailIfQuiesce(String)");
/*  582 */     String fiq = arg0.trim();
/*      */     try {
/*  584 */       if ((fiq != null) && (fiq.equalsIgnoreCase("true"))) {
/*  585 */         JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "setFailIfQuiesce(String)", "failIfQuiesce enabled");
/*  586 */         this.theDestination.setIntProperty("failIfQuiesce", 1);
/*      */       }
/*      */       else {
/*  589 */         JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "setFailIfQuiesce(String)", "failIfQuiesce disabled");
/*  590 */         this.theDestination.setIntProperty("failIfQuiesce", 0);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  595 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setFailIfQuiesce(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPersistence()
/*      */     throws JMSException
/*      */   {
/*  605 */     String retval = null;
/*      */     
/*  607 */     switch (this.theDestination.getIntProperty("deliveryMode")) {
/*      */     case -2: 
/*  609 */       retval = "APP";
/*  610 */       break;
/*      */     case 1: 
/*  612 */       retval = "NON";
/*  613 */       break;
/*      */     case 3: 
/*  615 */       retval = "HIGH";
/*  616 */       break;
/*      */     case 2: 
/*  618 */       retval = "PERS";
/*  619 */       break;
/*      */     case -1: 
/*  621 */       retval = "QDEF";
/*      */     }
/*      */     
/*  624 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPersistence(String persistence)
/*      */     throws JMSException
/*      */   {
/*  637 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setPersistence(String)");
/*  638 */     String s = persistence.trim();
/*      */     try
/*      */     {
/*  641 */       if (s == null)
/*      */       {
/*  643 */         this.inserts.clear();
/*  644 */         this.inserts.put("JCA_CONFIG_PROPERTY", "persistence");
/*  645 */         this.inserts.put("JCA_CONFIG_VALUE", "null");
/*  646 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("deliveryMode")));
/*      */         
/*  648 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*  650 */       else if (s.equalsIgnoreCase("APP"))
/*      */       {
/*  652 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPersistence(String)", "persistence: ", "APP");
/*  653 */         this.theDestination.setIntProperty("deliveryMode", -2);
/*      */       }
/*  655 */       else if (s.equalsIgnoreCase("NON"))
/*      */       {
/*  657 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPersistence(String)", "persistence: ", "NON");
/*  658 */         this.theDestination.setIntProperty("deliveryMode", 1);
/*      */       }
/*  660 */       else if (s.equalsIgnoreCase("HIGH"))
/*      */       {
/*  662 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPersistence(String)", "persistence: ", "HIGH");
/*  663 */         this.theDestination.setIntProperty("deliveryMode", 3);
/*      */       }
/*  665 */       else if (s.equalsIgnoreCase("PERS"))
/*      */       {
/*  667 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPersistence(String)", "persistence: ", "PERS");
/*  668 */         this.theDestination.setIntProperty("deliveryMode", 2);
/*      */       }
/*  670 */       else if (s.equalsIgnoreCase("QDEF"))
/*      */       {
/*  672 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPersistence(String)", "persistence: ", "QDEF");
/*  673 */         this.theDestination.setIntProperty("deliveryMode", -1);
/*      */       }
/*      */       else
/*      */       {
/*  677 */         this.inserts.clear();
/*  678 */         this.inserts.put("JCA_CONFIG_PROPERTY", "persistence");
/*  679 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/*  680 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("deliveryMode")));
/*      */         
/*  682 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  687 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setPersistence(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPriority()
/*      */     throws JMSException
/*      */   {
/*  697 */     String retval = null;
/*      */     
/*  699 */     int i = this.theDestination.getIntProperty("priority");
/*  700 */     if ((i >= 0) && (i <= 9)) {
/*  701 */       retval = Integer.toString(i);
/*      */     }
/*  703 */     else if (i == -2) {
/*  704 */       retval = "APP";
/*      */     }
/*      */     else {
/*  707 */       retval = "QDEF";
/*      */     }
/*  709 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPriority(String priority)
/*      */     throws JMSException
/*      */   {
/*  726 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setPriority(String)");
/*  727 */     String s = priority.trim();
/*      */     try
/*      */     {
/*  730 */       if (s == null)
/*      */       {
/*  732 */         this.inserts.clear();
/*  733 */         this.inserts.put("JCA_CONFIG_PROPERTY", "priority");
/*  734 */         this.inserts.put("JCA_CONFIG_VALUE", "null");
/*  735 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("priority")));
/*      */         
/*  737 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*  739 */       else if (s.equalsIgnoreCase("APP"))
/*      */       {
/*  741 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPriority(String)", "priority: ", "APP");
/*  742 */         this.theDestination.setIntProperty("priority", -2);
/*      */       }
/*  744 */       else if (s.equalsIgnoreCase("QDEF"))
/*      */       {
/*  746 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPriority(String)", "priority: ", "QDEF");
/*  747 */         this.theDestination.setIntProperty("priority", -1);
/*      */       }
/*      */       else
/*      */       {
/*  751 */         int pri = Integer.parseInt(s);
/*      */         
/*  753 */         if ((pri >= 0) && (pri <= 9)) {
/*  754 */           this.theDestination.setIntProperty("priority", pri);
/*  755 */           JCATraceAdapter.traceData(this, "MQDestinationProxy", "setPriority(String)", "priority: ", new Integer(pri));
/*      */         }
/*      */         else
/*      */         {
/*  759 */           this.inserts.clear();
/*  760 */           this.inserts.put("JCA_CONFIG_PROPERTY", "priority");
/*  761 */           this.inserts.put("JCA_CONFIG_VALUE", s);
/*  762 */           this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("priority")));
/*      */           
/*  764 */           JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/*  771 */       this.inserts.clear();
/*  772 */       this.inserts.put("JCA_CONFIG_PROPERTY", "priority");
/*  773 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  774 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("priority")));
/*      */       
/*  776 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */     finally
/*      */     {
/*  780 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setPriority(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadAheadClosePolicy(String racp)
/*      */     throws JMSException
/*      */   {
/*  791 */     String s = racp.trim();
/*  792 */     if ("ALL".equals(s)) {
/*  793 */       this.theDestination.setIntProperty("readAheadClosePolicy", 2);
/*      */     }
/*  795 */     else if ("CURRENT".equals(s)) {
/*  796 */       this.theDestination.setIntProperty("readAheadClosePolicy", 1);
/*      */     }
/*      */     else
/*      */     {
/*  800 */       this.inserts.clear();
/*  801 */       this.inserts.put("JCA_CONFIG_PROPERTY", "readAheadClosePolicy");
/*  802 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  803 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("readAheadClosePolicy")));
/*      */       
/*  805 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReadAheadClosePolicy()
/*      */     throws JMSException
/*      */   {
/*  817 */     String retval = null;
/*      */     
/*      */ 
/*  820 */     if (this.theDestination.getIntProperty("readAheadClosePolicy") == 2)
/*      */     {
/*  822 */       retval = "ALL";
/*      */     }
/*      */     else
/*      */     {
/*  826 */       retval = "CURRENT";
/*      */     }
/*  828 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTargetClient()
/*      */     throws JMSException
/*      */   {
/*  837 */     return this.theDestination.getIntProperty("targetClient") == 0 ? "JMS" : "MQ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTargetClient(String tc)
/*      */     throws JMSException
/*      */   {
/*  852 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setTargetClient(String)");
/*  853 */     String s = tc.trim();
/*      */     try
/*      */     {
/*  856 */       if (s == null)
/*      */       {
/*  858 */         this.inserts.clear();
/*  859 */         this.inserts.put("JCA_CONFIG_PROPERTY", "targetClient");
/*  860 */         this.inserts.put("JCA_CONFIG_VALUE", null);
/*  861 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("targetClient")));
/*      */         
/*  863 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*  865 */       else if (s.equalsIgnoreCase("JMS"))
/*      */       {
/*  867 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setTargetClient(String)", "targetClient: ", "JMS");
/*  868 */         this.theDestination.setIntProperty("targetClient", 0);
/*      */       }
/*  870 */       else if (s.equalsIgnoreCase("MQ"))
/*      */       {
/*  872 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setTargetClient(String)", "targetClient: ", "MQ");
/*  873 */         this.theDestination.setIntProperty("targetClient", 1);
/*      */       }
/*      */       else
/*      */       {
/*  877 */         this.inserts.clear();
/*  878 */         this.inserts.put("JCA_CONFIG_PROPERTY", "targetClient");
/*  879 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/*  880 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("targetClient")));
/*      */         
/*  882 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  887 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setTargetClient(String)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Destination getMQDestination()
/*      */   {
/*  898 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "getMQDestination()");
/*      */     try {
/*  900 */       return this.theDestination;
/*      */     }
/*      */     finally
/*      */     {
/*  904 */       JCATraceAdapter.traceExit(this, "MQDestinationProxy", "getMQDestination()");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int parseEncoding(String s)
/*      */   {
/*  917 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "parseEncoding()");
/*  918 */     JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "parseEncoding()", "encoding: " + s);
/*      */     
/*  920 */     int iVal = 0;
/*  921 */     String str = s.toUpperCase();
/*  922 */     boolean failed = false;
/*      */     
/*      */ 
/*  925 */     if (str.equals("NATIVE")) {
/*  926 */       iVal = 273;
/*      */     }
/*  928 */     else if (str.length() == 3)
/*      */     {
/*  930 */       iVal = 0;
/*      */       
/*  932 */       if (str.charAt(0) == 'N') {
/*  933 */         iVal |= 0x1;
/*      */       }
/*  935 */       else if (str.charAt(0) == 'R') {
/*  936 */         iVal |= 0x2;
/*      */       }
/*      */       else
/*      */       {
/*  940 */         failed = true;
/*      */       }
/*      */       
/*  943 */       if (str.charAt(1) == 'N') {
/*  944 */         iVal |= 0x10;
/*      */       }
/*  946 */       else if (str.charAt(1) == 'R') {
/*  947 */         iVal |= 0x20;
/*      */       }
/*      */       else
/*      */       {
/*  951 */         failed = true;
/*      */       }
/*      */       
/*  954 */       if (str.charAt(2) == 'N') {
/*  955 */         iVal |= 0x100;
/*      */       }
/*  957 */       else if (str.charAt(2) == 'R') {
/*  958 */         iVal |= 0x200;
/*      */       }
/*  960 */       else if (str.charAt(2) == '3') {
/*  961 */         iVal |= 0x300;
/*      */       }
/*      */       else
/*      */       {
/*  965 */         failed = true;
/*      */       }
/*      */       
/*  968 */       if (failed)
/*      */       {
/*  970 */         this.inserts.clear();
/*  971 */         this.inserts.put("JCA_CONFIG_PROPERTY", "encoding");
/*  972 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/*  973 */         this.inserts.put("JCA_CONFIG_DEFAULT", "NATIVE");
/*  974 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*  975 */         iVal = 273;
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  981 */       this.inserts.clear();
/*  982 */       this.inserts.put("JCA_CONFIG_PROPERTY", "encoding");
/*  983 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/*  984 */       this.inserts.put("JCA_CONFIG_DEFAULT", "NATIVE");
/*  985 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*  986 */       iVal = 273;
/*      */     }
/*      */     
/*      */ 
/*  990 */     JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "parseEncoding()", "encoding parsed to : " + iVal);
/*  991 */     JCATraceAdapter.traceExit(this, "MQDestinationProxy", "parseEncoding()");
/*      */     
/*  993 */     return iVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String parseEncoding(int i)
/*      */   {
/* 1004 */     JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "parseEncoding()");
/* 1005 */     JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "parseEncoding()", "encoding: " + i);
/*      */     
/* 1007 */     StringBuffer strBuf = new StringBuffer();
/*      */     
/* 1009 */     if (i == 273) {
/* 1010 */       strBuf.append("NATIVE");
/*      */     }
/*      */     else
/*      */     {
/* 1014 */       if ((i & 0x1) != 0) {
/* 1015 */         strBuf.append('N');
/*      */       }
/* 1017 */       else if ((i & 0x2) != 0) {
/* 1018 */         strBuf.append('R');
/*      */       }
/*      */       else {
/* 1021 */         strBuf.append('?');
/*      */       }
/*      */       
/* 1024 */       if ((i & 0x10) != 0) {
/* 1025 */         strBuf.append('N');
/*      */       }
/* 1027 */       else if ((i & 0x20) != 0) {
/* 1028 */         strBuf.append('R');
/*      */       }
/*      */       else {
/* 1031 */         strBuf.append('?');
/*      */       }
/*      */       
/* 1034 */       if ((i & 0x300) == 768) {
/* 1035 */         strBuf.append('3');
/*      */       }
/* 1037 */       else if ((i & 0x100) == 256) {
/* 1038 */         strBuf.append('N');
/*      */       }
/* 1040 */       else if ((i & 0x200) == 512) {
/* 1041 */         strBuf.append('R');
/*      */       }
/*      */       else {
/* 1044 */         strBuf.append('?');
/*      */       }
/*      */     }
/*      */     
/* 1048 */     JCATraceAdapter.traceInfo(this, "MQDestinationProxy", "parseEncoding()", "encoding parsed to : " + strBuf.toString());
/* 1049 */     JCATraceAdapter.traceExit(this, "MQDestinationProxy", "parseEncoding()");
/*      */     
/* 1051 */     return strBuf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveCCSID(String s)
/*      */     throws JMSException
/*      */   {
/* 1062 */     if (JCATraceAdapter.isOn) {
/* 1063 */       JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setReceiveCCSID(String)");
/*      */     }
/*      */     try {
/* 1066 */       this.theDestination.setIntProperty("receiveCCSID", Integer.parseInt(s.trim()));
/* 1067 */       if (JCATraceAdapter.isOn) {
/* 1068 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReceiveCCSID(String)", "Receive CCSID: ", s);
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1073 */       this.inserts.clear();
/* 1074 */       this.inserts.put("JCA_CONFIG_PROPERTY", "ReceiveCCSID");
/* 1075 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1076 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("receiveCCSID")));
/*      */       
/* 1078 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */     }
/*      */     finally
/*      */     {
/* 1082 */       if (JCATraceAdapter.isOn) {
/* 1083 */         JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setReceiveCCSID(String)");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReceiveCCSID()
/*      */     throws JMSException
/*      */   {
/* 1094 */     return Integer.toString(this.theDestination.getIntProperty("receiveCCSID"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceiveConversion(String s)
/*      */     throws JMSException
/*      */   {
/* 1105 */     if (JCATraceAdapter.isOn) {
/* 1106 */       JCATraceAdapter.traceEntry(this, "MQDestinationProxy", "setReceiveConversion(String)");
/*      */     }
/*      */     try {
/* 1109 */       if (s == null)
/*      */       {
/* 1111 */         this.inserts.clear();
/* 1112 */         this.inserts.put("JCA_CONFIG_PROPERTY", "setReceiveConversion");
/* 1113 */         this.inserts.put("JCA_CONFIG_VALUE", null);
/* 1114 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("receiveConversion")));
/*      */         
/* 1116 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/* 1118 */       else if (s.equalsIgnoreCase("CLIENT_MSG"))
/*      */       {
/* 1120 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReceiveConversion(String)", "receiveConversion: ", s);
/* 1121 */         this.theDestination.setIntProperty("receiveConversion", 1);
/*      */       }
/* 1123 */       else if (s.equalsIgnoreCase("QMGR"))
/*      */       {
/* 1125 */         JCATraceAdapter.traceData(this, "MQDestinationProxy", "setReceiveConversion(String)", "receiveConversion: ", s);
/* 1126 */         this.theDestination.setIntProperty("receiveConversion", 2);
/*      */       }
/*      */       else
/*      */       {
/* 1130 */         this.inserts.clear();
/* 1131 */         this.inserts.put("JCA_CONFIG_PROPERTY", "receiveConversion");
/* 1132 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/* 1133 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("receiveConversion")));
/*      */         
/* 1135 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1140 */       if (JCATraceAdapter.isOn) {
/* 1141 */         JCATraceAdapter.traceExit(this, "MQDestinationProxy", "setReceiveConversion(String)");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReceiveConversion()
/*      */     throws JMSException
/*      */   {
/* 1152 */     return this.theDestination.getIntProperty("receiveConversion") == 1 ? "CLIENT_MSG" : "QMGR";
/*      */   }
/*      */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/MQDestinationProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */