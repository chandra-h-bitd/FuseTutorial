/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.inbound.ActivationSpecImpl;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQXAConnectionFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.XAConnection;
/*     */ import javax.jms.XASession;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecoveryXAResource
/*     */   implements XAResource
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2012 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/RecoveryXAResource.java";
/*     */   private ActivationSpecImpl actSpec;
/*     */   private MQXAConnectionFactory xacf;
/*     */   private boolean isZOS;
/*     */   private boolean connectBindings;
/*     */   private boolean connectClient;
/*     */   
/*     */   public RecoveryXAResource(ActivationSpecImpl actSpec, boolean isZOS)
/*     */     throws XAException
/*     */   {
/*  67 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", new Object[] { actSpec, Boolean.valueOf(isZOS) });
/*     */     
/*     */ 
/*  70 */     this.actSpec = actSpec;
/*  71 */     this.isZOS = isZOS;
/*     */     
/*  73 */     String transportType = actSpec.getTransportType();
/*     */     
/*     */ 
/*  76 */     this.connectBindings = ((transportType.equalsIgnoreCase("BINDINGS")) || (transportType.equalsIgnoreCase("BINDINGS_THEN_CLIENT")));
/*  77 */     this.connectClient = ((transportType.equalsIgnoreCase("CLIENT")) || (transportType.equalsIgnoreCase("BINDINGS_THEN_CLIENT")));
/*     */     
/*  79 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", "Creating RecoveryXAResource with transportType: ", transportType);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  85 */       this.xacf = ((MQXAConnectionFactory)ConnectionFactoryBuilder.getInstance().createConnectionFactory(actSpec, 1, true));
/*     */     }
/*     */     catch (JMSException e) {
/*  88 */       JCATraceAdapter.traceException(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", e);
/*     */       
/*  90 */       XAException ex = new XAException(-7);
/*  91 */       ex.initCause(e);
/*  92 */       JCATraceAdapter.traceData(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", "Caught JMSException creating connection factory, exiting via XAException with XAER_RMFAIL", ex);
/*     */       
/*     */ 
/*  95 */       throw ex;
/*     */     }
/*     */     catch (ClassCastException e) {
/*  98 */       JCATraceAdapter.traceException(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", e);
/*     */       
/* 100 */       XAException ex = new XAException(-7);
/* 101 */       ex.initCause(e);
/* 102 */       JCATraceAdapter.traceData(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)", "Caught ClassCastException creating connection factory, exiting via XAException with XAER_RMFAIL", ex);
/*     */       
/*     */ 
/* 105 */       throw ex;
/*     */     } finally {
/* 107 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "<init>(ActivationSpecImpl, boolean)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkExceptions(ArrayList<Exception> exceptionList)
/*     */     throws XAException
/*     */   {
/* 120 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "checkExceptions(ArrayList)", new Object[] { exceptionList });
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 126 */       int expectedNumConnections = 1;
/*     */       
/* 128 */       if ((this.connectBindings) && (this.connectClient)) {
/* 129 */         expectedNumConnections = 2;
/*     */       }
/*     */       
/* 132 */       if (exceptionList.size() == expectedNumConnections)
/*     */       {
/*     */ 
/*     */ 
/* 136 */         if (expectedNumConnections == 1) {
/* 137 */           Exception e = (Exception)exceptionList.get(0);
/* 138 */           if ((e instanceof XAException)) {
/* 139 */             JCATraceAdapter.traceData(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "Throwing XAException", e);
/* 140 */             throw ((XAException)e); }
/* 141 */           if ((e instanceof JMSException)) {
/* 142 */             XAException ex = new XAException(-7);
/* 143 */             ex.initCause(e);
/* 144 */             JCATraceAdapter.traceData(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "Throwing XAException", ex);
/* 145 */             throw ex;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */         Exception bestException = null;
/* 163 */         for (int i = 0; i < exceptionList.size(); i++) {
/* 164 */           Object o = exceptionList.get(0);
/* 165 */           JCATraceAdapter.traceData(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "Processing stored Exception ", o);
/* 166 */           if ((o instanceof XAException)) {
/* 167 */             if (((XAException)o).errorCode > 0)
/*     */             {
/* 169 */               bestException = (XAException)o;
/*     */             }
/* 171 */             else if ((bestException == null) || ((bestException instanceof JMSException)))
/*     */             {
/*     */ 
/* 174 */               bestException = (XAException)o;
/*     */             }
/* 176 */             else if ((((XAException)o).errorCode == -4) && 
/* 177 */               ((bestException instanceof XAException)) && (((XAException)bestException).errorCode < 0))
/*     */             {
/*     */ 
/* 180 */               bestException = (XAException)o;
/*     */             }
/*     */           }
/* 183 */           else if ((bestException == null) && ((o instanceof JMSException))) {
/* 184 */             bestException = (JMSException)o;
/*     */           }
/*     */         }
/*     */         
/* 188 */         if (!(bestException instanceof XAException)) {
/* 189 */           Exception newException = new XAException(-7);
/* 190 */           newException.initCause(bestException);
/* 191 */           JCATraceAdapter.traceData(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "The exception to return to the transaction manager is not an XAException. A new XAException with XAER_RMFAIL will be generated to throw. The original exception is: ", bestException);
/* 192 */           bestException = newException;
/*     */         }
/*     */         
/* 195 */         JCATraceAdapter.traceData(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "Throwing XAException", bestException);
/* 196 */         throw ((XAException)bestException);
/*     */       }
/*     */       
/*     */ 
/* 200 */       JCATraceAdapter.traceInfo(this, "RecoveryXAResource", "CheckExceptions(ArrayList)", "At least one connection attempt was successful - no exception will be thrown to the TM");
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 205 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "CheckExceptions(ArrayList)");
/*     */     }
/*     */   }
/*     */   
/*     */   public void commit(Xid xid, boolean onePhase)
/*     */     throws XAException
/*     */   {
/* 212 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "commit(Xid, boolean)", new Object[] { xid, Boolean.valueOf(onePhase) });
/*     */     
/*     */ 
/* 215 */     XAConnection[] conns = new XAConnection[0];
/*     */     
/* 217 */     ArrayList<Exception> exceptions = new ArrayList();
/*     */     
/*     */     try
/*     */     {
/* 221 */       conns = getConnections(exceptions);
/*     */       
/* 223 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 225 */         XAConnection conn = conns[i];
/*     */         try
/*     */         {
/* 228 */           conn.start();
/* 229 */           XASession sess = conn.createXASession();
/* 230 */           XAResource xaResource = sess.getXAResource();
/*     */           
/* 232 */           xaResource.commit(xid, onePhase);
/*     */           
/* 234 */           sess.close();
/*     */         }
/*     */         catch (JMSException e) {
/* 237 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "commit(Xid, boolean)", e);
/*     */           
/* 239 */           exceptions.add(e);
/*     */         }
/*     */         catch (XAException e) {
/* 242 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "commit(Xid, boolean)", e);
/*     */           
/* 244 */           exceptions.add(e);
/*     */         }
/*     */       }
/*     */       
/* 248 */       checkExceptions(exceptions);
/*     */     } finally { int i;
/*     */       XAConnection conn;
/* 251 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 253 */         XAConnection conn = conns[i];
/*     */         try {
/* 255 */           conn.close();
/*     */         } catch (JMSException e) {
/* 257 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "commit(Xid, boolean)", e);
/*     */         }
/*     */       }
/* 260 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "commit(Xid, boolean)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XAConnection[] getConnections(ArrayList<Exception> exceptions)
/*     */   {
/* 273 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "getConnections(ArrayList)");
/*     */     
/* 275 */     ArrayList<XAConnection> conns = new ArrayList();
/*     */     try
/*     */     {
/* 278 */       if (this.connectBindings)
/*     */       {
/* 280 */         if (this.isZOS)
/*     */         {
/* 282 */           JCATraceAdapter.traceInfo(this, "RecoveryXAResource", "getConnections(ArrayList)", "Skipping bindings connection because running on z/OS");
/*     */         } else {
/*     */           try
/*     */           {
/* 286 */             synchronized (this.xacf) {
/* 287 */               this.xacf.setTransportType(0);
/* 288 */               XAConnection conn = this.xacf.createXAConnection(this.actSpec.getUserName(), this.actSpec.getPassword());
/* 289 */               conns.add(conn);
/*     */             }
/*     */             
/*     */           }
/*     */           catch (JMSException e)
/*     */           {
/* 295 */             JCATraceAdapter.traceData(this, "RecoveryXAResource", "getConnections(ArrayList)", "Caught JMSException creating bindings connection. The exception will be added to the stored exception list", e);
/*     */             
/* 297 */             exceptions.add(e);
/*     */           }
/*     */         }
/*     */       }
/*     */       XAConnection conn;
/* 302 */       if (this.connectClient)
/*     */       {
/*     */         try
/*     */         {
/* 306 */           synchronized (this.xacf) {
/* 307 */             this.xacf.setTransportType(1);
/* 308 */             conn = this.xacf.createXAConnection(this.actSpec.getUserName(), this.actSpec.getPassword());
/* 309 */             conns.add(conn);
/*     */           }
/*     */           
/*     */         }
/*     */         catch (JMSException e)
/*     */         {
/* 315 */           JCATraceAdapter.traceData(this, "RecoveryXAResource", "getConnections(ArrayList)", "Caught JMSException creating client connection. The exception will be added to the stored exception list", e);
/*     */           
/* 317 */           exceptions.add(e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 323 */       XAConnection[] xaConns = (XAConnection[])conns.toArray(new XAConnection[0]);
/*     */       
/* 325 */       if (JCATraceAdapter.isOn) {
/* 326 */         JCATraceAdapter.traceData(this, "RecoveryXAResource", "getConnections(ArrayList)", "Returning " + xaConns.length + " connections", xaConns);
/*     */       }
/*     */       
/* 329 */       return xaConns;
/*     */     }
/*     */     finally
/*     */     {
/* 333 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "getConnections(ArrayList)");
/*     */     }
/*     */   }
/*     */   
/*     */   public void end(Xid xid, int flags)
/*     */     throws XAException
/*     */   {
/* 340 */     XAException ex = new XAException(-6);
/* 341 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "end(Xid, int)", "This method should not be called on a RecoveryXAResource. Throwing XAException", ex);
/*     */     
/* 343 */     throw ex;
/*     */   }
/*     */   
/*     */   public void forget(Xid xid) throws XAException
/*     */   {
/* 348 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "forget(Xid)", new Object[] { xid });
/*     */     
/* 350 */     XAConnection[] conns = new XAConnection[0];
/*     */     
/* 352 */     ArrayList<Exception> exceptions = new ArrayList();
/*     */     
/*     */     try
/*     */     {
/* 356 */       conns = getConnections(exceptions);
/*     */       
/* 358 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 360 */         XAConnection conn = conns[i];
/*     */         try
/*     */         {
/* 363 */           conn.start();
/* 364 */           XASession sess = conn.createXASession();
/* 365 */           XAResource xaResource = sess.getXAResource();
/*     */           
/* 367 */           xaResource.forget(xid);
/*     */           
/* 369 */           sess.close();
/*     */         }
/*     */         catch (JMSException e) {
/* 372 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "forget(Xid)", e);
/*     */           
/*     */ 
/* 375 */           exceptions.add(e);
/*     */         } catch (XAException e) {
/* 377 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "forget(Xid)", e);
/*     */           
/*     */ 
/* 380 */           exceptions.add(e);
/*     */         }
/*     */       }
/*     */       
/* 384 */       checkExceptions(exceptions);
/*     */     } finally { int i;
/*     */       Connection conn;
/* 387 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 389 */         Connection conn = conns[i];
/*     */         try {
/* 391 */           conn.close();
/*     */         } catch (JMSException e) {
/* 393 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "forget(Xid)", e);
/*     */         }
/*     */       }
/*     */       
/* 397 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "forget(Xid)");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getTransactionTimeout()
/*     */     throws XAException
/*     */   {
/* 404 */     XAException ex = new XAException(-6);
/* 405 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "getTransactionTimeout()", "This method should not be called on a RecoveryXAResource. Throwing XAException", ex);
/*     */     
/* 407 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSameRM(XAResource xares)
/*     */     throws XAException
/*     */   {
/* 414 */     JCATraceAdapter.traceInfo(this, "RecoveryXAResource", "isSameRM(XAResource)", "Returning false");
/* 415 */     return false;
/*     */   }
/*     */   
/*     */   public int prepare(Xid xid) throws XAException {
/* 419 */     XAException ex = new XAException(-6);
/* 420 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "prepare(Xid)", "This method should not be called on a RecoveryXAResource. Throwing XAException", ex);
/*     */     
/* 422 */     throw ex;
/*     */   }
/*     */   
/*     */   public Xid[] recover(int flag) throws XAException
/*     */   {
/* 427 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "recover(int)", new Object[] { Integer.valueOf(flag) });
/*     */     
/* 429 */     XAConnection[] conns = new XAConnection[0];
/*     */     
/* 431 */     HashSet<Xid> allXids = new HashSet();
/*     */     
/* 433 */     ArrayList<Exception> exceptions = new ArrayList();
/*     */     
/*     */     try
/*     */     {
/* 437 */       conns = getConnections(exceptions);
/*     */       
/* 439 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 441 */         XAConnection conn = conns[i];
/*     */         try
/*     */         {
/* 444 */           conn.start();
/* 445 */           XASession sess = conn.createXASession();
/* 446 */           XAResource xaResource = sess.getXAResource();
/*     */           
/* 448 */           Xid[] xids = xaResource.recover(flag);
/*     */           
/* 450 */           for (int j = 0; j < xids.length; j++) {
/* 451 */             allXids.add(xids[j]);
/*     */           }
/*     */           
/* 454 */           sess.close();
/*     */         }
/*     */         catch (JMSException e) {
/* 457 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "recover(int)", e);
/*     */           
/* 459 */           exceptions.add(e);
/*     */         } catch (XAException e) {
/* 461 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "recover(int)", e);
/*     */           
/* 463 */           exceptions.add(e);
/*     */         }
/*     */       }
/*     */       
/* 467 */       checkExceptions(exceptions);
/*     */       
/* 469 */       Xid[] xids = (Xid[])allXids.toArray(new Xid[0]);
/*     */       
/* 471 */       JCATraceAdapter.traceData(this, "RecoveryXAResource", "recover(int)", "Returning: ", xids);
/*     */       int i;
/* 473 */       if (JCATraceAdapter.isOn) {
/* 474 */         for (i = 0; i < xids.length; i++)
/* 475 */           JCATraceAdapter.traceData(this, "RecoveryXAResource", "recover(int)", "xids[" + i + "]", xids[i].toString());
/*     */       }
/*     */       int i;
/*     */       Connection conn;
/* 479 */       return xids;
/*     */     }
/*     */     finally {
/* 482 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 484 */         Connection conn = conns[i];
/*     */         try {
/* 486 */           conn.close();
/*     */         } catch (JMSException e) {
/* 488 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "recover(int)", e);
/*     */         }
/*     */       }
/*     */       
/* 492 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "recover(int)");
/*     */     }
/*     */   }
/*     */   
/*     */   public void rollback(Xid xid)
/*     */     throws XAException
/*     */   {
/* 499 */     JCATraceAdapter.traceEntry(this, "RecoveryXAResource", "rollback(Xid)", new Object[] { xid });
/*     */     
/* 501 */     XAConnection[] conns = new XAConnection[0];
/*     */     
/* 503 */     ArrayList<Exception> exceptions = new ArrayList();
/*     */     
/*     */     try
/*     */     {
/* 507 */       conns = getConnections(exceptions);
/*     */       
/* 509 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 511 */         XAConnection conn = conns[i];
/*     */         try
/*     */         {
/* 514 */           conn.start();
/* 515 */           XASession sess = conn.createXASession();
/* 516 */           XAResource xaResource = sess.getXAResource();
/*     */           
/* 518 */           xaResource.rollback(xid);
/*     */           
/* 520 */           sess.close();
/*     */         }
/*     */         catch (JMSException e) {
/* 523 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "rollback(Xid)", e);
/*     */           
/* 525 */           exceptions.add(e);
/*     */         }
/*     */         catch (XAException e) {
/* 528 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "rollback(Xid)", e);
/*     */           
/* 530 */           exceptions.add(e);
/*     */         }
/*     */       }
/*     */       
/* 534 */       checkExceptions(exceptions);
/*     */     } finally { int i;
/*     */       Connection conn;
/* 537 */       for (int i = 0; i < conns.length; i++)
/*     */       {
/* 539 */         Connection conn = conns[i];
/*     */         try {
/* 541 */           conn.close();
/*     */         } catch (JMSException e) {
/* 543 */           JCATraceAdapter.traceException(this, "RecoveryXAResource", "rollback(Xid)", e);
/*     */         }
/*     */       }
/*     */       
/* 547 */       JCATraceAdapter.traceExit(this, "RecoveryXAResource", "rollback(Xid)");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean setTransactionTimeout(int seconds) throws XAException
/*     */   {
/* 553 */     XAException ex = new XAException(-6);
/* 554 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "setTransactionTimeout(int)", "This method should not be called on a RecoveryXAResource. Throwing XAException", ex);
/*     */     
/* 556 */     throw ex;
/*     */   }
/*     */   
/*     */   public void start(Xid xid, int flags) throws XAException {
/* 560 */     XAException ex = new XAException(-6);
/* 561 */     JCATraceAdapter.traceData(this, "RecoveryXAResource", "start(Xid, int)", "This method should not be called on a RecoveryXAResource. Throwing XAException", ex);
/*     */     
/* 563 */     throw ex;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/RecoveryXAResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */