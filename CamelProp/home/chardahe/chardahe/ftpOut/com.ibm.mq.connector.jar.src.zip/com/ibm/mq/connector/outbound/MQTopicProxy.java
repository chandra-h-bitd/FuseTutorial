/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQDestination;
/*     */ import com.ibm.msg.client.jms.JmsDestination;
/*     */ import com.ibm.msg.client.jms.JmsFactoryFactory;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Topic;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MQTopicProxy
/*     */   extends MQDestinationProxy
/*     */   implements Topic
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/MQTopicProxy.java";
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   
/*     */   public MQTopicProxy()
/*     */     throws JMSException
/*     */   {
/*  72 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "<init>");
/*     */     
/*  74 */     JmsFactoryFactory fac = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/*  75 */     this.theDestination = fac.createTopic(null);
/*     */     
/*  77 */     JCATraceAdapter.traceExit(this, "MQTopicProxy", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MQTopicProxy(String tName)
/*     */     throws JMSException
/*     */   {
/*  88 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "<init>(String)");
/*     */     
/*  90 */     JmsFactoryFactory fac = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/*  91 */     this.theDestination = fac.createTopic(tName);
/*     */     
/*  93 */     JCATraceAdapter.traceExit(this, "MQTopicProxy", "<init>(String)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseTopicName()
/*     */     throws JMSException
/*     */   {
/* 107 */     return this.theDestination.getStringProperty("XMSC_DESTINATION_NAME");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseTopicName(String tName)
/*     */     throws JMSException
/*     */   {
/* 118 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBaseTopicName()");
/*     */     try {
/* 120 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBaseTopicName()", "topicName: ", tName);
/* 121 */       this.theDestination.setStringProperty("XMSC_DESTINATION_NAME", tName.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 125 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBaseTopicName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrokerCCDurSubQueue()
/*     */     throws JMSException
/*     */   {
/* 136 */     return this.theDestination.getStringProperty("brokerCCDurSubQueue");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBrokerCCDurSubQueue(String arg0)
/*     */     throws JMSException
/*     */   {
/* 146 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBrokerCCDurSubQueue()");
/*     */     try {
/* 148 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBrokerCCDurSubQueue()", "brokerCCDurSubQueue: ", arg0);
/*     */       
/* 150 */       this.theDestination.setStringProperty("brokerCCDurSubQueue", arg0.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 154 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBrokerCCDurSubQueue()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrokerDurSubQueue()
/*     */     throws JMSException
/*     */   {
/* 165 */     return this.theDestination.getStringProperty("brokerDurSubQueue");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBrokerDurSubQueue(String arg0)
/*     */     throws JMSException
/*     */   {
/* 175 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBrokerDurSubQueue()");
/*     */     try {
/* 177 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBrokerDurSubQueue()", "brokerDurSubQueue: ", arg0);
/*     */       
/* 179 */       this.theDestination.setStringProperty("brokerDurSubQueue", arg0.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 183 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBrokerDurSubQueue()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrokerPubQueue()
/*     */     throws JMSException
/*     */   {
/* 194 */     return this.theDestination.getStringProperty("XMSC_WMQ_BROKER_PUBQ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBrokerPubQueue(String arg0)
/*     */     throws JMSException
/*     */   {
/* 204 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBrokerPubQueue()");
/*     */     try {
/* 206 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBrokerPubQueue()", "brokerPubQueue: ", arg0);
/*     */       
/* 208 */       this.theDestination.setStringProperty("XMSC_WMQ_BROKER_PUBQ", arg0.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 212 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBrokerPubQueue()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrokerPubQueueManager()
/*     */     throws JMSException
/*     */   {
/* 223 */     return this.theDestination.getStringProperty("XMSC_WMQ_BROKER_PUBQ_QMGR");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBrokerPubQueueManager(String arg0)
/*     */     throws JMSException
/*     */   {
/* 233 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBrokerPubQueueManager()");
/*     */     try {
/* 235 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBrokerPubQueueManager()", "brokerPubQueueManager: ", arg0);
/*     */       
/* 237 */       this.theDestination.setStringProperty("XMSC_WMQ_BROKER_PUBQ_QMGR", arg0.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 241 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBrokerPubQueueManager()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrokerVersion()
/*     */     throws JMSException
/*     */   {
/* 252 */     int i = this.theDestination.getIntProperty("brokerVersion");
/* 253 */     return i == 1 ? "1" : "2";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBrokerVersion(String s)
/*     */     throws JMSException
/*     */   {
/* 264 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "setBrokerVersion(String)");
/*     */     try {
/* 266 */       JCATraceAdapter.traceData(this, "MQTopicProxy", "setBrokerVersion(String)", "brokerVersion: ", s);
/*     */       
/* 268 */       int bv = Integer.parseInt(s.trim()) - 1;
/* 269 */       if ((bv == 0) || (bv == 1)) {
/* 270 */         JCATraceAdapter.traceInfo(this, "MQTopicProxy", "setBrokerVersion(String)", "broker Version: " + s + ", mapped to " + bv);
/*     */         
/* 272 */         this.theDestination.setIntProperty("brokerVersion", bv);
/*     */       }
/*     */       else
/*     */       {
/* 276 */         this.inserts.clear();
/* 277 */         this.inserts.put("JCA_CONFIG_PROPERTY", "brokerVersion");
/* 278 */         this.inserts.put("JCA_CONFIG_VALUE", s);
/* 279 */         this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("brokerVersion")));
/*     */         
/*     */ 
/* 282 */         JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/* 287 */       this.inserts.clear();
/* 288 */       this.inserts.put("JCA_CONFIG_PROPERTY", "brokerVersion");
/* 289 */       this.inserts.put("JCA_CONFIG_VALUE", s);
/* 290 */       this.inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(this.theDestination.getIntProperty("brokerVersion")));
/*     */       
/*     */ 
/* 293 */       JCAMessageBuilder.buildWarning("MQJCA4006", this.inserts);
/*     */     }
/*     */     finally
/*     */     {
/* 297 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "setBrokerVersion(String)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTopicName()
/*     */     throws JMSException
/*     */   {
/* 309 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "getTopicName()");
/*     */     try {
/* 311 */       return "topic://" + this.theDestination.getStringProperty("XMSC_DESTINATION_NAME");
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 316 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "getTopicName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Topic getMQTopic()
/*     */   {
/* 329 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "getTopicName()");
/*     */     try {
/* 331 */       return (Topic)this.theDestination;
/*     */     }
/*     */     finally
/*     */     {
/* 335 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "getTopicName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference getReference()
/*     */     throws NamingException
/*     */   {
/* 348 */     JCATraceAdapter.traceEntry(this, "MQTopicProxy", "getReference()");
/*     */     try {
/* 350 */       if ((this.theDestination instanceof Referenceable)) {
/* 351 */         Reference ref = ((MQDestination)this.theDestination).getReference();
/* 352 */         JCATraceAdapter.traceData(this, "MQTopicProxy", "getReference()", "reference: ", ref.getClassName() + "::" + ref.getFactoryClassName());
/*     */         
/*     */ 
/* 355 */         return ref;
/*     */       }
/*     */       
/* 358 */       throw new NamingException("getReference() called but destination is not referenceable");
/*     */     }
/*     */     finally
/*     */     {
/* 362 */       JCATraceAdapter.traceExit(this, "MQTopicProxy", "getReference()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/MQTopicProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */