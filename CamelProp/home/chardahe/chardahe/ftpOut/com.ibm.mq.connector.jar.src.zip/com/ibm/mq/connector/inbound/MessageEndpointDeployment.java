/*      */ package com.ibm.mq.connector.inbound;
/*      */ 
/*      */ import com.ibm.mq.MQException;
/*      */ import com.ibm.mq.connector.DestinationBuilder;
/*      */ import com.ibm.mq.connector.JCARuntimeHelper;
/*      */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*      */ import com.ibm.mq.connector.configuration.TransportTypeEnum;
/*      */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*      */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*      */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*      */ import com.ibm.mq.jms.ConnectionBrowser;
/*      */ import com.ibm.mq.jms.MQConnection;
/*      */ import com.ibm.mq.jms.MQXAConnection;
/*      */ import com.ibm.mq.jms.MessageReferenceHandler;
/*      */ import com.ibm.msg.client.commonservices.CSIException;
/*      */ import com.ibm.msg.client.commonservices.workqueue.WorkQueueManager;
/*      */ import com.ibm.msg.client.wmq.common.internal.Reason;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import javax.jms.Connection;
/*      */ import javax.jms.ConnectionConsumer;
/*      */ import javax.jms.Destination;
/*      */ import javax.jms.ExceptionListener;
/*      */ import javax.jms.IllegalStateException;
/*      */ import javax.jms.JMSException;
/*      */ import javax.jms.Queue;
/*      */ import javax.jms.Session;
/*      */ import javax.jms.Topic;
/*      */ import javax.jms.XAConnection;
/*      */ import javax.resource.ResourceException;
/*      */ import javax.resource.spi.ActivationSpec;
/*      */ import javax.resource.spi.ResourceAdapterInternalException;
/*      */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*      */ import javax.resource.spi.work.ExecutionContext;
/*      */ import javax.resource.spi.work.Work;
/*      */ import javax.resource.spi.work.WorkEvent;
/*      */ import javax.resource.spi.work.WorkException;
/*      */ import javax.resource.spi.work.WorkListener;
/*      */ import javax.resource.spi.work.WorkManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MessageEndpointDeployment
/*      */   implements WorkListener, ExceptionListener
/*      */ {
/*      */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*      */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/MessageEndpointDeployment.java";
/*  110 */   private ActivationSpecImpl theSpec = null;
/*      */   
/*      */ 
/*  113 */   private WorkManager theWorkManager = null;
/*      */   
/*      */ 
/*  116 */   private ServerSessionPoolImpl thePool = null;
/*      */   
/*      */ 
/*  119 */   private ConnectionConsumer theConsumer = null;
/*      */   
/*      */ 
/*  122 */   private ConnectionBrowser theBrowser = null;
/*      */   
/*      */ 
/*  125 */   private boolean isTransacted = false;
/*      */   
/*      */ 
/*  128 */   private volatile boolean haltResubmission = false;
/*      */   
/*      */ 
/*  131 */   private volatile boolean reconnectionInProgress = false;
/*      */   
/*      */ 
/*  134 */   private volatile boolean hasStopped = false;
/*      */   
/*      */ 
/*  137 */   private AtomicBoolean isProcessingException = new AtomicBoolean(false);
/*      */   
/*      */ 
/*  140 */   private NonASFManagerThread nonASFThread = null;
/*  141 */   private Set<NonASFWorkImpl> nonASFWorkImpls = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  146 */   private int sessionPoolExitTimeout = 120000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private ResourceAdapterImpl theResourceAdapter = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  156 */   private MessageEndpointFactory theEndpointFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   private Connection theConnection = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   private Destination theDestination = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  173 */   private String theMessageSelector = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   private int maxMessages = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   private boolean failedLastTime = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageEndpointDeployment(ResourceAdapterImpl ra, MessageEndpointFactory fac, ActivationSpec spec, WorkManager wm, boolean transacted)
/*      */     throws ResourceException
/*      */   {
/*  204 */     if (JCATraceAdapter.isOn) {
/*  205 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "<init>", new Object[] { ra, fac, spec, wm, Boolean.valueOf(transacted) });
/*      */     }
/*      */     
/*      */ 
/*  209 */     this.theResourceAdapter = ra;
/*  210 */     this.theEndpointFactory = fac;
/*  211 */     this.theWorkManager = wm;
/*  212 */     this.isTransacted = transacted;
/*      */     
/*      */ 
/*      */ 
/*  216 */     spec.validate();
/*      */     
/*      */ 
/*  219 */     this.theSpec = ((ActivationSpecImpl)spec);
/*      */     
/*      */ 
/*  222 */     this.maxMessages = this.theSpec.getMaxMessages();
/*      */     
/*      */ 
/*  225 */     if (this.theResourceAdapter.getStartupRetryCount() > 0)
/*      */     {
/*      */ 
/*  228 */       connect(true);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  233 */       acquireConnection();
/*      */       
/*  235 */       startDelivery();
/*      */     }
/*      */     
/*      */ 
/*  239 */     if (JCATraceAdapter.isOn) {
/*  240 */       JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "<init>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void acquireConnection()
/*      */     throws ResourceAdapterInternalException
/*      */   {
/*  253 */     if (JCATraceAdapter.isOn) {
/*  254 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "acquireConnection()");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  263 */       if ((this.isTransacted) && (this.theSpec.getTransportTypeEnum() == TransportTypeEnum.BINDINGS_THEN_CLIENT) && (this.theResourceAdapter.isZOS())) {
/*      */         try
/*      */         {
/*  266 */           this.theSpec.setTransportType("BINDINGS");
/*      */           
/*  268 */           this.theConnection = ConnectionHandler.getInstance().allocateConnection(this.theSpec, this.isTransacted, true);
/*      */ 
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  273 */           this.theSpec.setTransportType("CLIENT");
/*      */           
/*  275 */           this.theConnection = ConnectionHandler.getInstance().allocateConnection(this.theSpec, this.isTransacted, true);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  281 */         this.theConnection = ConnectionHandler.getInstance().allocateConnection(this.theSpec, this.isTransacted, true);
/*      */       }
/*      */       
/*      */ 
/*  285 */       if (JCATraceAdapter.isOn) {
/*  286 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "acquireConnection()", "acquired connection: " + this.theConnection);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  291 */       if (JCATraceAdapter.isOn) {
/*  292 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "acquireConnection()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startDelivery()
/*      */     throws ResourceException
/*      */   {
/*  309 */     if (JCATraceAdapter.isOn) {
/*  310 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "startDelivery()");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  315 */       this.theConnection.setExceptionListener(this);
/*      */     }
/*      */     catch (JMSException je)
/*      */     {
/*  319 */       HashMap<String, String> inserts = new HashMap();
/*  320 */       inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/*  321 */       JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*      */       
/*  323 */       JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "startDelivery()", je);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  328 */       this.theDestination = DestinationBuilder.createDestination(this.theSpec);
/*      */       
/*  330 */       if (this.theSpec.getNonASFTimeout() <= 0)
/*      */       {
/*  332 */         startDeliveryASF();
/*      */       }
/*      */       else
/*      */       {
/*  336 */         this.haltResubmission = false;
/*      */         
/*  338 */         startDeliveryNonASF();
/*      */       }
/*      */       
/*  341 */       this.reconnectionInProgress = false;
/*      */       
/*  343 */       this.theConnection.start();
/*  344 */       this.hasStopped = false;
/*      */     }
/*      */     catch (CSIException ce) {
/*  347 */       HashMap<String, Object> inserts = new HashMap();
/*  348 */       inserts.put("JCA_ENDPOINT", this.theSpec.toString());
/*  349 */       inserts.put("JCA_JMS_EXCEPTION", ce);
/*  350 */       JCAMessageBuilder.buildWarning("MQJCA4023", inserts);
/*      */       
/*      */ 
/*  353 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA4028", ce));
/*      */     }
/*      */     catch (JMSException je) {
/*  356 */       HashMap<String, Object> inserts = new HashMap();
/*  357 */       inserts.put("JCA_ENDPOINT", this.theSpec.toString());
/*  358 */       inserts.put("JCA_JMS_EXCEPTION", je);
/*  359 */       JCAMessageBuilder.buildWarning("MQJCA4023", inserts);
/*      */       
/*      */ 
/*  362 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*      */     }
/*      */     finally
/*      */     {
/*  366 */       if (JCATraceAdapter.isOn) {
/*  367 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "startDelivery()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startDeliveryASF()
/*      */     throws JMSException
/*      */   {
/*  379 */     if (JCATraceAdapter.isOn) {
/*  380 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "startDeliveryASF()");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  385 */       this.thePool = new ServerSessionPoolImpl(this, this.theConnection, this.theSpec.getMaxPoolDepth());
/*      */       
/*  387 */       this.thePool.setIdleTimeout(this.theSpec.getPoolTimeout());
/*      */       
/*  389 */       createConnectionConsumer();
/*      */     }
/*      */     finally
/*      */     {
/*  393 */       if (JCATraceAdapter.isOn) {
/*  394 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "startDeliveryASF()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startDeliveryNonASF()
/*      */     throws CSIException, JMSException
/*      */   {
/*  407 */     if (JCATraceAdapter.isOn) {
/*  408 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "startDeliveryNonASF()");
/*      */     }
/*      */     try
/*      */     {
/*  412 */       this.nonASFThread = new NonASFManagerThread(this);
/*  413 */       WorkQueueManager.enqueue(this.nonASFThread, 0, false);
/*      */       
/*  415 */       int numPoolThreads = this.theSpec.getMaxPoolDepth();
/*      */       
/*      */ 
/*  418 */       if ((this.theDestination instanceof Topic)) {
/*  419 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "startDeliveryNonASF()", "Using single thread for non-ASF topic delivery");
/*  420 */         numPoolThreads = 1;
/*      */       }
/*      */       
/*      */ 
/*  424 */       for (int i = 0; i < numPoolThreads; i++) {
/*  425 */         Session s = null;
/*      */         
/*  427 */         if ((this.theConnection instanceof XAConnection)) {
/*  428 */           s = ((XAConnection)this.theConnection).createXASession();
/*      */         }
/*      */         else
/*      */         {
/*  432 */           s = this.theConnection.createSession(this.theSpec.getNonASFRollbackEnabled(), 1);
/*      */         }
/*      */         NonASFWorkImpl w;
/*      */         NonASFWorkImpl w;
/*  436 */         if (((this.theDestination instanceof Topic)) && (this.theSpec.getSubscriptionDurability().equals("Durable"))) {
/*  437 */           w = new NonASFWorkImpl(this, s, (Topic)this.theDestination, this.theSpec.getSubscriptionName(), this.theSpec.getMessageSelector(), this.theSpec.getNonASFTimeout());
/*      */         }
/*      */         else {
/*  440 */           w = new NonASFWorkImpl(this, s, this.theDestination, this.theSpec.getMessageSelector(), this.theSpec.getNonASFTimeout());
/*      */         }
/*  442 */         this.nonASFWorkImpls.add(w);
/*      */         
/*  444 */         submitWork(w);
/*      */       }
/*      */     }
/*      */     catch (CSIException ce)
/*      */     {
/*  449 */       HashMap<String, String> info = new HashMap();
/*  450 */       info.put("CSIException", ce.getMessage());
/*  451 */       JCATraceAdapter.ffst(this, "startDeliveryNonASF()", "JCA02003", info);
/*  452 */       if (JCATraceAdapter.isOn) {
/*  453 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "startDeliveryNonASF()", "start failed with CSIException: " + ce.getMessage());
/*      */       }
/*  455 */       throw ce;
/*      */     }
/*      */     finally
/*      */     {
/*  459 */       if (JCATraceAdapter.isOn) {
/*  460 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "startDeliveryNonASF()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/*  474 */     if (JCATraceAdapter.isOn) {
/*  475 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "stop()");
/*      */     }
/*      */     try
/*      */     {
/*  479 */       if (!this.hasStopped)
/*      */       {
/*  481 */         if (this.theSpec.getNonASFTimeout() <= 0) {
/*  482 */           stopDeliveryASF();
/*      */         }
/*      */         else {
/*  485 */           stopDeliveryNonASF();
/*      */         }
/*      */         
/*  488 */         ConnectionHandler.getInstance().destroyConnection(this.theConnection);
/*  489 */         this.hasStopped = true;
/*      */ 
/*      */       }
/*  492 */       else if (JCATraceAdapter.isOn) {
/*  493 */         JCATraceAdapter.traceData(this, "MessageEndpointDeployment", "stop()", "already stopped", null);
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/*  499 */       if (JCATraceAdapter.isOn) {
/*  500 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "stop()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void stopDeliveryNonASF()
/*      */   {
/*  514 */     if (JCATraceAdapter.isOn) {
/*  515 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "stopDeliveryNonASF()");
/*      */     }
/*      */     try
/*      */     {
/*  519 */       this.haltResubmission = true;
/*      */       
/*  521 */       for (NonASFWorkImpl w : this.nonASFWorkImpls) {
/*  522 */         if (JCATraceAdapter.isOn) {
/*  523 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "stopDeliveryNonASF()", "stopping: " + w);
/*      */         }
/*  525 */         w.stop();
/*      */       }
/*      */       
/*  528 */       this.nonASFWorkImpls.clear();
/*      */       
/*      */ 
/*  531 */       if (this.nonASFThread != null) {
/*  532 */         this.nonASFThread.stop();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  537 */       if (JCATraceAdapter.isOn) {
/*  538 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "stopDeliveryNonASF()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void stopDeliveryASF()
/*      */   {
/*  546 */     if (JCATraceAdapter.isOn) {
/*  547 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "stopDeliveryASF()");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  554 */       if (this.thePool != null) {
/*  555 */         this.thePool.setIsClosing(true);
/*      */       }
/*      */       
/*  558 */       if (this.theConsumer != null)
/*      */       {
/*  560 */         this.theConsumer.close();
/*      */       }
/*  562 */       if (this.theBrowser != null)
/*      */       {
/*  564 */         this.theBrowser.close();
/*      */       }
/*      */       
/*      */     }
/*      */     catch (JMSException je)
/*      */     {
/*  570 */       HashMap<String, String> inserts = new HashMap();
/*  571 */       inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/*  572 */       JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*      */       
/*  574 */       if (JCATraceAdapter.isOn) {
/*  575 */         JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "stopDeliveryASF()", je);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  582 */         if (this.thePool != null) {
/*  583 */           this.thePool.close();
/*      */         }
/*      */       }
/*      */       catch (JMSException je) {
/*  587 */         HashMap<String, String> inserts = new HashMap();
/*  588 */         inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/*  589 */         JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*      */         
/*  591 */         if (JCATraceAdapter.isOn) {
/*  592 */           JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "stopDeliveryASF()", je);
/*      */         }
/*      */       }
/*  595 */       if (this.thePool != null) {
/*  596 */         this.thePool.setIsClosing(false);
/*      */       }
/*      */       
/*  599 */       if (JCATraceAdapter.isOn) {
/*  600 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "stopDeliveryASF()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createConnectionConsumer()
/*      */     throws JMSException
/*      */   {
/*  613 */     if (JCATraceAdapter.isOn) {
/*  614 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "createConnectionConsumer()");
/*      */     }
/*      */     try {
/*  617 */       this.theMessageSelector = this.theSpec.getMessageSelector();
/*      */       
/*  619 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "using Message Selector: " + this.theMessageSelector);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  625 */       JCARuntimeHelper helper = ResourceAdapterImpl.getJCARuntimeHelper();
/*      */       
/*      */ 
/*  628 */       if ((helper.getEnvironment() == 1) || (helper.getEnvironment() == 64) || ((helper.getEnvironment() & 0x80) == 128))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  633 */         if (JCATraceAdapter.isOn) {
/*  634 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "running in a distributed server environment");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  640 */         if (("javax.jms.Topic".equals(this.theSpec.getDestinationType())) && ("Durable".equals(this.theSpec.getSubscriptionDurability()))) {
/*  641 */           this.theConsumer = this.theConnection.createDurableConnectionConsumer((Topic)this.theDestination, this.theSpec.getSubscriptionName(), this.theMessageSelector, this.thePool, this.maxMessages);
/*  642 */           if (JCATraceAdapter.isOn) {
/*  643 */             JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "created DurableConnectionConsumer: " + this.theConsumer);
/*      */           }
/*      */         }
/*      */         else {
/*  647 */           if ((this.theConnection instanceof MQXAConnection)) {
/*  648 */             this.theConsumer = this.theConnection.createConnectionConsumer(this.theDestination, this.theMessageSelector, this.thePool, 1);
/*      */           } else {
/*  650 */             this.theConsumer = this.theConnection.createConnectionConsumer(this.theDestination, this.theMessageSelector, this.thePool, this.maxMessages);
/*      */           }
/*  652 */           if (JCATraceAdapter.isOn) {
/*  653 */             JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "created ConnectionConsumer: " + this.theConsumer);
/*      */           }
/*      */         }
/*      */       }
/*  657 */       else if ((helper.getEnvironment() == 16) || (helper.getEnvironment() == 32))
/*      */       {
/*  659 */         if (JCATraceAdapter.isOn) {
/*  660 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "running in the z/WAS environment");
/*      */         }
/*      */         
/*  663 */         if (helper.getEnvironment() == 16)
/*      */         {
/*      */ 
/*  666 */           String qmName = helper.resolveConnection(this.theConnection);
/*      */           
/*  668 */           String destName = null;
/*  669 */           if ((this.theDestination instanceof Queue)) {
/*  670 */             destName = ((Queue)this.theDestination).getQueueName();
/*      */           }
/*      */           else {
/*  673 */             destName = ((Topic)this.theDestination).getTopicName();
/*      */           }
/*      */           
/*  676 */           MessageReferenceHandler handler = helper.getCraMessageReferenceHandler(this.theEndpointFactory, this.theSpec, qmName, destName);
/*      */           
/*  678 */           if ((this.theDestination instanceof Queue)) {
/*  679 */             this.theBrowser = ((MQConnection)this.theConnection).createConnectionBrowser((Queue)this.theDestination, this.theMessageSelector, handler, this.maxMessages);
/*      */ 
/*      */ 
/*      */           }
/*  683 */           else if (("javax.jms.Topic".equals(this.theSpec.getDestinationType())) && ("Durable".equals(this.theSpec.getSubscriptionDurability()))) {
/*  684 */             this.theBrowser = ((MQConnection)this.theConnection).createDurableConnectionBrowser((Topic)this.theDestination, this.theSpec.getSubscriptionName(), this.theMessageSelector, handler, this.maxMessages, true);
/*      */           }
/*      */           else
/*      */           {
/*  688 */             this.theBrowser = ((MQConnection)this.theConnection).createConnectionBrowser((Topic)this.theDestination, this.theMessageSelector, handler, 2);
/*      */           }
/*      */           
/*  691 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "createConnectionConsumer()", "created ConnectionBrowser: " + this.theBrowser);
/*      */         }
/*      */         else
/*      */         {
/*  695 */           this.theConsumer = helper.getSrConnectionConsumer(this.theEndpointFactory, this.theSpec, this.theConnection, this.theDestination, this.theMessageSelector, this.thePool, this.maxMessages);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  701 */         HashMap<String, Object> info = new HashMap();
/*  702 */         info.put("Environment", new Integer(helper.getEnvironment()));
/*      */         try
/*      */         {
/*  705 */           if (helper.getEnvironment() == 8) {
/*  706 */             JCATraceAdapter.ffst(this, "createConnectionConsumer", "JCA02001", info);
/*      */           }
/*      */           else {
/*  709 */             JCATraceAdapter.ffst(this, "createConnectionConsumer", "JCA02002", info);
/*      */           }
/*      */         }
/*      */         catch (RuntimeException re)
/*      */         {
/*  714 */           throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1001"));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (JMSException e)
/*      */     {
/*  720 */       if (JCATraceAdapter.isOn) {
/*  721 */         JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "createConnectionConsumer()", e);
/*      */       }
/*      */       
/*  724 */       throw e;
/*      */     }
/*      */     finally
/*      */     {
/*  728 */       if (JCATraceAdapter.isOn) {
/*  729 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "createConnectionConsumer()");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected MessageEndpointFactory getEndpointFactory()
/*      */   {
/*  738 */     if (JCATraceAdapter.isOn) {
/*  739 */       JCATraceAdapter.traceData(this, "MessageEndpointDeployment", "getEndpointFactory()", "got value", this.theEndpointFactory);
/*      */     }
/*  741 */     return this.theEndpointFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected ActivationSpec getActivationSpec()
/*      */   {
/*  748 */     if (JCATraceAdapter.isOn) {
/*  749 */       JCATraceAdapter.traceData(this, "MessageEndpointDeployment", "getActivationSpec()", "got value", this.theSpec);
/*      */     }
/*  751 */     return this.theSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Destination getDestination()
/*      */   {
/*  758 */     if (JCATraceAdapter.isOn) {
/*  759 */       JCATraceAdapter.traceData(this, "MessageEndpointDeployment", "getDestination()", "got value", this.theDestination);
/*      */     }
/*  761 */     return this.theDestination;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean isTransacted()
/*      */   {
/*  768 */     if (JCATraceAdapter.isOn) {
/*  769 */       JCATraceAdapter.traceData(this, "MessageEndpointDeployment", "isTransacted()", "got value", Boolean.valueOf(this.isTransacted));
/*      */     }
/*  771 */     return this.isTransacted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onException(JMSException je)
/*      */   {
/*  786 */     if (JCATraceAdapter.isOn) {
/*  787 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "onException(JMSException)", new Object[] { je });
/*  788 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "being called to process exception " + je + ", with linked exception " + je.getLinkedException());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  793 */     boolean connectionBroken = true;
/*  794 */     Exception linkedException = je.getLinkedException();
/*  795 */     if ((linkedException instanceof MQException))
/*      */     {
/*  797 */       int reason = ((MQException)linkedException).getReason();
/*  798 */       connectionBroken = Reason.isConnectionBroken(reason);
/*      */ 
/*      */ 
/*      */     }
/*  802 */     else if ((linkedException instanceof RuntimeException))
/*      */     {
/*  804 */       connectionBroken = false;
/*      */     }
/*      */     
/*  807 */     if (connectionBroken) {
/*  808 */       onException(je);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  814 */     else if (JCATraceAdapter.isOn) {
/*  815 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "ignoring RuntimeException or non connection broken MQException");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  820 */     if (JCATraceAdapter.isOn) {
/*  821 */       JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "onException(JMSException)");
/*      */     }
/*      */   }
/*      */   
/*      */   void onException(Exception e)
/*      */   {
/*  827 */     if (JCATraceAdapter.isOn) {
/*  828 */       JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "onException(JMSException)", e);
/*      */     }
/*      */     
/*  831 */     HashMap<String, String> inserts = new HashMap();
/*  832 */     inserts.put("JCA_ENDPOINT", this.theSpec.toString());
/*  833 */     JCAMessageBuilder.buildWarning("MQJCA4013", inserts);
/*      */     
/*      */ 
/*  836 */     if (this.isProcessingException.compareAndSet(false, true)) {
/*  837 */       if (JCATraceAdapter.isOn) {
/*  838 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "Processing new Exception");
/*      */       }
/*      */     }
/*      */     else {
/*  842 */       if (JCATraceAdapter.isOn) {
/*  843 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "ExceptionListener is already processing an Exception. Returning");
/*      */       }
/*  845 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  849 */       synchronized (this.theEndpointFactory)
/*      */       {
/*  851 */         if (!this.reconnectionInProgress)
/*      */         {
/*  853 */           if (this.theSpec.getNonASFTimeout() <= 0)
/*      */           {
/*      */ 
/*      */ 
/*  857 */             this.thePool.setIsClosing(true);
/*  858 */             waitForServerSessionExit();
/*      */           }
/*      */           else
/*      */           {
/*  862 */             this.haltResubmission = true;
/*      */           }
/*      */           
/*  865 */           stop();
/*      */           
/*  867 */           ConnectionHandler.getInstance().destroyConnection(this.theConnection);
/*  868 */           this.theConnection = null;
/*      */           
/*      */ 
/*  871 */           this.reconnectionInProgress = true;
/*      */           
/*  873 */           connect(false);
/*      */ 
/*      */         }
/*  876 */         else if (JCATraceAdapter.isOn) {
/*  877 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "ignoring Exception, reconnect already in progress");
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  883 */       if (JCATraceAdapter.isOn) {
/*  884 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "onException(JMSException)", "Finished Processing Exception.");
/*      */       }
/*  886 */       this.isProcessingException.set(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void connectionComplete()
/*      */   {
/*  896 */     if (JCATraceAdapter.isOn) {
/*  897 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "connectionComplete()");
/*      */     }
/*      */     try
/*      */     {
/*  901 */       startDelivery();
/*      */       
/*  903 */       HashMap<String, String> inserts = new HashMap();
/*  904 */       inserts.put("JCA_ENDPOINT", this.theSpec.toString());
/*  905 */       JCAMessageBuilder.buildWarning("MQJCA4019", inserts);
/*      */ 
/*      */     }
/*      */     catch (ResourceException re)
/*      */     {
/*  910 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connectionComplete()", "initialization failed for: " + this);
/*  911 */       JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "connectionComplete()", re);
/*      */       
/*  913 */       JCAMessageBuilder.buildWarning("MQJCA4014");
/*      */     }
/*      */     
/*  916 */     if (JCATraceAdapter.isOn) {
/*  917 */       JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "connectionComplete()");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void connect(boolean startup)
/*      */   {
/*  931 */     if (JCATraceAdapter.isOn) {
/*  932 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "connect(boolean)");
/*  933 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "startup? " + startup);
/*  934 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "trying to connect: " + this);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  939 */       acquireConnection();
/*      */       
/*  941 */       startDelivery();
/*      */     }
/*      */     catch (ResourceException re) {
/*  944 */       if (JCATraceAdapter.isOn) {
/*  945 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "initial connect failed, starting helper thread");
/*  946 */         JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "connect(boolean)", re);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  952 */       ConnectionHelperThread runnable = new ConnectionHelperThread(startup ? this.theResourceAdapter.getStartupRetryCount() : this.theResourceAdapter.getReconnectionRetryCount(), startup ? this.theResourceAdapter.getStartupRetryInterval() : this.theResourceAdapter.getReconnectionRetryInterval(), this);
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  958 */         if (JCATraceAdapter.isOn) {
/*  959 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "starting ConnectionHelperThread " + runnable);
/*      */         }
/*  961 */         WorkQueueManager.enqueue(runnable, 0, false);
/*  962 */         if (JCATraceAdapter.isOn) {
/*  963 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "started successfully");
/*      */         }
/*      */         
/*      */       }
/*      */       catch (CSIException csie)
/*      */       {
/*  969 */         HashMap<String, String> info = new HashMap();
/*  970 */         info.put("CSIException", csie.getMessage());
/*  971 */         JCATraceAdapter.ffst(this, "connect(boolean)", "JCA02004", info);
/*  972 */         if (JCATraceAdapter.isOn) {
/*  973 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "connect(boolean)", "start failed with CSIException: " + csie.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/*  978 */       if (JCATraceAdapter.isOn) {
/*  979 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "connect(boolean)");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void submitWork(AbstractWorkImpl w)
/*      */   {
/*  998 */     if (JCATraceAdapter.isOn) {
/*  999 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", new Object[] { w });
/* 1000 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", "hasStopped = " + this.hasStopped);
/* 1001 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", "haltResubmission = " + this.haltResubmission);
/*      */     }
/*      */     
/* 1004 */     boolean workImplSessionClosed = false;
/* 1005 */     if ((w instanceof NonASFWorkImpl)) {
/* 1006 */       workImplSessionClosed = ((NonASFWorkImpl)w).sessionClosed();
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1012 */       if ((!this.haltResubmission) && (!workImplSessionClosed)) {
/* 1013 */         if (JCATraceAdapter.isOn) {
/* 1014 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", "scheduling " + w + " with " + this.theWorkManager);
/*      */         }
/* 1016 */         this.theWorkManager.scheduleWork(w, this.theSpec.getStartTimeout(), new ExecutionContext(), this);
/*      */ 
/*      */       }
/* 1019 */       else if (JCATraceAdapter.isOn) {
/* 1020 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", "Not scheduling " + w + " as submission has been halted");
/*      */       }
/*      */     }
/*      */     catch (WorkException we)
/*      */     {
/* 1025 */       if (JCATraceAdapter.isOn) {
/* 1026 */         JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)", "WorkManager rejected WorkImpl with: " + we);
/*      */       }
/* 1028 */       if (!(w instanceof ASFWorkImpl))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1037 */         this.nonASFThread.registerRejected((NonASFWorkImpl)w);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1042 */       if (JCATraceAdapter.isOn) {
/* 1043 */         JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "submitWork(AbstractWorkImpl)");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void workAccepted(WorkEvent e)
/*      */   {
/* 1056 */     if (JCATraceAdapter.isOn) {
/* 1057 */       traceWorkEvent(e, 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void workStarted(WorkEvent e)
/*      */   {
/* 1069 */     if (JCATraceAdapter.isOn) {
/* 1070 */       traceWorkEvent(e, 3);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void workCompleted(WorkEvent e)
/*      */   {
/* 1083 */     if (JCATraceAdapter.isOn) {
/* 1084 */       traceWorkEvent(e, 4);
/*      */     }
/*      */     
/* 1087 */     if ((e.getWork() instanceof ASFWorkImpl))
/*      */     {
/* 1089 */       releaseSession(e);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1094 */       submitWork((AbstractWorkImpl)e.getWork());
/*      */     }
/*      */     
/* 1097 */     this.failedLastTime = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void workRejected(WorkEvent e)
/*      */   {
/* 1109 */     if (JCATraceAdapter.isOn) {
/* 1110 */       traceWorkEvent(e, 2);
/*      */     }
/*      */     
/*      */ 
/* 1114 */     if ((e.getWork() instanceof AbstractWorkImpl)) {
/* 1115 */       ((AbstractWorkImpl)e.getWork()).setFailingThreadToThis();
/*      */     }
/* 1117 */     ResourceAdapterImpl.getJCARuntimeHelper().deliveryFailed(e.getException(), this.theSpec, this.theEndpointFactory, this.failedLastTime);
/* 1118 */     if ((e.getWork() instanceof AbstractWorkImpl)) {
/* 1119 */       ((AbstractWorkImpl)e.getWork()).unSetFailingThread();
/*      */     }
/* 1121 */     if ((e.getWork() instanceof ASFWorkImpl))
/*      */     {
/* 1123 */       releaseSession(e);
/*      */     }
/*      */     else
/*      */     {
/* 1127 */       this.nonASFThread.registerRejected((NonASFWorkImpl)e.getWork());
/*      */     }
/*      */     
/* 1130 */     this.failedLastTime = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void releaseSession(WorkEvent e)
/*      */   {
/* 1142 */     if (JCATraceAdapter.isOn) {
/* 1143 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "releaseSession(WorkEvent)", new Object[] { e });
/*      */     }
/*      */     
/*      */ 
/* 1147 */     Work w = e.getWork();
/*      */     
/* 1149 */     if ((w instanceof ASFWorkImpl))
/*      */     {
/* 1151 */       Session s = ((ASFWorkImpl)w).getSession();
/*      */       
/*      */ 
/* 1154 */       if (s != null) {
/* 1155 */         if (JCATraceAdapter.isOn) {
/* 1156 */           JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "releaseSession(WorkEvent)", "releasing: " + s);
/*      */         }
/* 1158 */         this.thePool.sessionReleased(s, ((AbstractWorkImpl)w).isDisposeRequired());
/*      */       }
/*      */     }
/*      */     
/* 1162 */     if (JCATraceAdapter.isOn) {
/* 1163 */       JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "releaseSession(WorkEvent)");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean waitForServerSessionExit()
/*      */   {
/* 1176 */     if (JCATraceAdapter.isOn) {
/* 1177 */       JCATraceAdapter.traceEntry(this, "MessageEndpointDeployment", "waitForServerSessionExit()");
/*      */     }
/*      */     
/* 1180 */     boolean timedout = false;
/* 1181 */     int sessionsRemaining = this.thePool.waitForNoSessionsInUse(this.sessionPoolExitTimeout);
/*      */     
/* 1183 */     if (sessionsRemaining != 0)
/*      */     {
/*      */ 
/*      */ 
/* 1187 */       HashMap<String, Object> info = new HashMap();
/* 1188 */       info.put("timeout", new Integer(this.sessionPoolExitTimeout));
/* 1189 */       info.put("sessionsRemaining", new Integer(sessionsRemaining));
/* 1190 */       JCATraceAdapter.ffst(this, "waitForServerSessionExit()", "JCA02007", info);
/*      */       
/* 1192 */       timedout = true;
/*      */     }
/*      */     
/* 1195 */     if (JCATraceAdapter.isOn) {
/* 1196 */       JCATraceAdapter.traceExit(this, "MessageEndpointDeployment", "waitForServerSessionExit()");
/*      */     }
/* 1198 */     return timedout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void traceWorkEvent(WorkEvent e, int expectedType)
/*      */   {
/* 1208 */     Work w = e.getWork();
/*      */     
/*      */ 
/* 1211 */     int type = e.getType();
/* 1212 */     if (type != expectedType) {
/* 1213 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "Unexpected condition: WorkEvent type does not match API call. Got: " + type + ", expected: " + expectedType);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1219 */     switch (type)
/*      */     {
/*      */     case 1: 
/* 1222 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "WorkImpl " + w.toString() + " accepted");
/* 1223 */       break;
/*      */     
/*      */     case 4: 
/* 1226 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "WorkImpl " + w.toString() + " completed");
/* 1227 */       break;
/*      */     
/*      */     case 2: 
/* 1230 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "WorkImpl " + w.toString() + " rejected");
/* 1231 */       break;
/*      */     
/*      */     case 3: 
/* 1234 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "WorkImpl " + w.toString() + " started");
/* 1235 */       break;
/*      */     
/*      */     default: 
/* 1238 */       JCATraceAdapter.traceInfo(this, "MessageEndpointDeployment", "traceWorkEvent(WorkEvent, int)", "Unknown Work event: " + e.getType());
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/MessageEndpointDeployment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */