/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MessageReferenceHandler;
/*     */ import com.ibm.msg.client.commonservices.cssystem.CSSystem;
/*     */ import com.ibm.msg.client.commonservices.cssystem.CSSystem.Platform;
/*     */ import com.ibm.msg.client.commonservices.cssystem.WASSupport;
/*     */ import com.ibm.msg.client.jms.JmsConnection;
/*     */ import java.util.Map;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionConsumer;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.ServerSessionPool;
/*     */ import javax.resource.spi.ActivationSpec;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import javax.transaction.RollbackException;
/*     */ import javax.transaction.SystemException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRuntimeHelperImpl
/*     */   implements JCARuntimeHelper
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2009 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/DefaultRuntimeHelperImpl.java";
/*     */   
/*     */   public void deliveryFailed(Exception e, ActivationSpec spec, MessageEndpointFactory fac, boolean isRepeatedFailure) {}
/*     */   
/*     */   public MessageReferenceHandler getCraMessageReferenceHandler(MessageEndpointFactory fac, ActivationSpec spec, String qmName, String destName)
/*     */     throws JMSException, javax.jms.IllegalStateException
/*     */   {
/*  90 */     throw new javax.jms.IllegalStateException("getCraMessageReferenceHandler environment error");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String resolveConnection(Connection conn)
/*     */   {
/*  99 */     JCATraceAdapter.traceEntry(this, "DefaultRuntimeHelperImpl", "resolveConnection()");
/*     */     
/*     */     try
/*     */     {
/* 103 */       String qmName = null;
/* 104 */       if ((conn instanceof JmsConnection)) {
/*     */         try
/*     */         {
/* 107 */           qmName = ((JmsConnection)conn).getStringProperty("XMSC_WMQ_RESOLVED_QUEUE_MANAGER");
/*     */           
/* 109 */           JCATraceAdapter.traceInfo(this, "DefaultRuntimeHelperImpl", "resolveConnection()", "qmName: " + qmName);
/*     */ 
/*     */         }
/*     */         catch (JMSException je)
/*     */         {
/* 114 */           JCATraceAdapter.traceNonNLSWarning(this, "DefaultRuntimeHelperImpl", "resolveConnection()", "queue manager name lookup threw an exception, returning null", null);
/*     */           
/*     */ 
/*     */ 
/* 118 */           JCATraceAdapter.traceException(this, "DefaultRuntimeHelperImpl", "resolveConnection()", je);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 124 */         JCATraceAdapter.traceNonNLSWarning(this, "DefaultRuntimeHelperImpl", "resolveConnection()", "supplied connection is not a com.ibm.msg.client.jms.JMSConnection: " + conn, null);
/*     */       }
/*     */       
/*     */ 
/* 128 */       return qmName;
/*     */     }
/*     */     finally
/*     */     {
/* 132 */       JCATraceAdapter.traceExit(this, "DefaultRuntimeHelperImpl", "resolveConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEnvironment()
/*     */   {
/* 146 */     boolean isWAS = WASSupport.getWASSupport().isWASCommonServicesPresent();
/* 147 */     if (isWAS) {
/* 148 */       CSSystem.Platform os = CSSystem.currentPlatform();
/* 149 */       if (os == CSSystem.Platform.OS_ZSERIES)
/*     */       {
/* 151 */         return 184;
/*     */       }
/* 153 */       return 192;
/*     */     }
/*     */     
/* 156 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionConsumer getSrConnectionConsumer(MessageEndpointFactory factory, ActivationSpec spec, Connection connection, Destination destination, String messageSelector, ServerSessionPool pool, int maxMessages)
/*     */     throws JMSException, javax.jms.IllegalStateException
/*     */   {
/* 170 */     throw new javax.jms.IllegalStateException("getSrConnectionConsumer environment error");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isSystemMessageListener(MessageListener listener)
/*     */   {
/* 177 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map processArbitraryProperties(Map unprocessedProperties, ConnectionFactory cf)
/*     */     throws InvalidPropertyException
/*     */   {
/* 187 */     return unprocessedProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map processArbitraryProperties(Map unprocessedProperties, Destination dest)
/*     */     throws InvalidPropertyException
/*     */   {
/* 197 */     return unprocessedProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearActivationSpecificationInformation(Object as) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startRRSTransaction()
/*     */     throws java.lang.IllegalStateException, RollbackException, SystemException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startLocalRRSTransaction()
/*     */     throws java.lang.IllegalStateException
/*     */   {
/* 222 */     if (getEnvironment() != 184) {
/* 223 */       throw new IllegalStateException("unsupported outside the z/OS environment");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endLocalRRSTransaction()
/*     */     throws java.lang.IllegalStateException, RollbackException
/*     */   {
/* 233 */     if (getEnvironment() != 184) {
/* 234 */       throw new IllegalStateException("unsupported outside the z/OS environment");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLocalRRSTranId()
/*     */   {
/* 248 */     return -1L;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/DefaultRuntimeHelperImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */