/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.msg.client.jms.JmsExceptionDetail;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DetailedInvalidPropertyException
/*     */   extends InvalidPropertyException
/*     */   implements JmsExceptionDetail
/*     */ {
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/DetailedInvalidPropertyException.java";
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private String explanation;
/*     */   private String useraction;
/*     */   private Map inserts;
/*     */   
/*     */   public DetailedInvalidPropertyException(String message, String id, String explanation, String useraction, Map inserts)
/*     */   {
/*  84 */     super(message, id);
/*     */     
/*  86 */     this.explanation = explanation;
/*  87 */     this.useraction = useraction;
/*  88 */     this.inserts = inserts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExplanation()
/*     */   {
/*  99 */     return this.explanation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserAction()
/*     */   {
/* 110 */     return this.useraction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue(String insertKey)
/*     */   {
/* 126 */     if (null == this.inserts) {
/* 127 */       return null;
/*     */     }
/*     */     
/* 130 */     return (String)this.inserts.get(insertKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getKeys()
/*     */   {
/* 144 */     if (null == this.inserts) {
/* 145 */       return null;
/*     */     }
/*     */     
/* 148 */     return this.inserts.keySet().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 157 */     String result = super.toString();
/*     */     
/* 159 */     if (this.explanation != null) {
/* 160 */       result = result + " " + this.explanation;
/*     */     }
/*     */     
/* 163 */     if (this.useraction != null) {
/* 164 */       result = result + " " + this.useraction;
/*     */     }
/*     */     
/* 167 */     return result;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/DetailedInvalidPropertyException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */