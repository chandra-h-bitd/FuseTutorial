/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.JCARuntimeHelper;
/*     */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ServerSession;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.XASession;
/*     */ import javax.transaction.xa.XAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSessionImpl
/*     */   implements ServerSession
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ServerSessionImpl.java";
/*  74 */   private MessageEndpointDeployment theMessageEndpointDeployment = null;
/*     */   
/*     */ 
/*     */ 
/*  78 */   private Session theSession = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private XAResource xar = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private IsInUseLock isInUseLock = new IsInUseLock(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private boolean isInUse = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private long pooledTime = 0L;
/*     */   
/*     */ 
/* 111 */   private ASFWorkImpl theWork = null;
/*     */   
/*     */ 
/* 114 */   private ServerSessionPoolImpl theServerSessionPool = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   private long removedTime = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerSessionImpl(ServerSessionPoolImpl ssp, MessageEndpointDeployment med, Session s)
/*     */   {
/* 131 */     if (JCATraceAdapter.isOn) {
/* 132 */       JCATraceAdapter.traceEntry(this, "ServerSessionImpl", "<init>");
/*     */     }
/*     */     
/*     */ 
/* 136 */     this.theMessageEndpointDeployment = med;
/* 137 */     this.theSession = s;
/* 138 */     this.theServerSessionPool = ssp;
/*     */     
/* 140 */     this.pooledTime = System.currentTimeMillis();
/*     */     
/* 142 */     if ((s instanceof XASession)) {
/* 143 */       this.xar = ((XASession)s).getXAResource();
/* 144 */       if (JCATraceAdapter.isOn) {
/* 145 */         JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "<init>", "ServerSession is using XA, with XAResource: " + this.xar);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 150 */     this.theWork = new ASFWorkImpl(this.theMessageEndpointDeployment, this.theSession);
/*     */     
/*     */ 
/* 153 */     this.isInUse = true;
/*     */     
/* 155 */     if (JCATraceAdapter.isOn) {
/* 156 */       JCATraceAdapter.traceExit(this, "ServerSessionImpl", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */   AbstractWorkImpl getTheWork() {
/* 161 */     return this.theWork;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getSession()
/*     */   {
/* 170 */     return this.theSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XAResource getXAResource()
/*     */   {
/* 180 */     return this.xar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 190 */     if (JCATraceAdapter.isOn) {
/* 191 */       JCATraceAdapter.traceEntry(this, "ServerSessionImpl", "start()");
/*     */     }
/*     */     
/*     */ 
/* 195 */     if (this.theWork == null) {
/* 196 */       this.theWork = new ASFWorkImpl(this.theMessageEndpointDeployment, this.theSession);
/* 197 */       if (JCATraceAdapter.isOn) {
/* 198 */         JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "start()", "created new WorkImpl: " + this.theWork);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 203 */     if (ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment() == 32)
/*     */     {
/* 205 */       this.theWork.run();
/*     */       
/*     */ 
/* 208 */       Session s = this.theWork.getSession();
/*     */       
/* 210 */       if (s != null) {
/* 211 */         if (JCATraceAdapter.isOn) {
/* 212 */           JCATraceAdapter.traceInfo(this, "ServerSessonImpl", "start()", "releasing: " + s);
/*     */         }
/* 214 */         this.theServerSessionPool.sessionReleased(s);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 220 */       this.theMessageEndpointDeployment.submitWork(this.theWork);
/*     */     }
/*     */     
/*     */ 
/* 224 */     if (JCATraceAdapter.isOn) {
/* 225 */       JCATraceAdapter.traceExit(this, "ServerSessionImpl", "start()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void release()
/*     */   {
/* 235 */     if (JCATraceAdapter.isOn) {
/* 236 */       JCATraceAdapter.traceEntry(this, "ServerSessionImpl", "release()");
/*     */     }
/* 238 */     synchronized (this.isInUseLock)
/*     */     {
/* 240 */       this.isInUse = false;
/*     */       
/* 242 */       this.isInUseLock.notifyAll();
/*     */     }
/*     */     
/* 245 */     this.pooledTime = System.currentTimeMillis();
/*     */     
/* 247 */     if (JCATraceAdapter.isOn) {
/* 248 */       JCATraceAdapter.traceExit(this, "ServerSessionImpl", "release()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 258 */     if (JCATraceAdapter.isOn) {
/* 259 */       JCATraceAdapter.traceEntry(this, "ServerSessionImpl", "close()");
/*     */     }
/*     */     
/* 262 */     synchronized (this.isInUseLock)
/*     */     {
/* 264 */       if (this.theWork.currentThreadIsFailingThread())
/*     */       {
/* 266 */         if (JCATraceAdapter.isOn) {
/* 267 */           JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "workImpl thread being closed is the same as current thread, not waiting.");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 272 */         if (this.isInUse)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 281 */           if (JCATraceAdapter.isOn) {
/* 282 */             JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "Got isInUseLock");
/*     */           }
/*     */           
/* 285 */           while (this.isInUse) {
/* 286 */             if (JCATraceAdapter.isOn) {
/* 287 */               JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "isInUse - waiting");
/*     */             }
/*     */             try {
/* 290 */               this.isInUseLock.wait();
/*     */             }
/*     */             catch (InterruptedException e) {}
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 297 */           if (JCATraceAdapter.isOn) {
/* 298 */             JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "Not isInUse (anymore)");
/*     */           }
/*     */         }
/*     */         
/* 302 */         this.isInUse = true;
/* 303 */         if (JCATraceAdapter.isOn) {
/* 304 */           JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "Marked ServerSession isInUse, released isInUseLock");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 311 */       if (this.theSession != null) {
/* 312 */         this.theSession.close();
/* 313 */         this.theSession = null;
/*     */       }
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 318 */       HashMap<String, Object> inserts = new HashMap();
/* 319 */       inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/* 320 */       JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*     */       
/* 322 */       JCATraceAdapter.traceException(this, "ServerSessionImpl", "close()", je);
/*     */     }
/*     */     finally
/*     */     {
/* 326 */       if (this.theWork.currentThreadIsFailingThread())
/*     */       {
/* 328 */         if (JCATraceAdapter.isOn) {
/* 329 */           JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "close()", "workImpl thread being closed is the same as current thread, not unsetting inUse.");
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 334 */         synchronized (this.isInUseLock) {
/* 335 */           this.isInUse = false;
/* 336 */           this.isInUseLock.notifyAll();
/*     */         }
/*     */       }
/*     */       
/* 340 */       if (JCATraceAdapter.isOn) {
/* 341 */         JCATraceAdapter.traceExit(this, "ServerSessionImpl", "close()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void markInUse()
/*     */   {
/* 352 */     synchronized (this.isInUseLock) {
/* 353 */       this.isInUse = true;
/*     */       
/* 355 */       if (JCATraceAdapter.isOn) {
/* 356 */         JCATraceAdapter.traceInfo(this, "ServerSessionImpl", "markInUse()", "ServerSessionImpl " + this + " is in use");
/*     */         
/*     */ 
/* 359 */         this.removedTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInUse()
/*     */   {
/* 370 */     return this.isInUse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getIdleTime()
/*     */   {
/* 380 */     long idleTime = System.currentTimeMillis() - this.pooledTime;
/* 381 */     return idleTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getInUseTime()
/*     */   {
/* 392 */     long inUseTime = System.currentTimeMillis() - this.removedTime;
/* 393 */     return inUseTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finalize()
/*     */   {
/* 401 */     if (this.theSession != null)
/*     */     {
/* 403 */       this.isInUse = false;
/* 404 */       close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String introspectSelf()
/*     */   {
/* 415 */     String indent = System.getProperty("line.separator") + "\t";
/* 416 */     StringBuffer buffer = new StringBuffer("ServerSessionImpl : " + hashCode());
/*     */     
/* 418 */     buffer.append(indent + "Wrapped JMS Session: " + this.theSession);
/* 419 */     buffer.append(indent + "XA Resource: " + this.xar);
/* 420 */     buffer.append(indent + "In Use: " + this.isInUse);
/*     */     
/* 422 */     if (this.isInUse) {
/* 423 */       buffer.append(indent + "Time In Use: " + getInUseTime() + " ms");
/* 424 */       buffer.append(indent + "Work: " + this.theWork);
/* 425 */       buffer.append(indent + "Message Endpoint Deployment: " + this.theMessageEndpointDeployment);
/*     */     }
/*     */     else {
/* 428 */       buffer.append(indent + "Idle Time: " + getIdleTime() + " ms");
/*     */     }
/*     */     
/* 431 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private class IsInUseLock
/*     */   {
/*     */     private IsInUseLock() {}
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ServerSessionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */