/*     */ package com.ibm.mq.connector.xa;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XAObservable
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/xa/XAObservable.java";
/*     */   public static final int STATE_COMMIT = 1;
/*     */   public static final int STATE_END = 2;
/*     */   public static final int STATE_FORGET = 3;
/*     */   public static final int STATE_PREPARE = 4;
/*     */   public static final int STATE_RECOVER = 5;
/*     */   public static final int STATE_ROLLBACK = 6;
/*     */   public static final int STATE_START = 7;
/*     */   public static final int STATE_FAILED = 8;
/*     */   public static final int STATE_MIN = 1;
/*     */   public static final int STATE_MAX = 8;
/*  77 */   private static final String[] STATES = { "UNKNOWN", "COMMIT", "END", "FORGET", "PREPARE", "RECOVER", "ROLLBACK", "START", "FAILED" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private final List observers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addXAObserver(XAObserver o)
/*     */   {
/*  92 */     if (!this.observers.contains(o)) {
/*  93 */       this.observers.add(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeXAObserver(XAObserver o)
/*     */   {
/* 104 */     if (o != null) {
/* 105 */       this.observers.remove(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void update(int xaState)
/*     */   {
/* 116 */     if (JCATraceAdapter.isOn) {
/* 117 */       JCATraceAdapter.traceInfo(this, "XAObservable", "update", "state changed: " + stateToString(xaState));
/*     */     }
/*     */     
/*     */ 
/* 121 */     if ((xaState >= 1) && (xaState <= 8))
/*     */     {
/* 123 */       Iterator i = this.observers.iterator();
/* 124 */       while (i.hasNext()) {
/* 125 */         ((XAObserver)i.next()).xaStateChanged(xaState);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String stateToString(int state)
/*     */   {
/* 138 */     if ((state >= 1) && (state <= 8)) {
/* 139 */       return STATES[state];
/*     */     }
/*     */     
/* 142 */     return STATES[0];
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/xa/XAObservable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */