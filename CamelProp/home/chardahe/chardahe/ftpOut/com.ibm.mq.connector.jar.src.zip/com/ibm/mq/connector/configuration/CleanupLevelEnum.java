/*     */ package com.ibm.mq.connector.configuration;
/*     */ 
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CleanupLevelEnum
/*     */ {
/*  36 */   FORCE("FORCE", "XMSC_WMQ_CLEANUP_LEVEL", 3), 
/*     */   
/*  38 */   NONDUR("NONDUR", "XMSC_WMQ_CLEANUP_LEVEL", 4), 
/*     */   
/*  40 */   NONE("NONE", "XMSC_WMQ_CLEANUP_LEVEL", 0), 
/*     */   
/*  42 */   SAFE("SAFE", "XMSC_WMQ_CLEANUP_LEVEL", 1), 
/*     */   
/*  44 */   STRONG("STRONG", "XMSC_WMQ_CLEANUP_LEVEL", 2);
/*     */   
/*     */ 
/*     */ 
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/configuration/CleanupLevelEnum.java";
/*     */   
/*     */   private String tag;
/*     */   
/*     */   private String property;
/*     */   
/*     */   private int propertyValue;
/*     */   
/*     */   private static HashMap<String, CleanupLevelEnum> lookup;
/*     */   
/*     */ 
/*     */   private CleanupLevelEnum(String tag, String property, int propertyValue)
/*     */   {
/*  63 */     this.tag = tag;
/*  64 */     this.property = property;
/*  65 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*  70 */     lookup = new HashMap();
/*  71 */     for (CleanupLevelEnum e : values()) {
/*  72 */       lookup.put(e.tag, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CleanupLevelEnum byTag(String tag)
/*     */   {
/*  81 */     return (CleanupLevelEnum)lookup.get(tag.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProperty(JmsPropertyContext context)
/*     */     throws JMSException
/*     */   {
/*  89 */     context.setIntProperty(this.property, this.propertyValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTag()
/*     */   {
/*  96 */     return this.tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 104 */     return this.tag;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/configuration/CleanupLevelEnum.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */