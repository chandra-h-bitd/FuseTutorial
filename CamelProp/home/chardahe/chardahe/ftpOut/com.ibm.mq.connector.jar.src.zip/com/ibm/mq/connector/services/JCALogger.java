/*     */ package com.ibm.mq.connector.services;
/*     */ 
/*     */ import com.ibm.msg.client.commonservices.nls.NLSServices;
/*     */ import com.ibm.msg.client.commonservices.provider.log.CSPLog;
/*     */ import com.ibm.msg.client.commonservices.trace.Trace;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCALogger
/*     */   implements CSPLog
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/JCALogger.java";
/*  53 */   private PrintWriter writer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JCALogger(PrintWriter writer)
/*     */   {
/*  61 */     if (Trace.isOn) {
/*  62 */       Trace.entry(this, "com.ibm.mq.connector.services.JCALogger", "<init>(PrintWriter)", new Object[] { writer });
/*     */     }
/*     */     
/*  65 */     this.writer = writer;
/*     */     
/*  67 */     if (Trace.isOn) {
/*  68 */       Trace.exit(this, "com.ibm.mq.connector.services.JCALogger", "<init>(PrintWriter)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/*  78 */     if (Trace.isOn) {
/*  79 */       Trace.entry(this, "com.ibm.mq.connector.services.JCALogger", "close()");
/*     */     }
/*     */     
/*  82 */     this.writer.flush();
/*  83 */     this.writer.close();
/*     */     
/*  85 */     if (Trace.isOn) {
/*  86 */       Trace.exit(this, "com.ibm.mq.connector.services.JCALogger", "close()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(Object parentClass, String parentClassName, String methodSignature, String key, HashMap<String, ?> inserts)
/*     */   {
/* 106 */     if (Trace.isOn) {
/* 107 */       Trace.entry(this, "com.ibm.mq.connector.services.JCALogger", "log(Object, String, String, String, HashMap)", new Object[] { parentClass, parentClassName, methodSignature, key, inserts });
/*     */     }
/*     */     
/*     */ 
/* 111 */     if (this.writer != null) {
/* 112 */       this.writer.println(key + ":" + NLSServices.getMessage(key, inserts));
/* 113 */       this.writer.flush();
/*     */     }
/*     */     
/* 116 */     if (Trace.isOn) {
/* 117 */       Trace.exit(this, "com.ibm.mq.connector.services.JCALogger", "log(Object, String, String, String, HashMap)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void logNLS(Object parentClass, String parentClassName, String methodSignature, String NLSMessage)
/*     */   {
/* 129 */     if (Trace.isOn) {
/* 130 */       Trace.entry(this, "com.ibm.mq.connector.services.JCALogger", "logNLS(Object, String, String, String)", new Object[] { parentClass, parentClassName, methodSignature, NLSMessage });
/*     */     }
/*     */     
/*     */ 
/* 134 */     if (this.writer != null) {
/* 135 */       this.writer.println(NLSMessage);
/* 136 */       this.writer.flush();
/*     */     }
/*     */     
/* 139 */     if (Trace.isOn) {
/* 140 */       Trace.exit(this, "com.ibm.mq.connector.services.JCALogger", "logNLS(Object, String, String, String)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintWriter getWriter()
/*     */   {
/* 150 */     if (this.writer != null) {
/* 151 */       this.writer.flush();
/*     */     }
/* 153 */     return this.writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriter(PrintWriter writer)
/*     */   {
/* 161 */     if (writer != null) {
/* 162 */       writer.flush();
/*     */     }
/* 164 */     this.writer = writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 174 */     StringBuffer retVal = new StringBuffer();
/*     */     
/* 176 */     retVal.append(super.toString());
/* 177 */     retVal.append(": Sending messages to ");
/* 178 */     if (this.writer == null) {
/* 179 */       retVal.append("<Null>");
/*     */     }
/*     */     else {
/* 182 */       retVal.append(this.writer);
/*     */     }
/*     */     
/* 185 */     return retVal.toString();
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/JCALogger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */