/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQDestination;
/*     */ import com.ibm.msg.client.jms.JmsDestination;
/*     */ import com.ibm.msg.client.jms.JmsFactoryFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MQQueueProxy
/*     */   extends MQDestinationProxy
/*     */   implements Queue
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/MQQueueProxy.java";
/*     */   private static final long serialVersionUID = 4815162342L;
/*     */   
/*     */   public MQQueueProxy()
/*     */     throws JMSException
/*     */   {
/*  69 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "<init>");
/*     */     
/*  71 */     JmsFactoryFactory fac = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/*  72 */     this.theDestination = fac.createQueue(null);
/*     */     
/*  74 */     JCATraceAdapter.traceExit(this, "MQQueueProxy", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MQQueueProxy(String qName)
/*     */     throws JMSException
/*     */   {
/*  85 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "<init(String)>");
/*     */     
/*  87 */     JmsFactoryFactory fac = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/*  88 */     this.theDestination = fac.createQueue("queue:///" + qName);
/*     */     
/*  90 */     JCATraceAdapter.traceExit(this, "MQQueueProxy", "<init(String)>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MQQueueProxy(String qMgrName, String qName)
/*     */     throws JMSException
/*     */   {
/* 102 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "<init(String, String)>");
/*     */     
/* 104 */     JmsFactoryFactory fac = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/* 105 */     this.theDestination = fac.createQueue("queue://" + qMgrName + "/" + qName);
/*     */     
/* 107 */     JCATraceAdapter.traceExit(this, "MQQueueProxy", "<init(String, String)>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseQueueManagerName()
/*     */     throws JMSException
/*     */   {
/* 121 */     return this.theDestination.getStringProperty("XMSC_WMQ_QUEUE_MANAGER");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseQueueManagerName(String qMgrName)
/*     */     throws JMSException
/*     */   {
/* 132 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "setBaseQueueManagerName()");
/*     */     try {
/* 134 */       JCATraceAdapter.traceData(this, "MQQueueProxy", "setBaseQueueManagerName()", "queueMgrName: ", qMgrName);
/*     */       
/* 136 */       this.theDestination.setStringProperty("XMSC_WMQ_QUEUE_MANAGER", qMgrName.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 140 */       JCATraceAdapter.traceExit(this, "MQQueueProxy", "setBaseQueueManagerName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseQueueName()
/*     */     throws JMSException
/*     */   {
/* 151 */     return this.theDestination.getStringProperty("XMSC_DESTINATION_NAME");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseQueueName(String qName)
/*     */     throws JMSException
/*     */   {
/* 162 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "setBaseQueueName()");
/*     */     try {
/* 164 */       JCATraceAdapter.traceData(this, "MQQueueProxy", "setBaseQueueName()", "queueName: ", qName);
/* 165 */       this.theDestination.setStringProperty("XMSC_DESTINATION_NAME", qName.trim());
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       JCATraceAdapter.traceExit(this, "MQQueueProxy", "setBaseQueueName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueueName()
/*     */     throws JMSException
/*     */   {
/* 181 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "getQueueName()");
/*     */     try {
/* 183 */       String retVal = "queue://" + this.theDestination.getStringProperty("XMSC_WMQ_QUEUE_MANAGER") + "/" + this.theDestination.getStringProperty("XMSC_DESTINATION_NAME");
/*     */       
/*     */ 
/* 186 */       return retVal;
/*     */     }
/*     */     finally
/*     */     {
/* 190 */       JCATraceAdapter.traceExit(this, "MQQueueProxy", "getQueueName()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Queue getMQQueue()
/*     */   {
/* 203 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "getMQQueue()");
/*     */     try {
/* 205 */       return (Queue)this.theDestination;
/*     */     }
/*     */     finally
/*     */     {
/* 209 */       JCATraceAdapter.traceExit(this, "MQQueueProxy", "getMQQueue()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference getReference()
/*     */     throws NamingException
/*     */   {
/* 222 */     JCATraceAdapter.traceEntry(this, "MQQueueProxy", "getReference()");
/*     */     try {
/* 224 */       if ((this.theDestination instanceof Referenceable)) {
/* 225 */         Reference ref = ((MQDestination)this.theDestination).getReference();
/* 226 */         JCATraceAdapter.traceData(this, "MQQueueProxy", "getReference()", "reference: ", ref.getClassName() + "::" + ref.getFactoryClassName());
/*     */         
/*     */ 
/* 229 */         return ref;
/*     */       }
/*     */       
/* 232 */       throw new NamingException("getReference() called but destination is not referenceable");
/*     */     }
/*     */     finally
/*     */     {
/* 236 */       JCATraceAdapter.traceExit(this, "MQQueueProxy", "getReference()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/MQQueueProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */