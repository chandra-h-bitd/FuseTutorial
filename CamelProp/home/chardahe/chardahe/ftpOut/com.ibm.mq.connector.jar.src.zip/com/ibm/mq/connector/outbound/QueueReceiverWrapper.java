/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueueReceiverWrapper
/*     */   extends MessageConsumerWrapper
/*     */   implements QueueReceiver
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/QueueReceiverWrapper.java";
/*     */   
/*     */   public QueueReceiverWrapper(SessionWrapper sw, Session s, boolean isManaged, Queue q)
/*     */     throws JMSException
/*     */   {
/*  60 */     this(sw, s, isManaged, q, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueueReceiverWrapper(SessionWrapper sw, Session s, boolean isManaged, Queue q, String sel)
/*     */     throws JMSException
/*     */   {
/*  76 */     JCATraceAdapter.traceEntry(this, "QueueReceiverWrapper", "<init>");
/*     */     
/*  78 */     this.isManaged = isManaged;
/*     */     
/*  80 */     if ((q instanceof MQQueueProxy))
/*     */     {
/*  82 */       this.theDestination = ((MQQueueProxy)q).getMQQueue();
/*  83 */       JCATraceAdapter.traceInfo(this, "QueueReceiverWrapper", "<init>", "extracted Queue: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  88 */       this.theDestination = q;
/*  89 */       JCATraceAdapter.traceInfo(this, "QueueReceiverWrapper", "<init>", "using Queue: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/*  93 */     this.theSessionWrapper = sw;
/*     */     
/*  95 */     JCATraceAdapter.traceInfo(this, "QueueReceiverWrapper", "<init>", "selector: " + sel);
/*     */     try
/*     */     {
/*  98 */       this.theConsumer = s.createConsumer(this.theDestination, sel);
/*     */     }
/*     */     finally
/*     */     {
/* 102 */       JCATraceAdapter.traceExit(this, "QueueReceiverWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Queue getQueue()
/*     */     throws JMSException
/*     */   {
/* 110 */     assertOpen();
/*     */     
/* 112 */     return (Queue)this.theDestination;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/QueueReceiverWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */