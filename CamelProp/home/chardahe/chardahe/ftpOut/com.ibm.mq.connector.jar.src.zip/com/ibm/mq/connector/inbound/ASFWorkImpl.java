/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.jms.JmsSession;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASFWorkImpl
/*     */   extends AbstractWorkImpl
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/ASFWorkImpl.java";
/*     */   
/*     */   protected ASFWorkImpl(MessageEndpointDeployment d, Session s)
/*     */   {
/*  73 */     if (JCATraceAdapter.isOn) {
/*  74 */       JCATraceAdapter.traceEntry(this, "ASFWorkImpl", "<init>", new Object[] { d, s });
/*     */     }
/*  76 */     this.theSession = s;
/*  77 */     this.theDeployment = d;
/*  78 */     if (JCATraceAdapter.isOn) {
/*  79 */       JCATraceAdapter.traceExit(this, "ASFWorkImpl", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doDelivery(MessageEndpoint endpoint)
/*     */     throws JMSException
/*     */   {
/*  88 */     if (JCATraceAdapter.isOn) {
/*  89 */       JCATraceAdapter.traceEntry(this, "ASFWorkImpl", "doDelivery()", new Object[] { endpoint });
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  94 */       MessageEndpointWrapper w = (MessageEndpointWrapper)this.theSession.getMessageListener();
/*  95 */       w.setEndpoint(endpoint);
/*     */       
/*     */ 
/*     */ 
/*  99 */       if (JCATraceAdapter.isOn) {
/* 100 */         JCATraceAdapter.traceInfo(this, "ASFWorkImpl", "doDelivery()", "ASFWorkImpl running " + this.theSession.getMessageListener());
/*     */       }
/* 102 */       this.theSession.run();
/*     */     }
/*     */     finally {
/* 105 */       if (JCATraceAdapter.isOn) {
/* 106 */         JCATraceAdapter.traceExit(this, "ASFWorkImpl", "doDelivery() ");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanupDelivery()
/*     */   {
/* 118 */     if (JCATraceAdapter.isOn) {
/* 119 */       JCATraceAdapter.traceEntry(this, "ASFWorkImpl", "cleanupDelivery() ");
/*     */     }
/*     */     
/* 122 */     if ((this.theSession instanceof JmsSession))
/*     */     {
/* 124 */       ((JmsSession)this.theSession).clearMessageReferences();
/*     */     }
/*     */     
/* 127 */     if (JCATraceAdapter.isOn) {
/* 128 */       JCATraceAdapter.traceExit(this, "ASFWorkImpl", "cleanupDelivery() ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getSession()
/*     */   {
/* 139 */     if (JCATraceAdapter.isOn) {
/* 140 */       JCATraceAdapter.traceData(this, "ASFWorkImpl", "getSession", "got value", this.theSession);
/*     */     }
/* 142 */     return this.theSession;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 147 */     int identityHashCode = System.identityHashCode(this);
/* 148 */     return "ASFWorkImpl[" + identityHashCode + " - " + Integer.toHexString(identityHashCode) + "]";
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/ASFWorkImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */