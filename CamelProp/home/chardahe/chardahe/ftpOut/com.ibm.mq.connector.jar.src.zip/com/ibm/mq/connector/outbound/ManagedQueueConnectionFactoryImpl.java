/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.ConnectionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.JMSException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.InvalidPropertyException;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedQueueConnectionFactoryImpl
/*     */   extends ManagedConnectionFactoryImpl
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedQueueConnectionFactoryImpl.java";
/*     */   private static final long serialVersionUID = 2305843009213693951L;
/*     */   
/*     */   public ManagedQueueConnectionFactoryImpl()
/*     */     throws InvalidPropertyException
/*     */   {
/*  73 */     JCATraceAdapter.traceEntry(this, "ManagedQueueConnectionFactoryImpl", "<init>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     JCATraceAdapter.traceExit(this, "ManagedQueueConnectionFactoryImpl", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object createConnectionFactory(ConnectionManager cm)
/*     */   {
/*  91 */     JCATraceAdapter.traceEntry(this, "ManagedQueueConnectionFactoryImpl", "createConnectionFactory(...)");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  96 */       return new QueueConnectionFactoryImpl(this, cm);
/*     */     }
/*     */     finally
/*     */     {
/* 100 */       JCATraceAdapter.traceExit(this, "ManagedQueueConnectionFactoryImpl", "createConnectionFactory(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object createConnectionFactory()
/*     */   {
/* 113 */     JCATraceAdapter.traceEntry(this, "ManagedQueueConnectionFactoryImpl", "createConnectionFactory()");
/*     */     
/*     */     try
/*     */     {
/* 117 */       return new QueueConnectionFactoryImpl(this);
/*     */     }
/*     */     finally
/*     */     {
/* 121 */       JCATraceAdapter.traceExit(this, "ManagedQueueConnectionFactoryImpl", "createConnectionFactory()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnection createManagedConnection(Subject arg0, ConnectionRequestInfo arg1)
/*     */     throws ResourceException
/*     */   {
/* 139 */     JCATraceAdapter.traceEntry(this, "ManagedQueueConnectionFactoryImpl", "createManagedConnection(...)");
/*     */     
/*     */     try
/*     */     {
/* 143 */       ManagedConnection mc = new ManagedQueueConnectionImpl(arg0, arg1, this);
/*     */       
/* 145 */       mc.setLogWriter(this.thePrintWriter);
/*     */       
/* 147 */       return mc;
/*     */     }
/*     */     finally
/*     */     {
/* 151 */       JCATraceAdapter.traceExit(this, "ManagedQueueConnectionFactoryImpl", "createManagedConnection(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Connection createConnection(ManagedConnectionImpl mc, Subject subj, ConnectionRequestInfo cri)
/*     */     throws ResourceException
/*     */   {
/* 160 */     if (this.theCF == null) {
/*     */       try {
/* 162 */         this.theCF = createConnectionFactory(2);
/*     */       }
/*     */       catch (JMSException je)
/*     */       {
/* 166 */         throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1012", je));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 172 */     return ConnectionBuilder.createConnection(this.theCF, this, mc, subj, cri);
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedQueueConnectionFactoryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */