/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.SimpleBeanInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConfigurationBeanInfo
/*     */   extends SimpleBeanInfo
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/AbstractConfigurationBeanInfo.java";
/* 102 */   static Class beanClass = AbstractConfiguration.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/* 113 */     JCATraceAdapter.traceEntry(this, "AbstractConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     
/*     */     try
/*     */     {
/* 117 */       PropertyDescriptor applicationName = new PropertyDescriptor("applicationName", beanClass);
/* 118 */       applicationName.setExpert(false);
/*     */       
/* 120 */       brokerCCSubQueue = new PropertyDescriptor("brokerCCSubQueue", beanClass);
/* 121 */       brokerCCSubQueue.setExpert(true);
/*     */       
/* 123 */       PropertyDescriptor brokerControlQueue = new PropertyDescriptor("brokerControlQueue", beanClass);
/*     */       
/* 125 */       brokerControlQueue.setExpert(true);
/*     */       
/* 127 */       PropertyDescriptor brokerPubQueue = new PropertyDescriptor("brokerPubQueue", beanClass);
/* 128 */       brokerPubQueue.setExpert(true);
/*     */       
/* 130 */       PropertyDescriptor brokerSubQueue = new PropertyDescriptor("brokerSubQueue", beanClass);
/* 131 */       brokerSubQueue.setExpert(true);
/*     */       
/* 133 */       PropertyDescriptor brokerQueueManager = new PropertyDescriptor("brokerQueueManager", beanClass);
/*     */       
/* 135 */       brokerQueueManager.setExpert(true);
/*     */       
/* 137 */       PropertyDescriptor brokerVersion = new PropertyDescriptor("brokerVersion", beanClass);
/* 138 */       brokerVersion.setExpert(true);
/*     */       
/* 140 */       PropertyDescriptor ccdtURL = new PropertyDescriptor("ccdtURL", beanClass);
/* 141 */       ccdtURL.setExpert(true);
/*     */       
/* 143 */       PropertyDescriptor ccsid = new PropertyDescriptor("CCSID", beanClass);
/* 144 */       ccsid.setExpert(true);
/*     */       
/* 146 */       PropertyDescriptor receiveCCSID = new PropertyDescriptor("receiveCCSID", beanClass);
/* 147 */       receiveCCSID.setExpert(true);
/*     */       
/* 149 */       PropertyDescriptor receiveConversion = new PropertyDescriptor("receiveConversion", beanClass);
/* 150 */       receiveConversion.setExpert(true);
/*     */       
/* 152 */       PropertyDescriptor channel = new PropertyDescriptor("channel", beanClass);
/* 153 */       channel.setPreferred(true);
/*     */       
/* 155 */       PropertyDescriptor cleanupInterval = new PropertyDescriptor("cleanupInterval", beanClass);
/* 156 */       cleanupInterval.setExpert(true);
/*     */       
/* 158 */       PropertyDescriptor cleanupLevel = new PropertyDescriptor("cleanupLevel", beanClass);
/* 159 */       cleanupLevel.setExpert(true);
/*     */       
/* 161 */       PropertyDescriptor clientID = new PropertyDescriptor("clientID", beanClass);
/* 162 */       clientID.setPreferred(false);
/*     */       
/* 164 */       PropertyDescriptor clientId = new PropertyDescriptor("clientId", beanClass);
/* 165 */       clientId.setPreferred(true);
/*     */       
/* 167 */       PropertyDescriptor cloneSupport = new PropertyDescriptor("cloneSupport", beanClass);
/* 168 */       cloneSupport.setExpert(true);
/*     */       
/* 170 */       PropertyDescriptor connectionNameList = new PropertyDescriptor("connectionNameList", beanClass);
/* 171 */       connectionNameList.setExpert(true);
/*     */       
/* 173 */       PropertyDescriptor failIfQuiesce = new PropertyDescriptor("failIfQuiesce", beanClass);
/* 174 */       failIfQuiesce.setExpert(true);
/*     */       
/* 176 */       PropertyDescriptor headerCompression = new PropertyDescriptor("headerCompression", beanClass);
/* 177 */       headerCompression.setExpert(true);
/*     */       
/* 179 */       PropertyDescriptor hostName = new PropertyDescriptor("hostName", beanClass);
/* 180 */       hostName.setPreferred(true);
/*     */       
/* 182 */       PropertyDescriptor localAddress = new PropertyDescriptor("localAddress", beanClass);
/* 183 */       localAddress.setExpert(true);
/*     */       
/* 185 */       PropertyDescriptor messageCompression = new PropertyDescriptor("messageCompression", beanClass);
/*     */       
/* 187 */       messageCompression.setExpert(true);
/*     */       
/* 189 */       PropertyDescriptor messageSelection = new PropertyDescriptor("messageSelection", beanClass);
/* 190 */       messageSelection.setExpert(true);
/*     */       
/* 192 */       PropertyDescriptor pollingInterval = new PropertyDescriptor("pollingInterval", beanClass);
/* 193 */       pollingInterval.setExpert(true);
/*     */       
/* 195 */       PropertyDescriptor port = new PropertyDescriptor("port", beanClass);
/* 196 */       port.setPreferred(true);
/*     */       
/* 198 */       PropertyDescriptor password = new PropertyDescriptor("password", beanClass);
/* 199 */       password.setPreferred(true);
/*     */       
/* 201 */       PropertyDescriptor queueManager = new PropertyDescriptor("queueManager", beanClass);
/*     */       
/* 203 */       PropertyDescriptor receiveExit = new PropertyDescriptor("receiveExit", beanClass);
/* 204 */       receiveExit.setExpert(true);
/*     */       
/* 206 */       PropertyDescriptor receiveExitInit = new PropertyDescriptor("receiveExitInit", beanClass);
/* 207 */       receiveExitInit.setExpert(true);
/*     */       
/* 209 */       PropertyDescriptor rescanInterval = new PropertyDescriptor("rescanInterval", beanClass);
/* 210 */       rescanInterval.setExpert(true);
/*     */       
/* 212 */       PropertyDescriptor securityExit = new PropertyDescriptor("securityExit", beanClass);
/* 213 */       securityExit.setExpert(true);
/*     */       
/* 215 */       PropertyDescriptor securityExitInit = new PropertyDescriptor("securityExitInit", beanClass);
/* 216 */       securityExitInit.setExpert(true);
/*     */       
/* 218 */       PropertyDescriptor sendExit = new PropertyDescriptor("sendExit", beanClass);
/* 219 */       sendExit.setExpert(true);
/*     */       
/* 221 */       PropertyDescriptor sendExitInit = new PropertyDescriptor("sendExitInit", beanClass);
/* 222 */       sendExitInit.setExpert(true);
/*     */       
/* 224 */       PropertyDescriptor sparseSubscriptions = new PropertyDescriptor("sparseSubscriptions", beanClass);
/*     */       
/* 226 */       sparseSubscriptions.setExpert(true);
/*     */       
/* 228 */       PropertyDescriptor sslCertStores = new PropertyDescriptor("sslCertStores", beanClass);
/* 229 */       sslCertStores.setExpert(true);
/*     */       
/* 231 */       PropertyDescriptor sslCipherSuite = new PropertyDescriptor("sslCipherSuite", beanClass);
/* 232 */       sslCipherSuite.setExpert(true);
/*     */       
/* 234 */       PropertyDescriptor sslFipsRequired = new PropertyDescriptor("sslFipsRequired", beanClass);
/* 235 */       sslFipsRequired.setExpert(true);
/*     */       
/* 237 */       PropertyDescriptor sslPeerName = new PropertyDescriptor("sslPeerName", beanClass);
/* 238 */       sslPeerName.setExpert(true);
/*     */       
/* 240 */       PropertyDescriptor sslResetCount = new PropertyDescriptor("sslResetCount", beanClass);
/* 241 */       sslResetCount.setExpert(true);
/*     */       
/* 243 */       PropertyDescriptor subscriptionStore = new PropertyDescriptor("subscriptionStore", beanClass);
/* 244 */       subscriptionStore.setExpert(true);
/*     */       
/* 246 */       PropertyDescriptor statusRefreshInterval = new PropertyDescriptor("statusRefreshInterval", beanClass);
/*     */       
/* 248 */       statusRefreshInterval.setExpert(true);
/*     */       
/* 250 */       PropertyDescriptor transportType = new PropertyDescriptor("transportType", beanClass);
/* 251 */       transportType.setPreferred(true);
/*     */       
/* 253 */       PropertyDescriptor username = new PropertyDescriptor("userName", beanClass);
/* 254 */       username.setPreferred(true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 259 */       PropertyDescriptor arbitraryProperties = new PropertyDescriptor("arbitraryProperties", beanClass);
/*     */       
/* 261 */       arbitraryProperties.setExpert(true);
/*     */       
/* 263 */       PropertyDescriptor providerVersion = new PropertyDescriptor("providerVersion", beanClass);
/* 264 */       providerVersion.setPreferred(true);
/*     */       
/* 266 */       PropertyDescriptor readAheadAllowed = new PropertyDescriptor("readAheadAllowed", beanClass);
/* 267 */       readAheadAllowed.setExpert(true);
/*     */       
/* 269 */       PropertyDescriptor shareConvAllowed = new PropertyDescriptor("shareConvAllowed", beanClass);
/* 270 */       shareConvAllowed.setExpert(true);
/*     */       
/* 272 */       PropertyDescriptor sslSocketFactory = new PropertyDescriptor("sslSocketFactory", beanClass);
/* 273 */       sslSocketFactory.setExpert(true);
/*     */       
/* 275 */       PropertyDescriptor wildcardFormat = new PropertyDescriptor("wildcardFormat", beanClass);
/* 276 */       wildcardFormat.setExpert(true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 281 */       PropertyDescriptor[] rv = { applicationName, queueManager, hostName, channel, port, ccsid, brokerCCSubQueue, brokerControlQueue, brokerPubQueue, brokerSubQueue, brokerQueueManager, brokerVersion, ccdtURL, cleanupInterval, cleanupLevel, clientID, clientId, cloneSupport, connectionNameList, failIfQuiesce, headerCompression, localAddress, messageSelection, messageCompression, password, pollingInterval, receiveExit, receiveExitInit, rescanInterval, securityExit, securityExitInit, sendExit, sendExitInit, sparseSubscriptions, statusRefreshInterval, sslCertStores, sslCipherSuite, sslFipsRequired, sslPeerName, sslResetCount, subscriptionStore, transportType, username, arbitraryProperties, providerVersion, readAheadAllowed, shareConvAllowed, sslSocketFactory, wildcardFormat, receiveCCSID, receiveConversion };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 290 */       return rv;
/*     */     }
/*     */     catch (IntrospectionException e) {
/*     */       PropertyDescriptor brokerCCSubQueue;
/* 294 */       JCATraceAdapter.traceException(this, "AbstractConfigurationBeanInfo", "getPropertyDescriptors()", e);
/*     */       
/* 296 */       return null;
/*     */     }
/*     */     finally
/*     */     {
/* 300 */       JCATraceAdapter.traceExit(this, "AbstractConfigurationBeanInfo", "getPropertyDescriptors()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/AbstractConfigurationBeanInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */