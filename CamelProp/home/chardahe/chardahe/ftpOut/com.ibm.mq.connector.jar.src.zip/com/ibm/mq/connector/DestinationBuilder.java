/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.configuration.ReadAheadAllowedEnum;
/*     */ import com.ibm.mq.connector.inbound.ActivationSpecImpl;
/*     */ import com.ibm.mq.connector.outbound.MQDestinationProxy;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQDestination;
/*     */ import com.ibm.mq.jms.MQQueue;
/*     */ import com.ibm.mq.jms.MQTopic;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.resource.ResourceException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DestinationBuilder
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/DestinationBuilder.java";
/*     */   private static InitialContext ctx;
/*     */   
/*     */   public static Destination createDestination(ActivationSpecImpl theSpec)
/*     */     throws ResourceException
/*     */   {
/*  86 */     JCATraceAdapter.traceEntry(null, "DestinationBuilder", "createDestination()");
/*     */     
/*  88 */     Destination theDestination = null;
/*     */     try
/*     */     {
/*     */       Destination aDestination;
/*  92 */       if (!theSpec.getUseJNDI())
/*     */       {
/*     */ 
/*  95 */         if (theSpec.getDestinationType().equalsIgnoreCase("javax.jms.Queue")) {
/*  96 */           theDestination = new MQQueue(theSpec.getDestination());
/*     */         }
/*     */         else {
/*  99 */           theDestination = new MQTopic(theSpec.getDestination());
/*     */           
/*     */ 
/* 102 */           ((MQTopic)theDestination).setBrokerCCDurSubQueue(theSpec.getBrokerCCDurSubQueue());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 107 */         ((MQDestination)theDestination).setReceiveCCSID(theSpec.getReceiveCCSID());
/* 108 */         ((MQDestination)theDestination).setStringProperty("RCNV", theSpec.getReceiveConversion());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 113 */         ((MQDestination)theDestination).setStringProperty("RACP", "DELIVER_" + theSpec.getReadAheadClosePolicy());
/*     */         
/*     */ 
/* 116 */         if (ReadAheadAllowedEnum.AS_DEST.getTag().equals(theSpec.getReadAheadAllowed())) {
/* 117 */           ((MQDestination)theDestination).setIntProperty("readAheadAllowed", -1);
/*     */ 
/*     */         }
/* 120 */         else if (theSpec.getReadAheadAllowed().equalsIgnoreCase(ReadAheadAllowedEnum.AS_QDEF.getTag()))
/*     */         {
/* 122 */           ((MQDestination)theDestination).setIntProperty("readAheadAllowed", -1);
/*     */ 
/*     */         }
/* 125 */         else if (theSpec.getReadAheadAllowed().equalsIgnoreCase(ReadAheadAllowedEnum.AS_TOPIC.getTag()))
/*     */         {
/* 127 */           ((MQDestination)theDestination).setIntProperty("readAheadAllowed", -1);
/*     */ 
/*     */         }
/* 130 */         else if (theSpec.getReadAheadAllowed().equalsIgnoreCase(ReadAheadAllowedEnum.ENABLED.getTag()))
/*     */         {
/* 132 */           ((MQDestination)theDestination).setIntProperty("readAheadAllowed", 1);
/*     */ 
/*     */         }
/* 135 */         else if (theSpec.getReadAheadAllowed().equalsIgnoreCase(ReadAheadAllowedEnum.DISABLED.getTag()))
/*     */         {
/* 137 */           ((MQDestination)theDestination).setIntProperty("readAheadAllowed", 0);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */         JCATraceAdapter.traceInfo(DestinationBuilder.class, "DestinationBuilder", "createDestination()", "created Destination: " + theDestination);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 149 */         if (ctx == null) {
/* 150 */           ctx = new InitialContext();
/* 151 */           JCATraceAdapter.traceInfo(DestinationBuilder.class, "DestinationBuilder", "createDestination()", "instantiated context: " + ctx);
/*     */         }
/*     */         
/* 154 */         JCATraceAdapter.traceInfo(DestinationBuilder.class, "DestinationBuilder", "createDestination()", "looking up: " + theSpec.getDestination());
/*     */         
/*     */ 
/* 157 */         aDestination = (Destination)ctx.lookup(theSpec.getDestination());
/* 158 */         JCATraceAdapter.traceInfo(DestinationBuilder.class, "DestinationBuilder", "createDestination()", "found: " + aDestination);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 163 */         if ((aDestination instanceof MQDestinationProxy)) {
/* 164 */           theDestination = ((MQDestinationProxy)aDestination).getMQDestination();
/*     */         }
/*     */         else {
/* 167 */           theDestination = aDestination;
/*     */         }
/* 169 */         JCATraceAdapter.traceInfo(DestinationBuilder.class, "DestinationBuilder", "createDestination()", "returning: " + theDestination);
/*     */       }
/*     */       
/* 172 */       return theDestination;
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 176 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*     */ 
/*     */     }
/*     */     catch (NamingException ne)
/*     */     {
/* 181 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0003", ne));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 186 */       JCATraceAdapter.traceExit(null, "DestinationBuilder", "createDestination()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/DestinationBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */