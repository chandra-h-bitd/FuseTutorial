/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.jms.BytesMessage;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.IllegalStateException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.MapMessage;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageConsumer;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.MessageProducer;
/*     */ import javax.jms.ObjectMessage;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueBrowser;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.StreamMessage;
/*     */ import javax.jms.TemporaryQueue;
/*     */ import javax.jms.TemporaryTopic;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionWrapper
/*     */   implements Session
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/SessionWrapper.java";
/*  82 */   protected Session theSession = null;
/*     */   
/*     */ 
/*  85 */   protected ConnectionWrapper theConnWrapper = null;
/*     */   
/*     */ 
/*  88 */   protected boolean isOpen = false;
/*     */   
/*     */ 
/*  91 */   protected ArrayList producers = null;
/*     */   
/*  93 */   protected ArrayList consumers = null;
/*     */   
/*  95 */   protected ArrayList browsers = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SessionWrapper(ConnectionWrapper w, Session s)
/*     */     throws JMSException
/*     */   {
/* 110 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "<init>");
/*     */     try
/*     */     {
/* 113 */       if ((w != null) && (s != null)) {
/* 114 */         this.theSession = s;
/* 115 */         this.theConnWrapper = w;
/*     */       }
/*     */       else
/*     */       {
/* 119 */         throw new JMSException("invalid parameters passed to SessionWrapper");
/*     */       }
/*     */       
/* 122 */       this.isOpen = true;
/*     */     }
/*     */     finally
/*     */     {
/* 126 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BytesMessage createBytesMessage()
/*     */     throws JMSException
/*     */   {
/* 135 */     assertOpen();
/* 136 */     return this.theSession.createBytesMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MapMessage createMapMessage()
/*     */     throws JMSException
/*     */   {
/* 144 */     assertOpen();
/* 145 */     return this.theSession.createMapMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Message createMessage()
/*     */     throws JMSException
/*     */   {
/* 153 */     assertOpen();
/* 154 */     return this.theSession.createMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ObjectMessage createObjectMessage()
/*     */     throws JMSException
/*     */   {
/* 162 */     assertOpen();
/* 163 */     return this.theSession.createObjectMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ObjectMessage createObjectMessage(Serializable arg0)
/*     */     throws JMSException
/*     */   {
/* 171 */     assertOpen();
/* 172 */     return this.theSession.createObjectMessage(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StreamMessage createStreamMessage()
/*     */     throws JMSException
/*     */   {
/* 180 */     assertOpen();
/* 181 */     return this.theSession.createStreamMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TextMessage createTextMessage()
/*     */     throws JMSException
/*     */   {
/* 189 */     assertOpen();
/* 190 */     return this.theSession.createTextMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TextMessage createTextMessage(String arg0)
/*     */     throws JMSException
/*     */   {
/* 198 */     assertOpen();
/* 199 */     return this.theSession.createTextMessage(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getTransacted()
/*     */     throws JMSException
/*     */   {
/* 207 */     assertOpen();
/* 208 */     return this.theSession.getTransacted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getAcknowledgeMode()
/*     */     throws JMSException
/*     */   {
/* 216 */     assertOpen();
/* 217 */     return this.theSession.getAcknowledgeMode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void commit()
/*     */     throws JMSException
/*     */   {
/* 225 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "commit()");
/*     */     try
/*     */     {
/* 228 */       assertOpen();
/* 229 */       this.theSession.commit();
/*     */     }
/*     */     finally
/*     */     {
/* 233 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "commit()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rollback()
/*     */     throws JMSException
/*     */   {
/* 242 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "rollback()");
/*     */     try
/*     */     {
/* 245 */       assertOpen();
/* 246 */       this.theSession.rollback();
/*     */     }
/*     */     finally
/*     */     {
/* 250 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "rollback()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws JMSException
/*     */   {
/* 260 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "close()");
/*     */     
/*     */     try
/*     */     {
/* 264 */       this.isOpen = false;
/*     */       
/*     */ 
/* 267 */       synchronized (this.theConnWrapper) {
/* 268 */         this.theConnWrapper.releaseSession(this);
/*     */         
/* 270 */         if (this.consumers != null)
/*     */         {
/* 272 */           JCATraceAdapter.traceInfo(this, "SessionWrapper", "close()", "closing " + this.consumers.size() + " MessageConsumerWrapper objects");
/*     */           
/*     */ 
/* 275 */           ArrayList consumersClone = (ArrayList)this.consumers.clone();
/* 276 */           Iterator i = consumersClone.iterator();
/* 277 */           while (i.hasNext()) {
/* 278 */             MessageConsumerWrapper mcw = (MessageConsumerWrapper)i.next();
/* 279 */             mcw.close();
/*     */           }
/*     */           
/* 282 */           this.consumers.clear();
/*     */         }
/*     */         
/* 285 */         if (this.producers != null)
/*     */         {
/* 287 */           JCATraceAdapter.traceInfo(this, "SessionWrapper", "close()", "closing " + this.producers.size() + " MessageProducerWrapper objects");
/*     */           
/*     */ 
/* 290 */           ArrayList producersClone = (ArrayList)this.producers.clone();
/* 291 */           Iterator i = producersClone.iterator();
/* 292 */           while (i.hasNext()) {
/* 293 */             MessageProducerWrapper mpw = (MessageProducerWrapper)i.next();
/* 294 */             mpw.close();
/*     */           }
/*     */           
/* 297 */           this.producers.clear();
/*     */         }
/*     */         
/* 300 */         if (this.browsers != null)
/*     */         {
/* 302 */           JCATraceAdapter.traceInfo(this, "SessionWrapper", "close()", "closing " + this.browsers.size() + " QueueBrowserWrapper objects");
/*     */           
/*     */ 
/* 305 */           ArrayList browsersClone = (ArrayList)this.browsers.clone();
/* 306 */           Iterator i = browsersClone.iterator();
/* 307 */           while (i.hasNext()) {
/* 308 */             QueueBrowserWrapper qbw = (QueueBrowserWrapper)i.next();
/* 309 */             qbw.close();
/*     */           }
/*     */           
/* 312 */           this.browsers.clear();
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 318 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "close()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void recover()
/*     */     throws JMSException
/*     */   {
/* 327 */     assertOpen();
/* 328 */     this.theSession.recover();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageListener getMessageListener()
/*     */     throws JMSException
/*     */   {
/* 337 */     throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1024"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageListener(MessageListener arg0)
/*     */     throws JMSException
/*     */   {
/* 346 */     throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1024"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 356 */     JCAMessageBuilder.buildWarning("MQJCA4012");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MessageProducer createProducer(Destination arg0)
/*     */     throws JMSException
/*     */   {
/* 364 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createProducer(...)");
/*     */     try
/*     */     {
/* 367 */       assertOpen();
/*     */       
/* 369 */       synchronized (this.theConnWrapper) {
/* 370 */         if (this.producers == null) {
/* 371 */           this.producers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 375 */       MessageProducerWrapper p = new MessageProducerWrapper(this, this.theSession, arg0);
/*     */       
/* 377 */       this.producers.add(p);
/*     */       
/* 379 */       return p;
/*     */     }
/*     */     finally
/*     */     {
/* 383 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createProducer(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MessageConsumer createConsumer(Destination arg0)
/*     */     throws JMSException
/*     */   {
/* 392 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createConsumer(...)");
/*     */     try {
/* 394 */       return createConsumer(arg0, null, false);
/*     */     }
/*     */     finally
/*     */     {
/* 398 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createConsumer(...)()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MessageConsumer createConsumer(Destination arg0, String arg1)
/*     */     throws JMSException
/*     */   {
/* 407 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createConsumer(...)");
/*     */     try {
/* 409 */       return createConsumer(arg0, arg1, false);
/*     */     }
/*     */     finally
/*     */     {
/* 413 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createConsumer(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageConsumer createConsumer(Destination arg0, String arg1, boolean arg2)
/*     */     throws JMSException
/*     */   {
/* 423 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createConsumer(...)");
/*     */     try
/*     */     {
/* 426 */       assertOpen();
/*     */       
/* 428 */       synchronized (this.theConnWrapper) {
/* 429 */         if (this.consumers == null) {
/* 430 */           this.consumers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 434 */       MessageConsumerWrapper c = new MessageConsumerWrapper(this, this.theSession, this.theConnWrapper.isManaged(), arg0, arg1, arg2);
/*     */       
/*     */ 
/* 437 */       this.consumers.add(c);
/*     */       
/* 439 */       return c;
/*     */     }
/*     */     finally
/*     */     {
/* 443 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createConsumer(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Queue createQueue(String arg0)
/*     */     throws JMSException
/*     */   {
/* 452 */     assertOpen();
/* 453 */     return this.theSession.createQueue(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Topic createTopic(String arg0)
/*     */     throws JMSException
/*     */   {
/* 461 */     assertOpen();
/* 462 */     return this.theSession.createTopic(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */   public TopicSubscriber createDurableSubscriber(Topic arg0, String arg1)
/*     */     throws JMSException
/*     */   {
/* 469 */     return createDurableSubscriber(arg0, arg1, "", false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TopicSubscriber createDurableSubscriber(Topic arg0, String arg1, String arg2, boolean arg3)
/*     */     throws JMSException
/*     */   {
/* 479 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createDurableSubscriber(...)");
/*     */     try
/*     */     {
/* 482 */       assertOpen();
/*     */       
/* 484 */       synchronized (this.theConnWrapper) {
/* 485 */         if (this.consumers == null) {
/* 486 */           this.consumers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 490 */       TopicSubscriberWrapper ds = new TopicSubscriberWrapper(this, this.theSession, this.theConnWrapper.isManaged(), arg0, arg1, arg2, arg3);
/*     */       
/*     */ 
/* 493 */       this.consumers.add(ds);
/*     */       
/* 495 */       return ds;
/*     */     }
/*     */     finally {
/* 498 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createDurableSubscriber(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueueBrowser createBrowser(Queue arg0)
/*     */     throws JMSException
/*     */   {
/* 508 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createBrowser(...)");
/*     */     try {
/* 510 */       return createBrowser(arg0, null);
/*     */     }
/*     */     finally
/*     */     {
/* 514 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createBrowser(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QueueBrowser createBrowser(Queue arg0, String arg1)
/*     */     throws JMSException
/*     */   {
/* 523 */     JCATraceAdapter.traceEntry(this, "SessionWrapper", "createBrowser(...)");
/*     */     try
/*     */     {
/* 526 */       assertOpen();
/*     */       
/* 528 */       synchronized (this.theConnWrapper) {
/* 529 */         if (this.browsers == null) {
/* 530 */           this.browsers = new ArrayList();
/*     */         }
/*     */       }
/*     */       
/* 534 */       QueueBrowserWrapper qbw = new QueueBrowserWrapper(this, this.theSession, arg0, arg1);
/*     */       
/* 536 */       this.browsers.add(qbw);
/*     */       
/* 538 */       return qbw;
/*     */     }
/*     */     finally
/*     */     {
/* 542 */       JCATraceAdapter.traceExit(this, "SessionWrapper", "createBrowser(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TemporaryQueue createTemporaryQueue()
/*     */     throws JMSException
/*     */   {
/* 551 */     assertOpen();
/*     */     
/*     */ 
/* 554 */     TemporaryQueue tq = this.theSession.createTemporaryQueue();
/*     */     try {
/* 556 */       JCATraceAdapter.traceInfo(this, "SessionWrapper", "createTemporaryQueue()", "Created a temporary queue " + tq.getQueueName());
/*     */     }
/*     */     catch (JMSException e)
/*     */     {
/* 560 */       JCATraceAdapter.traceException(this, "SessionWrapper", "createTemporaryQueue()", e);
/*     */     }
/* 562 */     this.theConnWrapper.theManagedConnection.addTempQueue(tq);
/*     */     
/* 564 */     return tq;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TemporaryTopic createTemporaryTopic()
/*     */     throws JMSException
/*     */   {
/* 572 */     assertOpen();
/*     */     
/* 574 */     TemporaryTopic tt = this.theSession.createTemporaryTopic();
/*     */     try {
/* 576 */       JCATraceAdapter.traceInfo(this, "SessionWrapper", "createTemporaryTopic()", "Created a temporary topic " + tt.getTopicName());
/*     */     } catch (JMSException e) {
/* 578 */       JCATraceAdapter.traceException(this, "SessionWrapper", "createTemporaryTopic()", e);
/*     */     }
/* 580 */     this.theConnWrapper.theManagedConnection.addTempTopic(tt);
/*     */     
/* 582 */     return tt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void unsubscribe(String arg0)
/*     */     throws JMSException
/*     */   {
/* 590 */     assertOpen();
/* 591 */     this.theSession.unsubscribe(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 600 */     if (!this.isOpen)
/*     */     {
/* 602 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1020"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void reassociate(Session s)
/*     */   {
/* 615 */     JCATraceAdapter.traceEntry(this, "SessionWrapper()", "reassociate()");
/*     */     
/*     */     try
/*     */     {
/* 619 */       if (getTransacted()) {
/* 620 */         rollback();
/*     */       }
/*     */       
/* 623 */       this.theSession = s;
/*     */     }
/*     */     catch (JMSException je) {
/* 626 */       JCATraceAdapter.traceNonNLSWarning(this, "SessionWrapper()", "reassociate()", "preemptive backout failed", null);
/*     */       
/* 628 */       JCATraceAdapter.traceException(this, "SessionWrapper()", "reassociate()", je);
/*     */     }
/*     */     finally
/*     */     {
/* 632 */       JCATraceAdapter.traceExit(this, "SessionWrapper()", "reassociate()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void hasClosed(MessageProducerWrapper mpw)
/*     */   {
/* 643 */     if (this.producers.contains(mpw)) {
/* 644 */       this.producers.remove(mpw);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 649 */       JCATraceAdapter.traceInfo(this, "SessionWrapper", "hasClosed(MessageProducerWrapper", "attempt to close an unknown MessageProducerWrapper ignored");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void hasClosed(MessageConsumerWrapper mcw)
/*     */   {
/* 661 */     if (this.consumers.contains(mcw)) {
/* 662 */       this.consumers.remove(mcw);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 667 */       JCATraceAdapter.traceInfo(this, "SessionWrapper", "hasClosed(MessageConsumerWrapper", "attempt to close an unknown MessageConsumerWrapper ignored");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void hasClosed(QueueBrowserWrapper qbw)
/*     */   {
/* 679 */     if (this.browsers.contains(qbw)) {
/* 680 */       this.browsers.remove(qbw);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 685 */       JCATraceAdapter.traceInfo(this, "SessionWrapper", "hasClosed(QueueBrowserWrapper", "attempt to close an unknown QueueBrowserWrapper ignored");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/SessionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */