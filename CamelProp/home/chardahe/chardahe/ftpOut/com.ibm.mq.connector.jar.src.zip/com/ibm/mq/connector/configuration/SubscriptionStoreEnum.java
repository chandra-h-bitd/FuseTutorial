/*     */ package com.ibm.mq.connector.configuration;
/*     */ 
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum SubscriptionStoreEnum
/*     */ {
/*  36 */   BROKER("BROKER", "XMSC_WMQ_SUBSCRIPTION_STORE", 1), 
/*     */   
/*  38 */   MIGRATE("MIGRATE", "XMSC_WMQ_SUBSCRIPTION_STORE", 2), 
/*     */   
/*  40 */   QUEUE("QUEUE", "XMSC_WMQ_SUBSCRIPTION_STORE", 0);
/*     */   
/*     */ 
/*     */ 
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2010 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   
/*     */ 
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/configuration/SubscriptionStoreEnum.java";
/*     */   
/*     */ 
/*     */   private String tag;
/*     */   
/*     */ 
/*     */   private String property;
/*     */   
/*     */   private int propertyValue;
/*     */   
/*     */   private static HashMap<String, SubscriptionStoreEnum> lookup;
/*     */   
/*     */ 
/*     */   private SubscriptionStoreEnum(String tag, String property, int propertyValue)
/*     */   {
/*  62 */     this.tag = tag;
/*  63 */     this.property = property;
/*  64 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  72 */     lookup = new HashMap();
/*  73 */     for (SubscriptionStoreEnum e : values()) {
/*  74 */       lookup.put(e.tag, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SubscriptionStoreEnum byTag(String tag)
/*     */   {
/*  84 */     return (SubscriptionStoreEnum)lookup.get(tag.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(JmsPropertyContext context)
/*     */     throws JMSException
/*     */   {
/*  93 */     context.setIntProperty(this.property, this.propertyValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTag()
/*     */   {
/* 100 */     return this.tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 108 */     return this.tag;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/configuration/SubscriptionStoreEnum.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */