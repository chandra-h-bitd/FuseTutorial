/*    */ package com.ibm.mq.connector.services;
/*    */ 
/*    */ import com.ibm.msg.client.commonservices.Log.Log;
/*    */ import com.ibm.msg.client.commonservices.nls.NLSServices;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JCAMessageBuilder
/*    */ {
/*    */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*    */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/JCAMessageBuilder.java";
/*    */   
/*    */   public static void buildWarning(String messageType)
/*    */   {
/* 66 */     buildWarning(messageType, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void buildWarning(String messageType, HashMap inserts)
/*    */   {
/* 79 */     if (JCATraceAdapter.isOn)
/*    */     {
/* 81 */       JCATraceAdapter.traceWarning(null, "JCAMessageBuilder", "buildWarning()", NLSServices.getMessage(messageType, inserts));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 86 */     Log.log("JCAMessageBuilder", "buildWarning()", messageType, inserts);
/*    */   }
/*    */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/JCAMessageBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */