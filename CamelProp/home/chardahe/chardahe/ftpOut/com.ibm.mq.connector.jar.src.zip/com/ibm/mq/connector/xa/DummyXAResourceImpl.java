/*    */ package com.ibm.mq.connector.xa;
/*    */ 
/*    */ import javax.transaction.xa.XAResource;
/*    */ import javax.transaction.xa.Xid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DummyXAResourceImpl
/*    */   implements XAResource
/*    */ {
/* 37 */   private static DummyXAResourceImpl theInstance = new DummyXAResourceImpl();
/*    */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2009 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*    */   
/* 40 */   public static DummyXAResourceImpl getInstance() { return theInstance; }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/xa/DummyXAResourceImpl.java";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void commit(Xid arg0, boolean arg1) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void end(Xid arg0, int arg1) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void forget(Xid arg0) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getTransactionTimeout()
/*    */   {
/* 73 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean isSameRM(XAResource arg0)
/*    */   {
/* 78 */     return false;
/*    */   }
/*    */   
/*    */   public int prepare(Xid arg0)
/*    */   {
/* 83 */     return 3;
/*    */   }
/*    */   
/*    */   public Xid[] recover(int arg0)
/*    */   {
/* 88 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public void rollback(Xid arg0) {}
/*    */   
/*    */ 
/*    */   public boolean setTransactionTimeout(int arg0)
/*    */   {
/* 97 */     return false;
/*    */   }
/*    */   
/*    */   public void start(Xid arg0, int arg1) {}
/*    */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/xa/DummyXAResourceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */