/*     */ package com.ibm.mq.connector;
/*     */ 
/*     */ import com.ibm.mq.connector.inbound.ActivationSpecImpl;
/*     */ import com.ibm.mq.connector.inbound.ConnectionHandler;
/*     */ import com.ibm.mq.connector.inbound.MessageEndpointDeployment;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.connector.xa.DummyXAResourceImpl;
/*     */ import com.ibm.msg.client.commonservices.Log.Log;
/*     */ import com.ibm.msg.client.commonservices.componentmanager.Component;
/*     */ import com.ibm.msg.client.commonservices.componentmanager.ComponentManager;
/*     */ import com.ibm.msg.client.commonservices.j2se.J2SEComponent;
/*     */ import com.ibm.msg.client.commonservices.nls.NLSServices;
/*     */ import com.ibm.msg.client.commonservices.propertystore.PropertyStore;
/*     */ import com.ibm.msg.client.jms.JmsFactoryFactory;
/*     */ import com.ibm.msg.client.wmq.factories.WMQComponent;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ActivationSpec;
/*     */ import javax.resource.spi.BootstrapContext;
/*     */ import javax.resource.spi.ResourceAdapter;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import javax.resource.spi.work.WorkManager;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceAdapterImpl
/*     */   extends ResourceAdapterConfiguration
/*     */   implements ResourceAdapter
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/ResourceAdapterImpl.java";
/*  95 */   private BootstrapContext theBootstrapContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private transient WorkManager theWorkManager = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private Map<MessageEndpointUID, MessageEndpointDeployment> endpoints = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private static Method onMessageMethod = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   private static boolean inboundDisabled = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   private static final Class<MessageListener> JMS_MSG_LISTENER = MessageListener.class;
/*     */   
/*     */ 
/*     */   private static final String JMS_MSG_LISTENER_METHOD = "onMessage";
/*     */   
/*     */ 
/* 133 */   private static final Class<?>[] JMS_MSG_LISTENER_PARAMETERS = { Message.class };
/*     */   
/*     */ 
/*     */   private static final String JCA_RUNTIME_HELPER_KEY = "com.ibm.mq.connector.JCARuntimeHelper";
/*     */   
/*     */ 
/*     */   public static final String NONASF_TIMEOUT = "com.ibm.mq.connector.nonASFTimeout";
/*     */   
/*     */ 
/*     */   public static final String NONASF_ROLLBACK_ENABLED = "com.ibm.mq.connector.nonASFRollbackEnabled";
/*     */   
/*     */ 
/* 145 */   private static JCARuntimeHelper theJCARuntimeHelper = null;
/*     */   
/*     */ 
/*     */   public static final long serialVersionUID = 4815162342L;
/*     */   
/*     */ 
/* 151 */   private List<ActivationSpec> endpointsPausing = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 169 */     ComponentManager compmgr = ComponentManager.getInstance();
/* 170 */     Component j2se = new J2SEComponent();
/* 171 */     compmgr.registerComponent(j2se);
/*     */     
/* 173 */     Component wmq = new WMQComponent();
/* 174 */     compmgr.registerComponent(wmq);
/*     */     
/*     */ 
/* 177 */     JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "{static}", "Registering default runtime helper");
/* 178 */     PropertyStore.register("com.ibm.mq.connector.JCARuntimeHelper", new DefaultRuntimeHelperImpl());
/*     */     
/*     */ 
/* 181 */     PropertyStore.register("com.ibm.mq.connector.nonASFTimeout", 0L, Long.valueOf(0L), Long.valueOf(2147483647L));
/* 182 */     PropertyStore.register("com.ibm.mq.connector.nonASFRollbackEnabled", false);
/*     */     
/*     */ 
/* 185 */     NLSServices.addCatalogue("com.ibm.mq.connector.services.resources.MQJCA_MessageResourceBundle", "MQJCA", ResourceAdapterImpl.class);
/*     */     
/*     */ 
/* 188 */     if (checkWASv7())
/*     */     {
/* 190 */       if ((theJCARuntimeHelper.getEnvironment() == 2) || (theJCARuntimeHelper.getEnvironment() == 4))
/*     */       {
/* 192 */         JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "{static}", "In WAS client, XA transactions are not supported");
/*     */         
/* 194 */         inboundDisabled = true;
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 201 */         JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
/*     */       }
/*     */       catch (JMSException e)
/*     */       {
/* 205 */         HashMap<String, Object> info = new HashMap();
/* 206 */         info.put("Exception", e);
/* 207 */         JCATraceAdapter.ffst(null, "ResourceAdapterImpl", "JCA02003", info);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 216 */       onMessageMethod = JMS_MSG_LISTENER.getMethod("onMessage", JMS_MSG_LISTENER_PARAMETERS);
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*     */ 
/* 222 */       inboundDisabled = true;
/*     */     }
/*     */     
/*     */ 
/* 226 */     HashMap<String, String> inserts = new HashMap();
/* 227 */     inserts.put("JCA_VERSION", j2se.getVersionString() + "-" + (String)j2se.getImplementationInfo().get("CMVC"));
/* 228 */     Log.log("ResourceAdapterImpl", "verifyJMSClasses()", "MQJCA5001", inserts);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceAdapterImpl()
/*     */   {
/* 249 */     ConnectionHandler.registerResourceAdapter(this);
/*     */     
/*     */ 
/* 252 */     this.endpoints = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start(BootstrapContext ctx)
/*     */     throws ResourceAdapterInternalException
/*     */   {
/* 274 */     initializeTrace();
/*     */     
/*     */ 
/* 277 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterImpl", "start(...)");
/*     */     try
/*     */     {
/* 280 */       this.theBootstrapContext = ctx;
/*     */       
/* 282 */       this.theWorkManager = this.theBootstrapContext.getWorkManager();
/*     */       
/*     */ 
/* 285 */       verifyJCAClasses();
/*     */       
/* 287 */       verifyJMSClasses();
/*     */       
/*     */ 
/* 290 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "Acquired WorkManager: " + this.theWorkManager.getClass().getName());
/*     */       
/*     */ 
/* 293 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "ResourceAdapter deployment successful");
/*     */       
/*     */ 
/* 296 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "effectiveMaxConnections = " + getEffectiveMaxConnections());
/* 297 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "reconnectionRetryCount = " + getReconnectionRetryCount());
/* 298 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "reconnectionRetryInterval = " + getReconnectionRetryInterval());
/* 299 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "startupRetryCount = " + getStartupRetryCount());
/* 300 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "start(...)", "startupRetryInterval = " + getStartupRetryInterval());
/*     */     }
/*     */     finally
/*     */     {
/* 304 */       JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "start(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 320 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterImpl", "stop()");
/*     */     
/*     */ 
/* 323 */     synchronized (this.endpoints) {
/* 324 */       for (Map.Entry<MessageEndpointUID, MessageEndpointDeployment> endpointEntry : this.endpoints.entrySet())
/*     */       {
/*     */ 
/*     */ 
/* 328 */         MessageEndpointUID u = (MessageEndpointUID)endpointEntry.getKey();
/*     */         
/*     */ 
/* 331 */         MessageEndpointDeployment p = (MessageEndpointDeployment)endpointEntry.getValue();
/*     */         
/* 333 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "stop()", "stopping MessageEndpoint: " + u.getActivationSpec() + "...");
/*     */         
/* 335 */         p.stop();
/* 336 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "stop()", "...MessageEndpoint stopped");
/*     */         
/*     */ 
/* 339 */         this.endpoints.remove(u);
/*     */         
/*     */ 
/* 342 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "stop()", "ResourceAdapter " + this + " shutdown successful");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 347 */     ConnectionHandler.getInstance().close();
/*     */     
/*     */ 
/* 350 */     JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "stop()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endpointActivation(MessageEndpointFactory mef, ActivationSpec actSpec)
/*     */     throws ResourceException
/*     */   {
/* 369 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterImpl", "endpointActivation(...)");
/*     */     
/*     */     try
/*     */     {
/* 373 */       if (inboundDisabled)
/*     */       {
/* 375 */         throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1001"));
/*     */       }
/*     */       
/* 378 */       if ((actSpec instanceof ActivationSpecImpl))
/*     */       {
/*     */ 
/* 381 */         boolean transacted = mef.isDeliveryTransacted(onMessageMethod);
/* 382 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointActivation(...)", "endpoint transacted: " + transacted);
/*     */         
/* 384 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointActivation(...)", "activating " + actSpec);
/*     */         
/* 386 */         actSpec.setResourceAdapter(this);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 392 */         synchronized (this.endpoints) {
/* 393 */           MessageEndpointDeployment endpoint = new MessageEndpointDeployment(this, mef, actSpec, this.theWorkManager, transacted);
/*     */           
/* 395 */           MessageEndpointUID uid = new MessageEndpointUID(mef, actSpec);
/* 396 */           this.endpoints.put(uid, endpoint);
/*     */         }
/*     */         
/*     */ 
/* 400 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointActivation(...)", "Endpoint " + actSpec + " activated");
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 405 */         JCAExceptionBuilder.buildException(0, "MQJCA1002");
/*     */       }
/*     */       
/*     */     }
/*     */     catch (NoSuchMethodException nsme)
/*     */     {
/* 411 */       JCAExceptionBuilder.buildException(0, "MQJCA1003", nsme);
/*     */     }
/*     */     
/* 414 */     JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "endpointActivation(...)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endpointDeactivation(MessageEndpointFactory mef, ActivationSpec actSpec)
/*     */   {
/* 432 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterImpl", "endpointDeactivation(...)");
/*     */     
/*     */ 
/* 435 */     if ((actSpec instanceof ActivationSpecImpl)) {
/* 436 */       synchronized (this.endpointsPausing) {
/* 437 */         if (this.endpointsPausing.contains(actSpec)) {
/* 438 */           JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "Activation Spec '" + actSpec + "' is already deactivating. Exiting.");
/*     */           
/*     */ 
/* 441 */           JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "endpointDeactivation(...)");
/* 442 */           return;
/*     */         }
/* 444 */         this.endpointsPausing.add(actSpec);
/* 445 */         if (JCATraceAdapter.isOn) {
/* 446 */           JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "deactivating Activation spec '" + actSpec + "'");
/*     */           
/*     */ 
/* 449 */           StringBuffer buf = new StringBuffer();
/*     */           
/* 451 */           buf.append("Adding to endpointsPausing list. New list contents:");
/* 452 */           for (int i = 0; i < this.endpointsPausing.size(); i++) {
/* 453 */             buf.append("\n");
/* 454 */             buf.append(this.endpointsPausing.get(i));
/*     */           }
/*     */           
/* 457 */           JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", buf.toString());
/*     */         }
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 463 */         JCATraceAdapter.traceData(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "Waiting for endpoints lock", this.endpoints);
/*     */         
/*     */ 
/* 466 */         synchronized (this.endpoints) {
/* 467 */           JCATraceAdapter.traceData(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "Got endpoints lock", this.endpoints);
/*     */           
/*     */ 
/* 470 */           MessageEndpointUID uid = new MessageEndpointUID(mef, actSpec);
/* 471 */           MessageEndpointDeployment endpoint = (MessageEndpointDeployment)this.endpoints.get(uid);
/*     */           
/*     */ 
/* 474 */           if (endpoint != null)
/*     */           {
/* 476 */             endpoint.stop();
/*     */             
/* 478 */             this.endpoints.remove(uid);
/*     */             
/*     */ 
/* 481 */             JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "releasing connection");
/*     */             
/*     */ 
/* 484 */             theJCARuntimeHelper.clearActivationSpecificationInformation(actSpec);
/*     */             
/*     */ 
/* 487 */             JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "Endpoint " + actSpec + " deactivated");
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 494 */             JCATraceAdapter.traceNonNLSWarning(this, "ResourceAdapterImpl", "endpointDeactivation(...)", "endpointDeactivation called for unknown endpoint:" + actSpec + " ", null);
/*     */           }
/*     */         }
/*     */       } finally {
/* 498 */         synchronized (this.endpointsPausing)
/*     */         {
/* 500 */           this.endpointsPausing.remove(actSpec);
/*     */           
/* 502 */           if (JCATraceAdapter.isOn) {
/* 503 */             StringBuffer buf = new StringBuffer();
/*     */             
/* 505 */             buf.append("Removing activation spec '");
/* 506 */             buf.append(actSpec.toString());
/* 507 */             buf.append("' from endpointsPausing list. Resulting list contents:");
/* 508 */             for (int i = 0; i < this.endpointsPausing.size(); i++) {
/* 509 */               buf.append("\n");
/* 510 */               buf.append(this.endpointsPausing.get(i));
/*     */             }
/*     */             
/* 513 */             JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "endpointDeactivation(...)", buf.toString());
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 522 */       JCAExceptionBuilder.buildException(0, "MQJCA1002");
/*     */     }
/*     */     
/*     */ 
/* 526 */     JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "endpointDeactivation(...)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XAResource[] getXAResources(ActivationSpec[] actSpecs)
/*     */     throws ResourceException
/*     */   {
/* 548 */     JCATraceAdapter.traceEntry(this, "ResourceAdapterImpl", "getXAResources(...)");
/*     */     
/*     */     try
/*     */     {
/* 552 */       List<XAResource> recoveryList = new ArrayList();
/*     */       ActivationSpecImpl actSpec;
/* 554 */       for (int i = 0; i < actSpecs.length; i++)
/*     */       {
/* 556 */         if ((actSpecs[i] instanceof ActivationSpecImpl))
/*     */         {
/*     */ 
/*     */ 
/* 560 */           actSpec = (ActivationSpecImpl)actSpecs[i];
/*     */           
/* 562 */           JCATraceAdapter.traceData(this, "ResourceAdapterImpl", "getXAResources(...)", "Creating XAResource for ActivationSpecImpl", actSpec);
/*     */           
/* 564 */           if ((isZOS()) && (actSpec.getTransportType().equalsIgnoreCase("BINDINGS")))
/*     */           {
/*     */ 
/* 567 */             JCATraceAdapter.traceData(this, "ResourceAdapterImpl", "getXAResources(...)", "Bindings only connection adding on z/OS - adding dummy XAResource", DummyXAResourceImpl.getInstance());
/* 568 */             recoveryList.add(DummyXAResourceImpl.getInstance());
/*     */           }
/*     */           else {
/*     */             try {
/* 572 */               RecoveryXAResource rXAR = new RecoveryXAResource(actSpec, isZOS());
/* 573 */               JCATraceAdapter.traceData(this, "ResourceAdapterImpl", "getXAResources(...)", "Adding RecoveryXAResource", rXAR);
/* 574 */               recoveryList.add(rXAR);
/*     */             } catch (XAException e) {
/* 576 */               JCATraceAdapter.traceException(this, "ResourceAdapterImpl", "getXAResources(...)", e);
/* 577 */               JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "getXAResources(...)", "Unable to obtain RecoveryXAResource for " + actSpec + ". Rethrowing exception as a resource exception");
/*     */               
/* 579 */               ResourceException raie = (ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", e);
/*     */               
/*     */ 
/* 582 */               throw raie;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 591 */           JCAMessageBuilder.buildWarning("MQJCA1002");
/*     */           
/* 593 */           JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "getXAResources(...)", "unknown activation spec: " + actSpecs[i]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 598 */       XAResource[] resourceArray = (XAResource[])recoveryList.toArray(new XAResource[0]);
/*     */       
/* 600 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "getXAResources(...)", "returning " + resourceArray.length + " XAResources");
/*     */       
/* 602 */       return resourceArray;
/*     */     }
/*     */     finally
/*     */     {
/* 606 */       JCATraceAdapter.traceExit(this, "ResourceAdapterImpl", "getXAResources(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean equals(Object o)
/*     */   {
/* 621 */     return super.equals(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 633 */     return super.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getOnMessageMethod()
/*     */   {
/* 644 */     return onMessageMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JCARuntimeHelper getJCARuntimeHelper()
/*     */   {
/* 654 */     return theJCARuntimeHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void initializeTrace()
/*     */   {
/* 664 */     if (!JCATraceAdapter.isEnabled()) {
/* 665 */       if ((getTraceEnabled()) && (getTraceLevel() != 0))
/*     */       {
/* 667 */         JCATraceAdapter.setTraceLevel(getTraceLevel());
/*     */         
/* 669 */         if (getLogWriterEnabled()) {
/* 670 */           JCATraceAdapter.enableLogWriter();
/*     */         }
/*     */         else {
/* 673 */           JCATraceAdapter.disableLogWriter();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 678 */         JCATraceAdapter.disableTrace();
/*     */       }
/*     */     }
/*     */     
/* 682 */     Package p = getClass().getPackage();
/* 683 */     JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "intializeTrace", "Implementation-Title: " + p.getImplementationTitle());
/* 684 */     JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "intializeTrace", "Implementation-Version: " + p.getImplementationVersion());
/*     */     
/*     */ 
/* 687 */     if (theJCARuntimeHelper.getEnvironment() != 1)
/*     */     {
/* 689 */       JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "initializeTrace", "running in WebSphere Application Server");
/* 690 */       if ((theJCARuntimeHelper.getEnvironment() == 4) || (theJCARuntimeHelper.getEnvironment() == 2)) {
/* 691 */         JCATraceAdapter.traceInfo(this, "ResourceAdapterImpl", "initializeTrace", "in THIN_CLIENT or APPLICATION_CLIENT, XA and MDB support disabled");
/*     */       }
/*     */     }
/*     */     
/* 695 */     if (inboundDisabled)
/*     */     {
/* 697 */       JCAMessageBuilder.buildWarning("MQJCA4002");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void verifyJCAClasses()
/*     */     throws ResourceAdapterInternalException
/*     */   {
/* 713 */     JCATraceAdapter.traceEntry(null, "ResourceAdapterImpl", "verifyJCAClasses()");
/*     */     
/*     */     try
/*     */     {
/* 717 */       Class<?> c = Class.forName("javax.resource.ResourceException");
/*     */       
/* 719 */       Class<?>[] params = { String.class, Throwable.class };
/* 720 */       c.getConstructor(params);
/*     */       
/* 722 */       JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "verifyJCAClasses()", "JCA v1.5 classes found");
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/* 727 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1005"));
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException nsme)
/*     */     {
/*     */ 
/* 734 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1006"));
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (SecurityException se)
/*     */     {
/*     */ 
/* 741 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1005"));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 746 */       JCATraceAdapter.traceExit(null, "ResourceAdapterImpl", "verifyJCAClasses()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void verifyJMSClasses()
/*     */     throws ResourceAdapterInternalException
/*     */   {
/* 761 */     JCATraceAdapter.traceEntry(null, "ResourceAdapterImpl", "verifyJMSClasses()");
/*     */     try
/*     */     {
/* 764 */       Class<?> c1 = Class.forName("com.ibm.mq.connector.ResourceAdapterImpl");
/* 765 */       Class<?> c2 = Class.forName("com.ibm.mq.jms.MQConnectionFactory");
/*     */       
/* 767 */       String thisImplVer = c1.getPackage().getImplementationVersion();
/* 768 */       String ma88ImplVer = c2.getPackage().getImplementationVersion();
/* 769 */       JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "verifyJMSClasses()", "RA version: " + thisImplVer);
/* 770 */       JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "verifyJMSClasses()", "WMQ JMS Version: " + ma88ImplVer);
/*     */       
/* 772 */       if (thisImplVer == null)
/*     */       {
/*     */ 
/* 775 */         JCATraceAdapter.traceNonNLSWarning(null, "ResourceAdapterImpl", "verifyJMSClasses()", "implementation version not set, version check skipped", null);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 785 */         String[] t1 = thisImplVer.split("-");
/* 786 */         String[] t2 = ma88ImplVer.split("-");
/*     */         
/* 788 */         boolean ok = t1.length == t2.length;
/*     */         
/* 790 */         for (int i = 0; (ok) && (i < t1.length); i++) {
/* 791 */           ok = t1[i].trim().equals(t2[i].trim());
/*     */         }
/*     */         
/* 794 */         if (ok)
/*     */         {
/* 796 */           JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "verifyJMSClasses()", "The correct level of the WMQ JMS client was found");
/*     */         }
/*     */         else
/*     */         {
/* 800 */           throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1008"));
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/* 808 */       throw ((ResourceAdapterInternalException)JCAExceptionBuilder.buildException(1, "MQJCA1007"));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 813 */       JCATraceAdapter.traceExit(null, "ResourceAdapterImpl", "verifyJMSClasses()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean checkWASv7()
/*     */   {
/* 825 */     JCATraceAdapter.traceEntry(null, "ResourceAdapterImpl", "checkWASv7()");
/*     */     
/*     */     try
/*     */     {
/* 829 */       if (theJCARuntimeHelper == null)
/*     */       {
/*     */ 
/* 832 */         theJCARuntimeHelper = (JCARuntimeHelper)PropertyStore.getObjectProperty("com.ibm.mq.connector.JCARuntimeHelper");
/*     */         
/* 834 */         if (theJCARuntimeHelper == null)
/*     */         {
/* 836 */           JCATraceAdapter.traceNonNLSWarning(null, "ResourceAdapterImpl", "checkWASv7()", "PropertyStore returned a null JCARuntimeHelper", null);
/*     */           
/* 838 */           theJCARuntimeHelper = new DefaultRuntimeHelperImpl();
/*     */         }
/*     */       }
/* 841 */       JCATraceAdapter.traceInfo(ResourceAdapterImpl.class, "ResourceAdapterImpl", "checkWASv7()", "getEnvironment() returns: " + theJCARuntimeHelper.getEnvironment());
/*     */       
/* 843 */       return theJCARuntimeHelper.getEnvironment() != 1;
/*     */     }
/*     */     finally
/*     */     {
/* 847 */       JCATraceAdapter.traceExit(null, "ResourceAdapterImpl", "checkWASv7()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/ResourceAdapterImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */