/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.connector.xa.XAObserver;
/*     */ import com.ibm.mq.connector.xa.XARWrapper;
/*     */ import java.io.PrintWriter;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ExceptionListener;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TemporaryQueue;
/*     */ import javax.jms.TemporaryTopic;
/*     */ import javax.jms.XAConnection;
/*     */ import javax.jms.XASession;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionEventListener;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.LocalTransaction;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ import javax.resource.spi.SecurityException;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.transaction.xa.XAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedConnectionImpl
/*     */   implements ManagedConnection, ExceptionListener, XAObserver
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedConnectionImpl.java";
/*  90 */   private PrintWriter thePrintWriter = null;
/*     */   
/*     */ 
/*  93 */   protected Connection thePhysicalConnection = null;
/*     */   
/*     */ 
/*  96 */   protected XASession thePhysicalXASession = null;
/*     */   
/*     */ 
/*  99 */   protected Session thePhysicalSession = null;
/*     */   
/*     */ 
/* 102 */   private ConnectionEventHandler theConnectionEventHandler = null;
/*     */   
/*     */ 
/* 105 */   protected ManagedConnectionFactoryImpl theMCF = null;
/*     */   
/*     */ 
/* 108 */   protected Subject theSubject = null;
/*     */   
/*     */ 
/* 111 */   protected ConnectionRequestInfo theConnectionRequestInfo = null;
/*     */   
/*     */ 
/* 114 */   private String userName = null;
/*     */   
/*     */ 
/* 117 */   protected Set connectionHandles = null;
/*     */   
/*     */ 
/* 120 */   private boolean transactionActive = false;
/*     */   
/* 122 */   private ArrayList<TemporaryQueue> temporaryQueues = new ArrayList();
/* 123 */   private ArrayList<TemporaryTopic> temporaryTopics = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ManagedConnectionImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ManagedConnectionImpl(final Subject s, ConnectionRequestInfo cri, ManagedConnectionFactoryImpl mcf)
/*     */     throws ResourceException
/*     */   {
/* 146 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "<init>");
/*     */     try
/*     */     {
/* 149 */       this.theMCF = mcf;
/*     */       
/* 151 */       this.thePhysicalConnection = this.theMCF.createConnection(this, s, cri);
/*     */       
/* 153 */       this.connectionHandles = new HashSet();
/*     */       try
/*     */       {
/* 156 */         this.thePhysicalConnection.setExceptionListener(this);
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (JMSException je)
/*     */       {
/*     */ 
/* 163 */         HashMap inserts = new HashMap();
/* 164 */         inserts.put("JCA_JMS_EXCEPTION", je.getMessage());
/* 165 */         JCAMessageBuilder.buildWarning("MQJCA4003", inserts);
/*     */         
/*     */ 
/* 168 */         JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "<init>", je);
/*     */       }
/*     */       
/* 171 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "<init>", "ConnectionRequestInfo: " + cri);
/*     */       
/* 173 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Object run() {
/* 176 */           JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "<init>", "subject: " + s);
/* 177 */           return null;
/*     */         }
/* 179 */       });
/* 180 */       this.theConnectionRequestInfo = cri;
/* 181 */       this.theSubject = s;
/* 182 */       this.theConnectionEventHandler = new ConnectionEventHandler(this);
/*     */     }
/*     */     finally
/*     */     {
/* 186 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getConnection(final Subject subj, final ConnectionRequestInfo cri)
/*     */     throws SecurityException
/*     */   {
/* 214 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "getConnection(...)");
/*     */     try {
/* 216 */       if ((this.theConnectionRequestInfo != null) && (!this.theConnectionRequestInfo.equals(cri)))
/*     */       {
/* 218 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getConnection(...)", "connection request info mismatch");
/*     */         
/*     */ 
/* 221 */         throw ((SecurityException)JCAExceptionBuilder.buildException(5, "MQJCA1028"));
/*     */       }
/*     */       
/* 224 */       if (wrongSubject(subj))
/*     */       {
/* 226 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getConnection(...)", "Subject mismatch");
/*     */         
/*     */ 
/* 229 */         throw ((SecurityException)JCAExceptionBuilder.buildException(5, "MQJCA1028"));
/*     */       }
/*     */       
/*     */ 
/* 233 */       if (JCATraceAdapter.isOn) {
/* 234 */         if ((subj == null) && (cri == null)) {
/* 235 */           JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getConnection(...)", "Subject, ConnectionRequestInfo null");
/*     */         }
/*     */         else
/*     */         {
/* 239 */           AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/* 242 */               JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getConnection(...)", "Subject: " + subj + ", ConnectionRequestInfo: " + cri);
/*     */               
/* 244 */               return null;
/*     */             }
/*     */           });
/*     */         }
/*     */       }
/*     */       
/* 250 */       ConnectionWrapper handle = new ConnectionWrapper(this, this.thePhysicalConnection, this.theMCF.isManaged());
/*     */       
/*     */ 
/* 253 */       this.connectionHandles.add(handle);
/*     */       
/* 255 */       return handle;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 260 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "getConnection(...)");
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean wrongSubject(final Subject subj) {
/* 265 */     Boolean result = (Boolean)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run() {
/* 268 */         return new Boolean((ManagedConnectionImpl.this.theSubject != null) && (!ManagedConnectionImpl.this.theSubject.equals(subj)));
/*     */       }
/* 270 */     });
/* 271 */     return result.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 284 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "destroy()");
/*     */     try
/*     */     {
/* 287 */       cleanup();
/*     */       
/* 289 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "destroy()", "closing JMS resources");
/*     */       
/*     */ 
/* 292 */       if (this.thePhysicalConnection != null) {
/* 293 */         this.thePhysicalConnection.close();
/* 294 */         this.thePhysicalConnection = null;
/*     */       }
/*     */       
/* 297 */       if (this.thePhysicalXASession != null) {
/* 298 */         this.thePhysicalXASession.close();
/*     */       }
/*     */       
/* 301 */       if (this.thePhysicalSession != null) {
/* 302 */         this.thePhysicalSession.close();
/*     */       }
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 307 */       JCAMessageBuilder.buildWarning("MQJCA4011");
/*     */       
/* 309 */       JCATraceAdapter.traceException(this, "MessageEndpointDeployment", "stop()", je);
/*     */     }
/*     */     finally
/*     */     {
/* 313 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "destroy()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanup()
/*     */   {
/* 340 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "cleanup()");
/*     */     try {
/* 342 */       deleteTempDestinations();
/*     */     } catch (JMSException e) {
/* 344 */       JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "cleanup()", e);
/*     */     }
/*     */     
/* 347 */     Iterator i = this.connectionHandles.iterator();
/* 348 */     int iCount = 0;
/* 349 */     while (i.hasNext())
/*     */     {
/* 351 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "cleanup()", "closing connection handle " + ++iCount + " of " + this.connectionHandles.size());
/*     */       
/*     */ 
/* 354 */       ((ConnectionWrapper)i.next()).close();
/*     */     }
/*     */     
/* 357 */     this.connectionHandles = new HashSet();
/*     */     
/* 359 */     JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "cleanup()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void associateConnection(Object conn)
/*     */     throws ResourceException
/*     */   {
/* 377 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "associateConnection()");
/*     */     try
/*     */     {
/* 380 */       if ((conn instanceof ConnectionWrapper))
/*     */       {
/* 382 */         ((ConnectionWrapper)conn).reassociate(this);
/*     */         
/* 384 */         this.connectionHandles.add(conn);
/*     */       }
/*     */       else
/*     */       {
/* 388 */         JCATraceAdapter.traceNonNLSWarning(this, "ManagedConnectionImpl", "associateConnection()", "unexpected object type: " + conn.getClass(), null);
/*     */         
/* 390 */         throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1011"));
/*     */       }
/*     */       
/*     */     }
/*     */     catch (JMSException je)
/*     */     {
/* 396 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA0001", je));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 401 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "associateConnection()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConnectionEventListener(ConnectionEventListener listener)
/*     */   {
/* 415 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "addConnectionEventListener()");
/*     */     try {
/* 417 */       this.theConnectionEventHandler.addListener(listener);
/*     */     }
/*     */     finally
/*     */     {
/* 421 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "addConnectionEventListener()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeConnectionEventListener(ConnectionEventListener listener)
/*     */   {
/* 432 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "removeConnectionEventListener()");
/*     */     try {
/* 434 */       this.theConnectionEventHandler.removeListener(listener);
/*     */     }
/*     */     finally
/*     */     {
/* 438 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "removeConnectionEventListener()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XAResource getXAResource()
/*     */     throws ResourceException
/*     */   {
/* 452 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "getXAResource()");
/*     */     try
/*     */     {
/* 455 */       XARWrapper xar = null;
/* 456 */       if (this.theMCF.isXAConnectionFactory())
/*     */       {
/* 458 */         if (this.thePhysicalXASession == null) {
/* 459 */           this.thePhysicalXASession = ((XAConnection)this.thePhysicalConnection).createXASession();
/*     */         }
/*     */         
/* 462 */         xar = new XARWrapper(this.thePhysicalXASession.getXAResource(), this.thePhysicalXASession);
/*     */         
/* 464 */         xar.addXAObserver(this);
/*     */         
/* 466 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getXAResource()", "Returning XARWrapper: " + xar);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 471 */       else if (this.theMCF.isXAConnectionFactory())
/*     */       {
/* 473 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getXAResource()", "XA disabled on this connection, returning null");
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 478 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getXAResource()", "XA unsupported in this environment, returning null");
/*     */       }
/*     */       
/*     */ 
/* 482 */       return xar;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 486 */       throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1013", e));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 491 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "getXAResource()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LocalTransaction getLocalTransaction()
/*     */   {
/* 510 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "getLocalTransaction()");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 516 */       return new LocalTransactionImpl(this);
/*     */     }
/*     */     finally
/*     */     {
/* 520 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "getLocalTransaction()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createTransactedNonXASession()
/*     */     throws JMSException
/*     */   {
/* 534 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "createTransactedNonXASession()");
/*     */     try
/*     */     {
/* 537 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "createTransactedNonXASession()", "creating new locally-transacted Session");
/*     */       
/*     */ 
/* 540 */       this.thePhysicalSession = this.thePhysicalConnection.createSession(true, 1);
/*     */     }
/*     */     finally
/*     */     {
/* 544 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "createTransactedNonXASession()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnectionMetaData getMetaData()
/*     */   {
/* 553 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "getMetaData()");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 558 */       return new ManagedConnectionMetaDataImpl(this.userName);
/*     */     }
/*     */     finally
/*     */     {
/* 562 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "getMetaData()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogWriter(PrintWriter pw)
/*     */   {
/* 571 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "setLogWriter()");
/*     */     
/* 573 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "setLogWriter()", "PrintWriter: " + pw);
/*     */     
/*     */ 
/*     */ 
/* 577 */     if (JCATraceAdapter.isLogWriterEnabled()) {
/* 578 */       this.thePrintWriter = pw;
/*     */     }
/*     */     else
/*     */     {
/* 582 */       this.thePrintWriter = null;
/*     */       
/*     */ 
/*     */ 
/* 586 */       if (!ManagedConnectionFactoryImpl.isPwWarningSent()) {
/* 587 */         JCAMessageBuilder.buildWarning("MQJCA4017");
/*     */         
/* 589 */         ManagedConnectionFactoryImpl.setPwWarningSent(true);
/*     */       }
/*     */     }
/*     */     
/* 593 */     JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "setLogWriter()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintWriter getLogWriter()
/*     */   {
/* 601 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getLogWriter()", "LogWriter: " + this.thePrintWriter);
/*     */     
/* 603 */     return this.thePrintWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void beginLocalTransaction()
/*     */     throws JMSException
/*     */   {
/* 616 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "beginLocalTransaction()");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 627 */       if ((this.thePhysicalSession == null) || (!this.thePhysicalSession.getTransacted()))
/*     */       {
/* 629 */         createTransactedNonXASession();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 635 */         this.thePhysicalSession.rollback();
/*     */       }
/*     */       
/* 638 */       this.theConnectionEventHandler.fireEvent(2, this, null);
/*     */     }
/*     */     finally {
/* 641 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "beginLocalTransaction()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected synchronized void commitLocalTransaction()
/*     */     throws JMSException
/*     */   {
/* 649 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "commitLocalTransaction()");
/*     */     try
/*     */     {
/* 652 */       this.thePhysicalSession.commit();
/*     */       
/* 654 */       this.theConnectionEventHandler.fireEvent(3, this, null);
/*     */     }
/*     */     finally {
/* 657 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "commitLocalTransaction()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected synchronized void rollbackLocalTransaction()
/*     */     throws JMSException
/*     */   {
/* 665 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "rollbackLocalTransaction()");
/*     */     try
/*     */     {
/* 668 */       this.thePhysicalSession.rollback();
/*     */       
/* 670 */       this.theConnectionEventHandler.fireEvent(4, this, null);
/*     */     }
/*     */     finally {
/* 673 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "rollbackLocalTransaction()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ManagedConnectionFactoryImpl getManagedConnectionFactory()
/*     */   {
/* 685 */     return this.theMCF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getPhysicalConnection()
/*     */   {
/* 694 */     return this.thePhysicalConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getPhysicalSession()
/*     */     throws JMSException
/*     */   {
/* 706 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "getPhysicalSession()");
/*     */     try
/*     */     {
/* 709 */       Session theSession = null;
/* 710 */       if (isTransactionStarted())
/*     */       {
/* 712 */         if (this.thePhysicalXASession == null) {
/* 713 */           this.thePhysicalXASession = ((XAConnection)this.thePhysicalConnection).createXASession();
/*     */         }
/* 715 */         theSession = this.thePhysicalXASession;
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 723 */         if (this.thePhysicalSession == null) {
/* 724 */           this.thePhysicalSession = this.thePhysicalConnection.createSession(false, 1);
/*     */         }
/* 726 */         theSession = this.thePhysicalSession;
/*     */       }
/*     */       
/* 729 */       if (JCATraceAdapter.isOn) {
/* 730 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "getPhysicalSession()", "returning: " + (theSession != null ? theSession.getClass().getName() : "null"));
/*     */       }
/*     */       
/* 733 */       return theSession;
/*     */     }
/*     */     finally {
/* 736 */       JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "getPhysicalSession()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserName(String userName)
/*     */   {
/* 747 */     this.userName = userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 756 */     return this.userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTransactionStarted()
/*     */   {
/* 766 */     return this.transactionActive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireConnectionClosed(ConnectionWrapper handle)
/*     */   {
/* 777 */     if (this.connectionHandles.contains(handle))
/*     */     {
/* 779 */       this.connectionHandles.remove(handle);
/*     */       
/* 781 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "fireConnectionClosed()", "ManagedConnectionImpl.fireConnectionClosed()");
/*     */       
/*     */ 
/* 784 */       this.theConnectionEventHandler.fireEvent(1, handle, null);
/*     */     }
/*     */     else
/*     */     {
/* 788 */       HashMap inserts = new HashMap();
/* 789 */       inserts.put("JCA_CONNECTION_HANDLE", handle.toString());
/* 790 */       JCAMessageBuilder.buildWarning("MQJCA4016", inserts);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireConnectionException(ConnectionWrapper handle, Exception e)
/*     */   {
/* 804 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "fireConnectionException()", "ConnectionHandle " + handle + " threw exception: " + e.getMessage());
/*     */     
/*     */ 
/* 807 */     this.theConnectionEventHandler.fireEvent(5, handle, e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disassociate(ConnectionWrapper handle)
/*     */   {
/* 818 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "disassociate()", "handle: " + handle);
/*     */     
/* 820 */     this.connectionHandles.remove(handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionRequestInfo getConnectionRequestInfo()
/*     */   {
/* 829 */     return this.theConnectionRequestInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Subject getSubject()
/*     */   {
/* 838 */     return this.theSubject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onException(JMSException je)
/*     */   {
/* 848 */     this.theConnectionEventHandler.fireEvent(5, this, je);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void finalize()
/*     */   {
/* 855 */     if (this.thePhysicalConnection != null) {
/* 856 */       destroy();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void xaStateChanged(int state)
/*     */   {
/* 866 */     if (state == 7) {
/* 867 */       this.transactionActive = true;
/*     */     }
/* 869 */     else if ((state == 1) || (state == 6) || (state == 3))
/*     */     {
/*     */ 
/* 872 */       this.transactionActive = false;
/*     */     }
/* 874 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "xaStateChanged", "transactionActive: " + this.transactionActive);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTempQueue(TemporaryQueue tq)
/*     */   {
/* 883 */     this.temporaryQueues.add(tq);
/*     */     try {
/* 885 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "addTempQueue(TemporaryQueue)", "Adding temporary queue " + tq.getQueueName());
/*     */     }
/*     */     catch (JMSException e) {
/* 888 */       JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "addTempQueue(TemporaryQueue)", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTempTopic(TemporaryTopic tt)
/*     */   {
/* 896 */     this.temporaryTopics.add(tt);
/*     */     try {
/* 898 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "addTempTopic(TemporaryTopic)", "Adding temporary topic " + tt.getTopicName());
/*     */     }
/*     */     catch (JMSException e) {
/* 901 */       JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "addTempTopic(TemporaryTopic)", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void deleteTempDestinations()
/*     */     throws JMSException
/*     */   {
/* 910 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionImpl", "deleteTempDestinations()");
/*     */     
/* 912 */     TemporaryQueue temporaryQueue = null;
/*     */     
/* 914 */     Iterator<TemporaryQueue> queueIterator = this.temporaryQueues.iterator();
/* 915 */     while (queueIterator.hasNext()) {
/*     */       try
/*     */       {
/* 918 */         temporaryQueue = (TemporaryQueue)queueIterator.next();
/* 919 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "deleteTempDestinations()", "Deleting temporary queue " + temporaryQueue);
/* 920 */         temporaryQueue.delete();
/* 921 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "deleteTempDestinations()", "Temporary queue " + temporaryQueue + " deleted");
/*     */       } catch (JMSException ex) {
/* 923 */         JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "deleteTempDestinations()", ex);
/*     */       }
/*     */     }
/*     */     
/* 927 */     TemporaryTopic temporaryTopic = null;
/*     */     
/* 929 */     Iterator<TemporaryTopic> topicIterator = this.temporaryTopics.iterator();
/* 930 */     while (topicIterator.hasNext()) {
/*     */       try
/*     */       {
/* 933 */         temporaryTopic = (TemporaryTopic)topicIterator.next();
/* 934 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "deleteTempDestinations()", "Deleting temporary topic " + temporaryTopic);
/* 935 */         temporaryTopic.delete();
/* 936 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionImpl", "deleteTempDestinations()", "Temporary topic " + temporaryTopic + " deleted");
/*     */       } catch (JMSException ex) {
/* 938 */         JCATraceAdapter.traceException(this, "ManagedConnectionImpl", "deleteTempDestinations()", ex);
/*     */       }
/*     */     }
/* 941 */     this.temporaryQueues.clear();
/* 942 */     this.temporaryTopics.clear();
/*     */     
/* 944 */     JCATraceAdapter.traceExit(this, "ManagedConnectionImpl", "deleteTempDestinations()");
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedConnectionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */