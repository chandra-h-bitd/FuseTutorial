/*     */ package com.ibm.mq.connector.services;
/*     */ 
/*     */ import com.ibm.msg.client.commonservices.Log.Log;
/*     */ import com.ibm.msg.client.commonservices.trace.Trace.TraceHandler;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCATraceAdapter
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/services/JCATraceAdapter.java";
/*     */   public static final int NONE = 0;
/*     */   public static final int EXCEPTIONS = 1;
/*     */   public static final int WARNINGS = 3;
/*     */   public static final int INFO = 6;
/*     */   public static final int ENTRYEXIT = 8;
/*     */   public static final int DATA = 9;
/*     */   public static final int ALL = 10;
/*     */   private static final String TRACE_ENABLED = "traceEnabled";
/*     */   private static final String TRACE_LEVEL = "traceLevel";
/*     */   private static final String LOG_WRITER_ENABLED = "logWriterEnabled";
/*  92 */   private static int traceLevel = 6;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */   public static boolean isOn = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private static boolean originalLogSetting = true;
/*     */   
/*     */ 
/* 108 */   private static boolean logWriterEnabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Trace.TraceHandler traceHandler;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 128 */     com.ibm.msg.client.commonservices.trace.Trace.registerTraceHandler(getTraceHandler());
/*     */     
/*     */ 
/* 131 */     isOn = com.ibm.msg.client.commonservices.trace.Trace.isOn;
/*     */     
/* 133 */     if (isOn) {
/* 134 */       traceLevel = com.ibm.msg.client.commonservices.trace.Trace.getTraceLevel();
/*     */     }
/*     */     
/* 137 */     if (!isOn)
/*     */     {
/* 139 */       String traceEn = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public String run() {
/* 142 */           return System.getProperty("traceEnabled");
/*     */         }
/*     */         
/* 145 */       });
/* 146 */       isOn = traceEn != null ? traceEn.trim().equalsIgnoreCase("true") : false;
/*     */       
/* 148 */       if (isOn) {
/* 149 */         com.ibm.msg.client.commonservices.trace.Trace.setOn(true);
/*     */       }
/*     */     }
/*     */     
/* 153 */     if (isOn)
/*     */     {
/* 155 */       String traceLvl = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public String run() {
/* 158 */           return System.getProperty("traceLevel");
/*     */         }
/*     */       });
/*     */       
/* 162 */       if (traceLvl != null) {
/*     */         try {
/* 164 */           setTraceLevel(Integer.parseInt(traceLvl));
/*     */         }
/*     */         catch (NumberFormatException nfe) {
/* 167 */           HashMap<String, String> inserts = new HashMap();
/* 168 */           inserts.put("JCA_CONFIG_PROPERTY", "traceLevel");
/* 169 */           inserts.put("JCA_CONFIG_VALUE", traceLvl);
/* 170 */           inserts.put("JCA_CONFIG_DEFAULT", Integer.toString(traceLevel));
/*     */           
/* 172 */           JCAMessageBuilder.buildWarning("MQJCA4006", inserts);
/*     */         }
/*     */       }
/*     */       
/* 176 */       String enable = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public String run() {
/* 179 */           return System.getProperty("logWriterEnabled");
/*     */         }
/*     */       });
/*     */       
/*     */ 
/* 184 */       if ((enable != null) && (!enable.equalsIgnoreCase("true"))) {
/* 185 */         disableLogWriter();
/*     */       }
/*     */       else {
/* 188 */         enableLogWriter();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void setTraceLevel(int level)
/*     */   {
/* 211 */     com.ibm.msg.client.commonservices.trace.Trace.setTraceLevel(level);
/*     */     
/* 213 */     traceLevel = level;
/*     */     
/* 215 */     enableTrace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized int getTraceLevel()
/*     */   {
/* 226 */     return traceLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void enableTrace()
/*     */   {
/* 234 */     if (!isOn) {
/* 235 */       isOn = true;
/* 236 */       com.ibm.msg.client.services.Trace.setStatus(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void enableTrace(int level)
/*     */   {
/* 247 */     if (!isOn) {
/* 248 */       enableTrace();
/* 249 */       traceLevel = level;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static synchronized void disableTrace()
/*     */   {
/* 257 */     isOn = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEnabled()
/*     */   {
/* 266 */     return isOn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static synchronized void enableLogWriter()
/*     */   {
/* 273 */     logWriterEnabled = true;
/* 274 */     originalLogSetting = Log.getOn();
/* 275 */     Log.setOn(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static synchronized void disableLogWriter()
/*     */   {
/* 282 */     logWriterEnabled = false;
/* 283 */     Log.setOn(originalLogSetting);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isLogWriterEnabled()
/*     */   {
/* 292 */     return logWriterEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceException(Object o, String clName, String method, Throwable t)
/*     */   {
/* 308 */     if ((isOn) && (traceLevel >= 1)) {
/* 309 */       com.ibm.msg.client.commonservices.trace.Trace.catchBlock(o, clName, method, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static synchronized void traceWarning(Object o, String clName, String method, String msg)
/*     */   {
/* 324 */     if ((isOn) && (traceLevel >= 3)) {
/* 325 */       com.ibm.msg.client.commonservices.trace.Trace.traceWarning(o, clName, method, msg, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static synchronized void traceWarning(Object o, String clName, String method, String msg, Throwable t)
/*     */   {
/* 342 */     if ((isOn) && (traceLevel >= 3)) {
/* 343 */       com.ibm.msg.client.commonservices.trace.Trace.traceWarning(o, clName, method, msg, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceNonNLSWarning(Object o, String clName, String method, String msg, Throwable t)
/*     */   {
/* 362 */     if ((isOn) && (traceLevel >= 3)) {
/* 363 */       com.ibm.msg.client.commonservices.trace.Trace.traceWarning(o, clName, method, msg, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void ffst(Object o, String clName, String method, HashMap<String, ? extends Object> map)
/*     */   {
/* 377 */     com.ibm.msg.client.commonservices.trace.Trace.ffst(o, clName, method, map, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceInfo(Object obj, String clName, String methodName, String info)
/*     */   {
/* 392 */     if ((isOn) && (traceLevel >= 6))
/*     */     {
/* 394 */       com.ibm.msg.client.commonservices.trace.Trace.traceInfo(obj, clName, methodName, null, info);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceEntry(Object obj, String className, String methodName)
/*     */   {
/* 406 */     if ((isOn) && (traceLevel >= 8)) {
/* 407 */       com.ibm.msg.client.commonservices.trace.Trace.entry(obj, className, methodName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceEntry(Object obj, String className, String methodName, Object[] params)
/*     */   {
/* 420 */     if ((isOn) && (traceLevel >= 8)) {
/* 421 */       com.ibm.msg.client.commonservices.trace.Trace.entry(obj, className, methodName, params);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceExit(Object obj, String className, String methodName)
/*     */   {
/* 433 */     if ((isOn) && (traceLevel >= 8)) {
/* 434 */       com.ibm.msg.client.commonservices.trace.Trace.exit(obj, className, methodName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceExit(Object obj, String className, String methodName, Object returnValue)
/*     */   {
/* 447 */     if ((isOn) && (traceLevel >= 8)) {
/* 448 */       com.ibm.msg.client.commonservices.trace.Trace.exit(obj, className, methodName, returnValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void traceData(Object obj, String className, String methodName, String msg, Object o)
/*     */   {
/* 463 */     if ((isOn) && (traceLevel >= 9)) {
/* 464 */       com.ibm.msg.client.commonservices.trace.Trace.data(obj, className, methodName, msg, o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static synchronized Trace.TraceHandler getTraceHandler()
/*     */   {
/* 476 */     if (traceHandler == null) {
/* 477 */       traceHandler = new Trace.TraceHandler()
/*     */       {
/*     */         public void setOn(boolean traceOn) {
/* 480 */           if (traceOn) {
/* 481 */             JCATraceAdapter.enableTrace(com.ibm.msg.client.commonservices.trace.Trace.getTraceLevel());
/*     */           } else {
/* 483 */             JCATraceAdapter.disableTrace();
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 489 */     return traceHandler;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/services/JCATraceAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */