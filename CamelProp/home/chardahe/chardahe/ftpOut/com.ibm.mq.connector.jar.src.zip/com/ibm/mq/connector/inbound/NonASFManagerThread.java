/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonASFManagerThread
/*     */   implements Runnable
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/NonASFManagerThread.java";
/*  53 */   private volatile boolean running = true;
/*     */   
/*  55 */   private MessageEndpointDeployment theDeployment = null;
/*     */   
/*  57 */   private Set<NonASFWorkImpl> stoppedWorkImpls = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonASFManagerThread(MessageEndpointDeployment med)
/*     */   {
/*  67 */     this.theDeployment = med;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerRejected(NonASFWorkImpl w)
/*     */   {
/*  76 */     synchronized (this.stoppedWorkImpls) {
/*  77 */       if (this.running) {
/*  78 */         if (this.stoppedWorkImpls.contains(w))
/*     */         {
/*  80 */           if (JCATraceAdapter.isOn) {
/*  81 */             JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "registerRejected", "ignoring duplicate NonASFWorkImpl: " + w);
/*     */           }
/*     */         }
/*     */         else {
/*  85 */           if (JCATraceAdapter.isOn) {
/*  86 */             JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "registerRejected", "registering NonASFWorkImpl: " + w);
/*     */           }
/*     */           
/*  89 */           this.stoppedWorkImpls.add(w);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 101 */     JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "run()", "non-ASF manager thread running");
/*     */     do
/*     */     {
/*     */       try
/*     */       {
/* 106 */         Thread.sleep(60000L);
/*     */       }
/*     */       catch (InterruptedException ie) {
/* 109 */         JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "run()", "interrupted");
/*     */       }
/*     */       
/*     */ 
/* 113 */       synchronized (this.stoppedWorkImpls)
/*     */       {
/* 115 */         if (this.stoppedWorkImpls.size() != 0) {
/* 116 */           for (NonASFWorkImpl w : this.stoppedWorkImpls)
/*     */           {
/* 118 */             if (JCATraceAdapter.isOn) {
/* 119 */               JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "run()", "resubmitting: " + w);
/*     */             }
/*     */             
/* 122 */             this.theDeployment.submitWork(w);
/*     */           }
/*     */           
/* 125 */           this.stoppedWorkImpls.clear();
/*     */ 
/*     */         }
/* 128 */         else if (JCATraceAdapter.isOn) {
/* 129 */           JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "run()", "no stopped NonASFWorkImpl objects to restart");
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 134 */     } while (this.running);
/*     */     
/* 136 */     JCATraceAdapter.traceInfo(this, "NonASFManagerThread", "run()", "non-ASF manager thread halting");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 143 */     this.running = false;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/NonASFManagerThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */