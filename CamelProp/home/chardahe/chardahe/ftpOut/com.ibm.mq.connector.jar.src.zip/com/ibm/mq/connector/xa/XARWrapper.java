/*     */ package com.ibm.mq.connector.xa;
/*     */ 
/*     */ import com.ibm.mq.connector.inbound.AbstractWorkImpl;
/*     */ import com.ibm.mq.connector.inbound.ConnectionHandler;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.jms.MQConnectionFactory.ConnectionFactoryProperty;
/*     */ import com.ibm.mq.jms.MQXAConnectionFactory;
/*     */ import com.ibm.msg.client.jms.JmsPropertyContext;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.XAConnection;
/*     */ import javax.jms.XASession;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XARWrapper
/*     */   extends XAObservable
/*     */   implements XAResource, Serializable
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/xa/XARWrapper.java";
/*     */   private static final long serialVersionUID = -4601034762854051073L;
/*  80 */   private transient XAResource theXAR = null;
/*     */   
/*     */ 
/*  83 */   private boolean rollbackOnly = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private MQXAConnectionFactory recoveryConnectionFactory = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private transient XAConnection recoveryConnection = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XARWrapper(AbstractWorkImpl wi)
/*     */   {
/* 104 */     if (JCATraceAdapter.isOn) {
/* 105 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "<init>");
/*     */       
/* 107 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "<init>", "owning WorkImpl: " + wi);
/*     */     }
/*     */     
/* 110 */     addXAObserver(wi);
/*     */     
/*     */ 
/* 113 */     if (JCATraceAdapter.isOn) {
/* 114 */       JCATraceAdapter.traceExit(this, "XARWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XARWrapper(XAResource xar, Session session)
/*     */   {
/* 126 */     if (JCATraceAdapter.isOn) {
/* 127 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "<init>");
/*     */       
/* 129 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "<init>", "wrapping XAR: " + xar);
/*     */     }
/*     */     
/* 132 */     this.theXAR = xar;
/*     */     
/* 134 */     setConnectionInformation(session);
/*     */     
/*     */ 
/* 137 */     if (JCATraceAdapter.isOn) {
/* 138 */       JCATraceAdapter.traceExit(this, "XARWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXAResource(XAResource xares, Session session)
/*     */   {
/* 150 */     if (JCATraceAdapter.isOn) {
/* 151 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "setXAResource()");
/*     */       
/* 153 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "setXAResource()", "wrapping XAR: " + xares);
/*     */     }
/* 155 */     this.theXAR = xares;
/*     */     
/* 157 */     setConnectionInformation(session);
/*     */     
/* 159 */     if (JCATraceAdapter.isOn) {
/* 160 */       JCATraceAdapter.traceExit(this, "XARWrapper", "setXAResource()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void commit(Xid xid, boolean onePhase)
/*     */     throws XAException
/*     */   {
/* 169 */     if (JCATraceAdapter.isOn) {
/* 170 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "commit()");
/*     */     }
/*     */     try
/*     */     {
/* 174 */       if ((this.rollbackOnly) && (onePhase)) {
/* 175 */         if (JCATraceAdapter.isOn) {
/* 176 */           JCATraceAdapter.traceInfo(this, "XARWrapper", "commit()", "Xid: " + xid + " forcing rollback");
/*     */         }
/*     */         
/*     */ 
/* 180 */         rollback(xid);
/*     */         
/* 182 */         this.rollbackOnly = false;
/* 183 */         throw new XAException(100);
/*     */       }
/* 185 */       if ((this.rollbackOnly) && (!onePhase))
/*     */       {
/* 187 */         HashMap<String, Xid> data = new HashMap();
/* 188 */         data.put("xid", xid);
/* 189 */         JCATraceAdapter.ffst(this, "XARWrapper", "JCA02005", data);
/*     */         
/* 191 */         throw new XAException(-7);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 196 */         if (JCATraceAdapter.isOn) {
/* 197 */           JCATraceAdapter.traceInfo(this, "XARWrapper", "commit()", "Xid: " + xid + ", onePhase: " + onePhase);
/*     */         }
/*     */         
/* 200 */         this.theXAR.commit(xid, onePhase);
/* 201 */         update(1);
/*     */       }
/*     */       catch (XAException xe) {
/* 204 */         if (xe.errorCode == 7)
/*     */         {
/*     */ 
/*     */ 
/* 208 */           JCAMessageBuilder.buildWarning("MQJCA4027", null);
/*     */         }
/*     */         
/* 211 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "commit()", "commit failed with: " + xe.errorCode);
/*     */         
/* 213 */         JCATraceAdapter.traceException(this, "XARWrapper", "commit()", xe);
/* 214 */         update(8);
/* 215 */         throw xe;
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 222 */       if (this.recoveryConnection != null) {
/* 223 */         ConnectionHandler.getInstance().destroyConnection(this.recoveryConnection);
/*     */       }
/*     */       
/* 226 */       if (JCATraceAdapter.isOn) {
/* 227 */         JCATraceAdapter.traceExit(this, "XARWrapper", "commit()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void end(Xid xid, int flags)
/*     */     throws XAException
/*     */   {
/* 237 */     if (JCATraceAdapter.isOn) {
/* 238 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "end()");
/*     */     }
/*     */     try
/*     */     {
/* 242 */       if (JCATraceAdapter.isOn) {
/* 243 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "end()", "Xid: " + xid + ", flags: " + parseFlags(flags));
/*     */       }
/*     */       
/* 246 */       this.theXAR.end(xid, flags);
/* 247 */       update(2);
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 251 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "end()", "end failed with: " + xe.errorCode);
/* 252 */       update(8);
/*     */       
/* 254 */       if (xe.errorCode != 100)
/*     */       {
/* 256 */         JCATraceAdapter.traceException(this, "XARWrapper", "end()", xe);
/* 257 */         throw xe;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 262 */       HashMap<String, String> inserts = new HashMap();
/* 263 */       inserts.put("JCA_XA_EXCEPTION", xe.getMessage());
/* 264 */       JCAMessageBuilder.buildWarning("MQJCA4026", inserts);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 269 */       if (JCATraceAdapter.isOn) {
/* 270 */         JCATraceAdapter.traceExit(this, "XARWrapper", "end()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void forget(Xid xid)
/*     */     throws XAException
/*     */   {
/* 280 */     if (JCATraceAdapter.isOn) {
/* 281 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "forget()");
/*     */     }
/*     */     try
/*     */     {
/* 285 */       if (JCATraceAdapter.isOn) {
/* 286 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "forget()", "Xid: " + xid);
/*     */       }
/* 288 */       this.theXAR.forget(xid);
/* 289 */       update(3);
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 293 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "forget()", "forget failed with: " + xe.errorCode);
/*     */       
/* 295 */       JCATraceAdapter.traceException(this, "XARWrapper", "forget()", xe);
/* 296 */       update(8);
/* 297 */       throw xe;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 302 */       if (this.recoveryConnection != null) {
/* 303 */         ConnectionHandler.getInstance().destroyConnection(this.recoveryConnection);
/*     */       }
/*     */       
/* 306 */       if (JCATraceAdapter.isOn) {
/* 307 */         JCATraceAdapter.traceExit(this, "XARWrapper", "forget()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTransactionTimeout()
/*     */     throws XAException
/*     */   {
/* 317 */     JCATraceAdapter.traceEntry(this, "XARWrapper", "getTransactionTimeout()");
/*     */     try
/*     */     {
/* 320 */       int t = this.theXAR.getTransactionTimeout();
/* 321 */       if (JCATraceAdapter.isOn) {
/* 322 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "getTransactionTimeout()", "transaction timeout: " + t);
/*     */       }
/*     */       
/* 325 */       return t;
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 329 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "getTransactionTimeout()", "getTransactionTimeout failed with: " + xe.errorCode);
/*     */       
/* 331 */       JCATraceAdapter.traceException(this, "XARWrapper", "getTransactionTimeout()", xe);
/* 332 */       update(8);
/* 333 */       throw xe;
/*     */     }
/*     */     finally
/*     */     {
/* 337 */       JCATraceAdapter.traceExit(this, "XARWrapper", "getTransactionTimeout()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isSameRM(XAResource xares)
/*     */     throws XAException
/*     */   {
/* 346 */     JCATraceAdapter.traceEntry(this, "XARWrapper", "isSameRM()");
/*     */     try
/*     */     {
/* 349 */       return false;
/*     */     }
/*     */     finally {
/* 352 */       JCATraceAdapter.traceExit(this, "XARWrapper", "isSameRM()");
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int prepare(Xid xid)
/*     */     throws XAException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 6	com/ibm/mq/connector/services/JCATraceAdapter:isOn	Z
/*     */     //   3: ifeq +11 -> 14
/*     */     //   6: aload_0
/*     */     //   7: ldc 7
/*     */     //   9: ldc 62
/*     */     //   11: invokestatic 9	com/ibm/mq/connector/services/JCATraceAdapter:traceEntry	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   14: aload_0
/*     */     //   15: getfield 3	com/ibm/mq/connector/xa/XARWrapper:rollbackOnly	Z
/*     */     //   18: ifeq +152 -> 170
/*     */     //   21: getstatic 6	com/ibm/mq/connector/services/JCATraceAdapter:isOn	Z
/*     */     //   24: ifeq +35 -> 59
/*     */     //   27: aload_0
/*     */     //   28: ldc 7
/*     */     //   30: ldc 62
/*     */     //   32: new 10	java/lang/StringBuilder
/*     */     //   35: dup
/*     */     //   36: invokespecial 11	java/lang/StringBuilder:<init>	()V
/*     */     //   39: ldc 23
/*     */     //   41: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   44: aload_1
/*     */     //   45: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   48: ldc 24
/*     */     //   50: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   53: invokevirtual 15	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   56: invokestatic 16	com/ibm/mq/connector/services/JCATraceAdapter:traceInfo	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   59: aload_0
/*     */     //   60: aload_1
/*     */     //   61: invokevirtual 25	com/ibm/mq/connector/xa/XARWrapper:rollback	(Ljavax/transaction/xa/Xid;)V
/*     */     //   64: new 26	javax/transaction/xa/XAException
/*     */     //   67: dup
/*     */     //   68: bipush 100
/*     */     //   70: invokespecial 27	javax/transaction/xa/XAException:<init>	(I)V
/*     */     //   73: astore_2
/*     */     //   74: aload_0
/*     */     //   75: iconst_0
/*     */     //   76: putfield 3	com/ibm/mq/connector/xa/XARWrapper:rollbackOnly	Z
/*     */     //   79: goto +80 -> 159
/*     */     //   82: astore_3
/*     */     //   83: aload_3
/*     */     //   84: getfield 38	javax/transaction/xa/XAException:errorCode	I
/*     */     //   87: tableswitch	default:+70->157, 5:+29->116, 6:+29->116, 7:+29->116, 8:+29->116
/*     */     //   116: new 28	java/util/HashMap
/*     */     //   119: dup
/*     */     //   120: invokespecial 29	java/util/HashMap:<init>	()V
/*     */     //   123: astore 4
/*     */     //   125: aload 4
/*     */     //   127: ldc 63
/*     */     //   129: aload_3
/*     */     //   130: invokevirtual 31	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   133: pop
/*     */     //   134: aload_0
/*     */     //   135: ldc 7
/*     */     //   137: ldc 64
/*     */     //   139: aload 4
/*     */     //   141: invokestatic 33	com/ibm/mq/connector/services/JCATraceAdapter:ffst	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V
/*     */     //   144: new 26	javax/transaction/xa/XAException
/*     */     //   147: dup
/*     */     //   148: bipush -7
/*     */     //   150: invokespecial 27	javax/transaction/xa/XAException:<init>	(I)V
/*     */     //   153: astore_2
/*     */     //   154: goto +5 -> 159
/*     */     //   157: aload_3
/*     */     //   158: astore_2
/*     */     //   159: aload_0
/*     */     //   160: ldc 7
/*     */     //   162: ldc 62
/*     */     //   164: aload_2
/*     */     //   165: invokestatic 43	com/ibm/mq/connector/services/JCATraceAdapter:traceException	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   168: aload_2
/*     */     //   169: athrow
/*     */     //   170: aload_0
/*     */     //   171: getfield 2	com/ibm/mq/connector/xa/XARWrapper:theXAR	Ljavax/transaction/xa/XAResource;
/*     */     //   174: aload_1
/*     */     //   175: invokeinterface 65 2 0
/*     */     //   180: istore_2
/*     */     //   181: getstatic 6	com/ibm/mq/connector/services/JCATraceAdapter:isOn	Z
/*     */     //   184: ifeq +43 -> 227
/*     */     //   187: aload_0
/*     */     //   188: ldc 7
/*     */     //   190: ldc 62
/*     */     //   192: new 10	java/lang/StringBuilder
/*     */     //   195: dup
/*     */     //   196: invokespecial 11	java/lang/StringBuilder:<init>	()V
/*     */     //   199: ldc 23
/*     */     //   201: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   204: aload_1
/*     */     //   205: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   208: ldc 66
/*     */     //   210: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   213: aload_0
/*     */     //   214: iload_2
/*     */     //   215: invokevirtual 67	com/ibm/mq/connector/xa/XARWrapper:parseResult	(I)Ljava/lang/String;
/*     */     //   218: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   221: invokevirtual 15	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   224: invokestatic 16	com/ibm/mq/connector/services/JCATraceAdapter:traceInfo	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   227: aload_0
/*     */     //   228: iconst_4
/*     */     //   229: invokevirtual 37	com/ibm/mq/connector/xa/XARWrapper:update	(I)V
/*     */     //   232: iload_2
/*     */     //   233: istore_3
/*     */     //   234: getstatic 6	com/ibm/mq/connector/services/JCATraceAdapter:isOn	Z
/*     */     //   237: ifeq +11 -> 248
/*     */     //   240: aload_0
/*     */     //   241: ldc 7
/*     */     //   243: ldc 62
/*     */     //   245: invokestatic 18	com/ibm/mq/connector/services/JCATraceAdapter:traceExit	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   248: iload_3
/*     */     //   249: ireturn
/*     */     //   250: astore_2
/*     */     //   251: aload_0
/*     */     //   252: ldc 7
/*     */     //   254: ldc 62
/*     */     //   256: new 10	java/lang/StringBuilder
/*     */     //   259: dup
/*     */     //   260: invokespecial 11	java/lang/StringBuilder:<init>	()V
/*     */     //   263: aload_1
/*     */     //   264: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   267: ldc 68
/*     */     //   269: invokevirtual 13	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   272: aload_2
/*     */     //   273: getfield 38	javax/transaction/xa/XAException:errorCode	I
/*     */     //   276: invokevirtual 42	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   279: invokevirtual 15	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   282: invokestatic 16	com/ibm/mq/connector/services/JCATraceAdapter:traceInfo	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   285: aload_0
/*     */     //   286: ldc 7
/*     */     //   288: ldc 62
/*     */     //   290: aload_2
/*     */     //   291: invokestatic 43	com/ibm/mq/connector/services/JCATraceAdapter:traceException	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   294: aload_0
/*     */     //   295: bipush 8
/*     */     //   297: invokevirtual 37	com/ibm/mq/connector/xa/XARWrapper:update	(I)V
/*     */     //   300: aload_2
/*     */     //   301: athrow
/*     */     //   302: astore 5
/*     */     //   304: getstatic 6	com/ibm/mq/connector/services/JCATraceAdapter:isOn	Z
/*     */     //   307: ifeq +11 -> 318
/*     */     //   310: aload_0
/*     */     //   311: ldc 7
/*     */     //   313: ldc 62
/*     */     //   315: invokestatic 18	com/ibm/mq/connector/services/JCATraceAdapter:traceExit	(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   318: aload 5
/*     */     //   320: athrow
/*     */     // Line number table:
/*     */     //   Java source line #378	-> byte code offset #0
/*     */     //   Java source line #379	-> byte code offset #6
/*     */     //   Java source line #383	-> byte code offset #14
/*     */     //   Java source line #384	-> byte code offset #21
/*     */     //   Java source line #385	-> byte code offset #27
/*     */     //   Java source line #391	-> byte code offset #59
/*     */     //   Java source line #392	-> byte code offset #64
/*     */     //   Java source line #395	-> byte code offset #74
/*     */     //   Java source line #419	-> byte code offset #79
/*     */     //   Java source line #397	-> byte code offset #82
/*     */     //   Java source line #402	-> byte code offset #83
/*     */     //   Java source line #408	-> byte code offset #116
/*     */     //   Java source line #409	-> byte code offset #125
/*     */     //   Java source line #410	-> byte code offset #134
/*     */     //   Java source line #412	-> byte code offset #144
/*     */     //   Java source line #413	-> byte code offset #154
/*     */     //   Java source line #415	-> byte code offset #157
/*     */     //   Java source line #421	-> byte code offset #159
/*     */     //   Java source line #422	-> byte code offset #168
/*     */     //   Java source line #427	-> byte code offset #170
/*     */     //   Java source line #428	-> byte code offset #181
/*     */     //   Java source line #429	-> byte code offset #187
/*     */     //   Java source line #432	-> byte code offset #227
/*     */     //   Java source line #433	-> byte code offset #232
/*     */     //   Java source line #447	-> byte code offset #234
/*     */     //   Java source line #448	-> byte code offset #240
/*     */     //   Java source line #450	-> byte code offset #248
/*     */     //   Java source line #435	-> byte code offset #250
/*     */     //   Java source line #437	-> byte code offset #251
/*     */     //   Java source line #439	-> byte code offset #285
/*     */     //   Java source line #440	-> byte code offset #294
/*     */     //   Java source line #441	-> byte code offset #300
/*     */     //   Java source line #447	-> byte code offset #302
/*     */     //   Java source line #448	-> byte code offset #310
/*     */     //   Java source line #450	-> byte code offset #318
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	321	0	this	XARWrapper
/*     */     //   0	321	1	xid	Xid
/*     */     //   73	96	2	toThrow	XAException
/*     */     //   180	53	2	i	int
/*     */     //   250	51	2	xe	XAException
/*     */     //   82	167	3	e	XAException
/*     */     //   123	17	4	data	HashMap<String, XAException>
/*     */     //   302	17	5	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   59	79	82	javax/transaction/xa/XAException
/*     */     //   170	234	250	javax/transaction/xa/XAException
/*     */     //   14	234	302	finally
/*     */     //   250	304	302	finally
/*     */   }
/*     */   
/*     */   public Xid[] recover(int flag)
/*     */     throws XAException
/*     */   {
/* 458 */     JCATraceAdapter.traceEntry(this, "XARWrapper", "recover()");
/*     */     try
/*     */     {
/* 461 */       Xid[] res = this.theXAR.recover(flag);
/* 462 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "recover()", "flag: " + parseFlags(flag) + ", size: " + (res != null ? res.length : -1));
/*     */       
/* 464 */       update(5);
/* 465 */       return res;
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 469 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "recover()", "recover with " + parseFlags(flag) + " failed with: " + xe.errorCode);
/*     */       
/* 471 */       JCATraceAdapter.traceException(this, "XARWrapper", "recover()", xe);
/* 472 */       update(8);
/* 473 */       throw xe;
/*     */     }
/*     */     finally
/*     */     {
/* 477 */       JCATraceAdapter.traceExit(this, "XARWrapper", "recover()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rollback(Xid xid)
/*     */     throws XAException
/*     */   {
/* 486 */     if (JCATraceAdapter.isOn) {
/* 487 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "rollback()");
/*     */     }
/*     */     try
/*     */     {
/* 491 */       if (JCATraceAdapter.isOn) {
/* 492 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "rollback()", "Xid: " + xid);
/*     */       }
/* 494 */       this.theXAR.rollback(xid);
/* 495 */       update(6);
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 499 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "rollback()", "rollback failed with: " + xe.errorCode);
/*     */       
/* 501 */       update(8);
/*     */       
/* 503 */       if (xe.errorCode != 100)
/*     */       {
/* 505 */         JCATraceAdapter.traceException(this, "XARWrapper", "rollback()", xe);
/* 506 */         throw xe;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 511 */       HashMap<String, String> inserts = new HashMap();
/* 512 */       inserts.put("JCA_XA_EXCEPTION", xe.getMessage());
/* 513 */       JCAMessageBuilder.buildWarning("MQJCA4026", inserts);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 519 */       if (this.recoveryConnection != null) {
/* 520 */         ConnectionHandler.getInstance().destroyConnection(this.recoveryConnection);
/*     */       }
/*     */       
/* 523 */       if (JCATraceAdapter.isOn) {
/* 524 */         JCATraceAdapter.traceExit(this, "XARWrapper", "rollback()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean setTransactionTimeout(int seconds)
/*     */     throws XAException
/*     */   {
/* 534 */     JCATraceAdapter.traceEntry(this, "XARWrapper", "setTransactionTimeout()");
/*     */     try
/*     */     {
/* 537 */       boolean set = this.theXAR.setTransactionTimeout(seconds);
/* 538 */       if (JCATraceAdapter.isOn) {
/* 539 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "setTransactionTimeout()", "timeout: " + seconds + ", result: " + set);
/*     */       }
/*     */       
/* 542 */       return set;
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 546 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "setTransactionTimeout()", "setTransactionTimeout " + seconds + " failed with: " + xe.errorCode);
/*     */       
/* 548 */       JCATraceAdapter.traceException(this, "XARWrapper", "setTransactionTimeout()", xe);
/* 549 */       update(8);
/* 550 */       throw xe;
/*     */     }
/*     */     finally
/*     */     {
/* 554 */       JCATraceAdapter.traceExit(this, "XARWrapper", "setTransactionTimeout()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void start(Xid xid, int flags)
/*     */     throws XAException
/*     */   {
/* 563 */     if (JCATraceAdapter.isOn) {
/* 564 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "start()");
/*     */     }
/*     */     try
/*     */     {
/* 568 */       if (JCATraceAdapter.isOn) {
/* 569 */         JCATraceAdapter.traceInfo(this, "XARWrapper", "start()", "Xid: " + xid + ", flags: " + parseFlags(flags));
/*     */       }
/*     */       
/* 572 */       this.theXAR.start(xid, flags);
/* 573 */       update(7);
/*     */     }
/*     */     catch (XAException xe)
/*     */     {
/* 577 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "start()", "start failed with: " + xe.errorCode);
/*     */       
/* 579 */       JCATraceAdapter.traceException(this, "XARWrapper", "start()", xe);
/* 580 */       update(8);
/* 581 */       throw xe;
/*     */     }
/*     */     finally
/*     */     {
/* 585 */       if (JCATraceAdapter.isOn) {
/* 586 */         JCATraceAdapter.traceExit(this, "XARWrapper", "start()");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecoveryConnection(XAConnection conn)
/*     */   {
/* 599 */     this.recoveryConnection = conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRollbackOnly()
/*     */   {
/* 608 */     this.rollbackOnly = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRollbackOnly()
/*     */   {
/* 617 */     return this.rollbackOnly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseFlags(int flags)
/*     */   {
/* 628 */     String s = null;
/* 629 */     switch (flags) {
/*     */     case 0: 
/* 631 */       s = "TMNOFLAGS";
/* 632 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 1048576: 
/* 637 */       s = "TMMIGRATE";
/* 638 */       break;
/*     */     
/*     */     case 4194304: 
/* 641 */       s = "TMMULTIPLE";
/* 642 */       break;
/*     */     
/*     */     case 268435456: 
/* 645 */       s = "TMNOWAIT";
/* 646 */       break;
/*     */     
/*     */     case -2147483648: 
/* 649 */       s = "TMASYNC";
/* 650 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 25165824: 
/* 655 */       s = "TMSTARTRSCAN + TMENDRSCAN";
/* 656 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 1073741824: 
/* 661 */       s = "TMONEPHASE";
/* 662 */       break;
/*     */     
/*     */     case 536870912: 
/* 665 */       s = "TMFAIL";
/* 666 */       break;
/*     */     
/*     */     case 134217728: 
/* 669 */       s = "TMRESUME";
/* 670 */       break;
/*     */     
/*     */     case 67108864: 
/* 673 */       s = "TMSUCCESS";
/* 674 */       break;
/*     */     
/*     */     case 33554432: 
/* 677 */       s = "TMSUSPEND";
/* 678 */       break;
/*     */     
/*     */     case 16777216: 
/* 681 */       s = "TMSTARTRSCAN";
/* 682 */       break;
/*     */     
/*     */     case 8388608: 
/* 685 */       s = "TMENDRSCAN";
/* 686 */       break;
/*     */     
/*     */     case 2097152: 
/* 689 */       s = "TMJOIN";
/* 690 */       break;
/*     */     
/*     */ 
/*     */     default: 
/* 694 */       s = "unknown flag: " + flags;
/*     */     }
/* 696 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String parseResult(int res)
/*     */   {
/* 706 */     if (res == 0) {
/* 707 */       return "XA_OK";
/*     */     }
/* 709 */     if (res == 3) {
/* 710 */       return "XA_RDONLY";
/*     */     }
/*     */     
/* 713 */     return "unknown result: " + res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setConnectionInformation(Session session)
/*     */   {
/* 726 */     if (JCATraceAdapter.isOn) {
/* 727 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "setConnectionInformation()");
/*     */     }
/*     */     try
/*     */     {
/* 731 */       Map propsFromSession = (Map)session;
/*     */       
/* 733 */       this.recoveryConnectionFactory = new MQXAConnectionFactory();
/*     */       
/* 735 */       for (MQConnectionFactory.ConnectionFactoryProperty cfp : MQConnectionFactory.ConnectionFactoryProperty.values((short)4))
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/* 741 */           String key = cfp.getCanonicalKey();
/* 742 */           Object value = ((JmsPropertyContext)propsFromSession).getObjectProperty(key);
/* 743 */           if (null != value)
/*     */           {
/* 745 */             this.recoveryConnectionFactory.setObjectProperty(key, value);
/*     */           }
/*     */           
/*     */         }
/*     */         catch (JMSException jmse)
/*     */         {
/* 751 */           HashMap<String, Object> info = new HashMap();
/* 752 */           info.put("Exception", jmse);
/* 753 */           JCATraceAdapter.ffst(null, "XARWrapper", "????????", info);
/*     */         }
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 759 */           String connNameList = ((JmsPropertyContext)propsFromSession).getStringProperty("XMSC_WMQ_CONNECTION_NAME_LIST_INT");
/* 760 */           if (null != connNameList)
/*     */           {
/* 762 */             this.recoveryConnectionFactory.setStringProperty("XMSC_WMQ_CONNECTION_NAME_LIST", connNameList);
/*     */           }
/*     */           
/*     */         }
/*     */         catch (JMSException jmse)
/*     */         {
/* 768 */           HashMap<String, Object> info = new HashMap();
/* 769 */           info.put("Exception", jmse);
/* 770 */           JCATraceAdapter.ffst(null, "XARWrapper", "????????", info);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (ClassCastException e)
/*     */     {
/* 777 */       HashMap<String, Object> info = new HashMap();
/* 778 */       info.put("Exception", e);
/* 779 */       JCATraceAdapter.ffst(null, "XARWrapper", "????????", info);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 784 */     if (JCATraceAdapter.isOn) {
/* 785 */       JCATraceAdapter.traceExit(this, "XARWrapper", "setConnectionInformation()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 799 */     if (JCATraceAdapter.isOn) {
/* 800 */       JCATraceAdapter.traceEntry(this, "XARWrapper", "readObject()");
/*     */     }
/*     */     
/* 803 */     in.defaultReadObject();
/*     */     
/*     */     try
/*     */     {
/* 807 */       setRecoveryConnection(this.recoveryConnectionFactory.createXAConnection());
/* 808 */       this.theXAR = this.recoveryConnection.createXASession().getXAResource();
/*     */ 
/*     */     }
/*     */     catch (JMSException jmse)
/*     */     {
/* 813 */       JCATraceAdapter.traceInfo(this, "XARWrapper", "readObject()", "RecoveryXAConnection createConnection failed with: " + jmse);
/*     */       
/* 815 */       JCATraceAdapter.traceException(this, "XARWrapper", "readObject()", jmse);
/* 816 */       IOException ioe = new IOException("Failed to connect to MQ for XARecovery: " + jmse);
/* 817 */       ioe.initCause(jmse);
/* 818 */       throw ioe;
/*     */     }
/*     */     
/*     */ 
/* 822 */     if (JCATraceAdapter.isOn) {
/* 823 */       JCATraceAdapter.traceExit(this, "XARWrapper", "readObject()");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/xa/XARWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */