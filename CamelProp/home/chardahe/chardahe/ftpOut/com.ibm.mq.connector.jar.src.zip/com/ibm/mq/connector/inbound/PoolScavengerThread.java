/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolScavengerThread
/*     */   extends Thread
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/PoolScavengerThread.java";
/*     */   private static final int SCAN_INTERVAL = 300000;
/*  63 */   private boolean started = true;
/*     */   
/*     */ 
/*  66 */   private List pools = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public PoolScavengerThread()
/*     */   {
/*  72 */     this.pools = new ArrayList();
/*  73 */     JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "<init>", "scavenger thread initialized");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*  82 */     JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "run()", "scavenger thread running, priority: " + getPriority());
/*     */     
/*     */ 
/*     */ 
/*  86 */     while (this.started)
/*     */     {
/*     */       try {
/*  89 */         sleep(300000L);
/*     */       }
/*     */       catch (InterruptedException ie)
/*     */       {
/*  93 */         JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "run()", "scavenger thread interrupted");
/*     */       }
/*     */       
/*     */ 
/*  97 */       JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "run()", "scavenger thread awake, triggering cleanup");
/*     */       
/*     */       try
/*     */       {
/* 101 */         Iterator i = this.pools.iterator();
/* 102 */         while (i.hasNext()) {
/* 103 */           ServerSessionPoolImpl p = (ServerSessionPoolImpl)i.next();
/*     */           
/* 105 */           if ((p.getIdleTimeout() > 0) && (p.getCurrentPoolDepth() > 0)) {
/* 106 */             p.poolCleanup();
/*     */           }
/*     */         }
/*     */         
/* 110 */         JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "run()", "cleanup complete, sleeping");
/*     */ 
/*     */       }
/*     */       catch (RuntimeException re)
/*     */       {
/*     */ 
/* 116 */         JCAMessageBuilder.buildWarning("MQJCA4015");
/* 117 */         JCATraceAdapter.traceException(this, "PoolScavengerThread", "run()", re);
/* 118 */         this.started = false;
/*     */       }
/*     */     }
/*     */     
/* 122 */     JCATraceAdapter.traceInfo(this, "PoolScavengerThread", "run()", "scavenger thread run() exiting");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addServerSessionPool(ServerSessionPoolImpl p)
/*     */   {
/* 133 */     if ((p != null) && (!this.pools.contains(p))) {
/* 134 */       this.pools.add(p);
/*     */     }
/*     */     else
/*     */     {
/* 138 */       HashMap info = new HashMap();
/* 139 */       info.put("null/duplicate ServerSessionPoolImpl", p != null ? Integer.toString(System.identityHashCode(p)) : "null");
/*     */       
/* 141 */       JCATraceAdapter.ffst(this, "PoolScavengerThread", "JCA02004", info);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeServerSessionPool(ServerSessionPoolImpl p)
/*     */   {
/* 152 */     if ((p != null) && (this.pools.contains(p))) {
/* 153 */       this.pools.remove(p);
/*     */     }
/*     */     else
/*     */     {
/* 157 */       HashMap info = new HashMap();
/* 158 */       info.put("null/unknown ServerSessionPoolImpl", p != null ? Integer.toString(System.identityHashCode(p)) : "null");
/*     */       
/* 160 */       JCATraceAdapter.ffst(this, "PoolScavengerThread", "JCA02005", info);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/PoolScavengerThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */