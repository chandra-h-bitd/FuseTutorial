/*     */ package com.ibm.mq.connector.inbound;
/*     */ 
/*     */ import com.ibm.mq.connector.JCARuntimeHelper;
/*     */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.mq.connector.xa.DummyXAResourceImpl;
/*     */ import com.ibm.mq.connector.xa.XAObserver;
/*     */ import com.ibm.mq.connector.xa.XARWrapper;
/*     */ import com.ibm.mq.jms.MQXASession;
/*     */ import com.ibm.msg.client.jms.JmsSession;
/*     */ import java.util.HashMap;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TransactionRolledBackException;
/*     */ import javax.jms.XASession;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import javax.resource.spi.work.Work;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractWorkImpl
/*     */   implements Work, XAObserver
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/inbound/AbstractWorkImpl.java";
/*  87 */   protected Session theSession = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  92 */   protected MessageEndpointDeployment theDeployment = null;
/*     */   
/*     */ 
/*     */ 
/*     */   protected volatile Thread failingThread;
/*     */   
/*     */ 
/*     */ 
/* 100 */   private boolean failedLastTime = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private boolean exceptionThrown = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 113 */   private boolean rolledBack = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   private boolean beforeDeliveryFailed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 124 */   private final XARWrapper xarw = new XARWrapper(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doDelivery(MessageEndpoint paramMessageEndpoint)
/*     */     throws JMSException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void cleanupDelivery();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void run()
/*     */   {
/* 151 */     if (JCATraceAdapter.isOn) {
/* 152 */       JCATraceAdapter.traceEntry(this, "AbstractWorkImpl", "run()");
/*     */     }
/*     */     
/* 155 */     this.exceptionThrown = false;
/*     */     
/* 157 */     MessageEndpoint endpoint = null;
/*     */     
/* 159 */     boolean transacted = false;
/*     */     
/* 161 */     boolean useRRS = false;
/*     */     
/*     */ 
/*     */ 
/* 165 */     boolean transactionStarted = false;
/* 166 */     boolean sessionClosed = ((this.theSession instanceof MQXASession)) && (((MQXASession)this.theSession).isClosed());
/*     */     
/* 168 */     boolean doDeliveryCalled = false;
/*     */     
/* 170 */     if (!sessionClosed)
/*     */     {
/*     */       try
/*     */       {
/* 174 */         MessageEndpointFactory theEndpointFactory = this.theDeployment.getEndpointFactory();
/* 175 */         if (JCATraceAdapter.isOn) {
/* 176 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "resolving endpoint from factory: " + theEndpointFactory);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 181 */         XAResource xar = null;
/*     */         
/* 183 */         int env = ResourceAdapterImpl.getJCARuntimeHelper().getEnvironment();
/* 184 */         boolean zWAS = (env == 8) || (env == 16) || (env == 32) || (env == 184);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */         useRRS = (zWAS) && ((this.theSession instanceof JmsSession)) && (((JmsSession)this.theSession).getIntProperty("XMSC_WMQ_CONNECTION_MODE") == 0);
/* 191 */         if (useRRS)
/*     */         {
/* 193 */           xar = DummyXAResourceImpl.getInstance();
/*     */         }
/*     */         else
/*     */         {
/* 197 */           xar = (this.theSession instanceof XASession) ? ((XASession)this.theSession).getXAResource() : null;
/*     */         }
/*     */         
/* 200 */         if (JCATraceAdapter.isOn) {
/* 201 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "XAResource: " + xar);
/*     */         }
/*     */         
/* 204 */         if (xar != null) {
/* 205 */           this.xarw.setXAResource(xar, this.theSession);
/*     */         }
/*     */         
/*     */ 
/* 209 */         endpoint = theEndpointFactory.createEndpoint(xar != null ? this.xarw : null);
/*     */         
/*     */ 
/* 212 */         if (JCATraceAdapter.isOn) {
/* 213 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "calling beforeDelivery(...) on endpoint: " + endpoint + ", activationSpec: " + this.theDeployment.getActivationSpec());
/*     */         }
/*     */         
/*     */ 
/* 217 */         transacted = theEndpointFactory.isDeliveryTransacted(ResourceAdapterImpl.getOnMessageMethod());
/* 218 */         if (transacted) {
/* 219 */           this.beforeDeliveryFailed = true;
/* 220 */           endpoint.beforeDelivery(ResourceAdapterImpl.getOnMessageMethod());
/* 221 */           this.beforeDeliveryFailed = false;
/*     */           
/*     */ 
/* 224 */           if (useRRS) {
/* 225 */             ResourceAdapterImpl.getJCARuntimeHelper().startRRSTransaction();
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 230 */         else if (useRRS) {
/* 231 */           ResourceAdapterImpl.getJCARuntimeHelper().startLocalRRSTransaction();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 236 */         transactionStarted = (transacted) || (useRRS);
/*     */         
/*     */ 
/* 239 */         doDeliveryCalled = true;
/* 240 */         doDelivery(endpoint);
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */ 
/* 246 */         if (JCATraceAdapter.isOn) {
/* 247 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "setting RollbackOnly(true)");
/*     */         }
/*     */         
/* 250 */         if (this.xarw != null) {
/* 251 */           this.xarw.setRollbackOnly();
/*     */         }
/*     */         
/* 254 */         if (!doDeliveryCalled)
/*     */         {
/*     */ 
/* 257 */           cleanupDelivery();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 263 */         HashMap<String, Object> inserts = new HashMap();
/* 264 */         inserts.put("JCA_ENDPOINT", endpoint);
/* 265 */         inserts.put("JCA_JMS_EXCEPTION", e.getMessage());
/* 266 */         JCAMessageBuilder.buildWarning("MQJCA4004", inserts);
/*     */         
/* 268 */         JCATraceAdapter.traceException(this, "AbstractWorkImpl", "run()", e);
/*     */         
/* 270 */         JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Deciding whether to notify");
/*     */         
/*     */ 
/*     */ 
/* 274 */         boolean notifyHelper = true;
/*     */         
/* 276 */         if (!(e instanceof Exception)) {
/* 277 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Not an Exception - so not notifying");
/*     */           
/* 279 */           notifyHelper = false;
/*     */         }
/* 281 */         else if (endpoint == null)
/*     */         {
/*     */ 
/*     */ 
/* 285 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Endpoint is null - so not notifying");
/* 286 */           notifyHelper = false;
/*     */         }
/* 288 */         if (notifyHelper) {
/* 289 */           this.failingThread = Thread.currentThread();
/* 290 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Notifying the runtime helper");
/* 291 */           ResourceAdapterImpl.getJCARuntimeHelper().deliveryFailed((Exception)e, this.theDeployment.getActivationSpec(), this.theDeployment.getEndpointFactory(), isFailedLastTime());
/* 292 */           this.failingThread = null;
/*     */         }
/*     */         
/*     */ 
/* 296 */         JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Checking the chain of exceptions");
/* 297 */         boolean rmerrFound = false;
/* 298 */         for (Throwable exceptionToCheck = e; (!rmerrFound) && (exceptionToCheck != null); exceptionToCheck = exceptionToCheck.getCause()) {
/* 299 */           JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Checking exception " + exceptionToCheck.getClass().getName());
/* 300 */           if ((exceptionToCheck instanceof XAException)) {
/* 301 */             int errorCode = ((XAException)exceptionToCheck).errorCode;
/* 302 */             JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "Error code is " + errorCode);
/* 303 */             switch (errorCode)
/*     */             {
/*     */             case -7: 
/*     */             case -3: 
/* 307 */               rmerrFound = true;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 314 */         if ((rmerrFound) && ((e instanceof Exception))) {
/* 315 */           this.failingThread = Thread.currentThread();
/* 316 */           this.theDeployment.onException((Exception)e);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 321 */         this.exceptionThrown = true;
/* 322 */         setFailedLastTime(true);
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 328 */           if (JCATraceAdapter.isOn) {
/* 329 */             JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "calling afterDelivery()");
/*     */           }
/*     */           
/* 332 */           if (transactionStarted)
/*     */           {
/* 334 */             if (transacted)
/*     */             {
/* 336 */               endpoint.afterDelivery();
/*     */             }
/*     */             else {
/* 339 */               ResourceAdapterImpl.getJCARuntimeHelper().endLocalRRSTransaction();
/*     */             }
/*     */           }
/*     */           
/* 343 */           if (JCATraceAdapter.isOn) {
/* 344 */             JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "message delivery completed");
/*     */           }
/*     */         }
/*     */         catch (Exception re)
/*     */         {
/* 349 */           HashMap<String, Object> inserts = new HashMap();
/* 350 */           inserts.put("JCA_JMS_EXCEPTION", re.getMessage());
/* 351 */           JCAMessageBuilder.buildWarning("MQJCA4018", inserts);
/*     */           
/* 353 */           JCATraceAdapter.traceException(this, "AbstractWorkImpl", "run()", re);
/*     */         }
/*     */         
/* 356 */         if (endpoint != null) {
/* 357 */           if (JCATraceAdapter.isOn) {
/* 358 */             JCATraceAdapter.traceInfo(this, "AbstractWorkImpl", "run()", "releasing MessageEndpoint: " + endpoint);
/*     */           }
/* 360 */           endpoint.release();
/*     */         }
/*     */         
/*     */ 
/* 364 */         if ((!this.exceptionThrown) && (!this.rolledBack)) {
/* 365 */           setFailedLastTime(false);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 370 */     if (JCATraceAdapter.isOn) {
/* 371 */       JCATraceAdapter.traceExit(this, "AbstractWorkImpl", "run()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void release()
/*     */   {
/* 385 */     if (JCATraceAdapter.isOn) {
/* 386 */       JCATraceAdapter.traceNonNLSWarning(this, "AbstractWorkImpl", "release()", "release called, ignoring", null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean currentThreadIsFailingThread()
/*     */   {
/* 394 */     boolean currentThreadIsFailingThread = this.failingThread == Thread.currentThread();
/* 395 */     if (JCATraceAdapter.isOn) {
/* 396 */       JCATraceAdapter.traceData(this, "AbstractWorkImpl", "currentThreadIsFailingThread", "returning value", Boolean.valueOf(currentThreadIsFailingThread));
/*     */     }
/* 398 */     return currentThreadIsFailingThread;
/*     */   }
/*     */   
/*     */   void setFailingThreadToThis() {
/* 402 */     if (JCATraceAdapter.isOn) {
/* 403 */       JCATraceAdapter.traceData(this, "AbstractWorkImpl", "setFailingThreadToThis", "setting", null);
/*     */     }
/* 405 */     this.failingThread = Thread.currentThread();
/*     */   }
/*     */   
/*     */   void unSetFailingThread() {
/* 409 */     if (JCATraceAdapter.isOn) {
/* 410 */       JCATraceAdapter.traceData(this, "AbstractWorkImpl", "unSetFailingThread", "setting", null);
/*     */     }
/* 412 */     this.failingThread = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void xaStateChanged(int xaState)
/*     */   {
/* 422 */     if (xaState == 6)
/*     */     {
/*     */ 
/* 425 */       if (!this.exceptionThrown) {
/* 426 */         this.failingThread = Thread.currentThread();
/* 427 */         ResourceAdapterImpl.getJCARuntimeHelper().deliveryFailed(new TransactionRolledBackException(""), this.theDeployment.getActivationSpec(), this.theDeployment.getEndpointFactory(), isFailedLastTime());
/*     */         
/* 429 */         this.failingThread = null;
/*     */       }
/* 431 */       setFailedLastTime(true);
/* 432 */       this.rolledBack = true;
/*     */     }
/* 434 */     else if (xaState == 1)
/*     */     {
/* 436 */       setFailedLastTime(false);
/* 437 */       this.rolledBack = false;
/*     */     }
/*     */   }
/*     */   
/*     */   void setFailedLastTime(boolean failedLastTime) {
/* 442 */     this.failedLastTime = failedLastTime;
/*     */   }
/*     */   
/*     */   boolean isFailedLastTime() {
/* 446 */     return this.failedLastTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isDisposeRequired()
/*     */   {
/* 456 */     boolean traceRet = this.beforeDeliveryFailed;
/* 457 */     if (JCATraceAdapter.isOn) {
/* 458 */       JCATraceAdapter.traceInfo(this, "WorkImpl", "isDisposeRequired", "beforeDeliveryFailed: " + this.beforeDeliveryFailed + ", returning: " + traceRet);
/*     */     }
/* 460 */     return traceRet;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/inbound/AbstractWorkImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */