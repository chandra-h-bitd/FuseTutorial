/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.JCARuntimeHelper;
/*     */ import com.ibm.mq.connector.ResourceAdapterImpl;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.IllegalStateException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageConsumer;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageConsumerWrapper
/*     */   implements MessageConsumer
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/MessageConsumerWrapper.java";
/*  59 */   protected Destination theDestination = null;
/*     */   
/*  61 */   protected MessageConsumer theConsumer = null;
/*     */   
/*  63 */   protected boolean isOpen = true;
/*     */   
/*  65 */   protected boolean isManaged = false;
/*     */   
/*  67 */   protected SessionWrapper theSessionWrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageConsumerWrapper() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageConsumerWrapper(SessionWrapper sw, Session s, boolean isManaged, Destination d)
/*     */     throws JMSException
/*     */   {
/*  85 */     this(sw, s, isManaged, d, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageConsumerWrapper(SessionWrapper sw, Session s, boolean isManaged, Destination d, String sel)
/*     */     throws JMSException
/*     */   {
/*  99 */     this(sw, s, isManaged, d, sel, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageConsumerWrapper(SessionWrapper sw, Session s, boolean isManaged, Destination d, String sel, boolean noloc)
/*     */     throws JMSException
/*     */   {
/* 120 */     JCATraceAdapter.traceEntry(this, "MessageConsumerWrapper", "<init>");
/*     */     
/* 122 */     this.isManaged = isManaged;
/*     */     
/* 124 */     if ((d instanceof MQDestinationProxy))
/*     */     {
/* 126 */       this.theDestination = ((MQDestinationProxy)d).getMQDestination();
/* 127 */       JCATraceAdapter.traceInfo(this, "MessageConsumerWrapper", "<init>", "extracted Destination: " + this.theDestination);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 132 */       this.theDestination = d;
/* 133 */       JCATraceAdapter.traceInfo(this, "MessageConsumerWrapper", "<init>", "using Destination: " + this.theDestination);
/*     */     }
/*     */     
/*     */ 
/* 137 */     this.theSessionWrapper = sw;
/*     */     
/* 139 */     JCATraceAdapter.traceInfo(this, "MessageConsumerWrapper", "<init>", "noLocal: " + noloc + ", selector: " + sel);
/*     */     
/*     */     try
/*     */     {
/* 143 */       this.theConsumer = s.createConsumer(this.theDestination, sel, noloc);
/*     */     }
/*     */     finally
/*     */     {
/* 147 */       JCATraceAdapter.traceExit(this, "MessageConsumerWrapper", "<init>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMessageSelector()
/*     */     throws JMSException
/*     */   {
/* 155 */     assertOpen();
/* 156 */     return this.theConsumer.getMessageSelector();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MessageListener getMessageListener()
/*     */     throws JMSException
/*     */   {
/* 164 */     if (this.isManaged) {
/* 165 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1025"));
/*     */     }
/*     */     
/*     */ 
/* 169 */     return this.theConsumer.getMessageListener();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageListener(MessageListener arg0)
/*     */     throws JMSException
/*     */   {
/* 178 */     if ((!this.isManaged) || (ResourceAdapterImpl.getJCARuntimeHelper().isSystemMessageListener(arg0))) {
/* 179 */       this.theConsumer.setMessageListener(arg0);
/*     */     }
/*     */     else {
/* 182 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1025"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Message receive()
/*     */     throws JMSException
/*     */   {
/* 192 */     assertOpen();
/* 193 */     return this.theConsumer.receive();
/*     */   }
/*     */   
/*     */ 
/*     */   public Message receive(long arg0)
/*     */     throws JMSException
/*     */   {
/* 200 */     assertOpen();
/* 201 */     return this.theConsumer.receive(arg0);
/*     */   }
/*     */   
/*     */ 
/*     */   public Message receiveNoWait()
/*     */     throws JMSException
/*     */   {
/* 208 */     assertOpen();
/* 209 */     return this.theConsumer.receiveNoWait();
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws JMSException
/*     */   {
/*     */     try
/*     */     {
/* 217 */       this.theConsumer.close();
/* 218 */       this.isOpen = false;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 224 */       this.theSessionWrapper.hasClosed(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 234 */     if (!this.isOpen)
/*     */     {
/* 236 */       throw ((IllegalStateException)JCAExceptionBuilder.buildException(4, "MQJCA1022"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/MessageConsumerWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */