/*     */ package com.ibm.mq.connector.outbound;
/*     */ 
/*     */ import com.ibm.mq.connector.ConnectionBuilder;
/*     */ import com.ibm.mq.connector.ConnectionFactoryBuilder;
/*     */ import com.ibm.mq.connector.configuration.TransportTypeEnum;
/*     */ import com.ibm.mq.connector.services.JCAExceptionBuilder;
/*     */ import com.ibm.mq.connector.services.JCALogger;
/*     */ import com.ibm.mq.connector.services.JCAMessageBuilder;
/*     */ import com.ibm.mq.connector.services.JCATraceAdapter;
/*     */ import com.ibm.msg.client.commonservices.Log.Log;
/*     */ import com.ibm.msg.client.commonservices.componentmanager.ComponentManager;
/*     */ import com.ibm.msg.client.commonservices.cssystem.WASSupport.WASRuntimeHelper;
/*     */ import com.ibm.msg.client.commonservices.j2se.J2SEComponent;
/*     */ import com.ibm.msg.client.commonservices.propertystore.PropertyStore;
/*     */ import com.ibm.msg.client.commonservices.provider.log.CSPLog;
/*     */ import com.ibm.msg.client.wmq.factories.WMQComponent;
/*     */ import java.io.PrintWriter;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.XAConnectionFactory;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.resource.spi.ManagedConnectionFactory;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedConnectionFactoryImpl
/*     */   extends ManagedConnectionFactoryConfiguration
/*     */   implements ManagedConnectionFactory
/*     */ {
/*     */   static final String copyright_notice = "Licensed Materials - Property of IBM 5724-H72, 5655-R36, 5724-L26, 5655-L82                (c) Copyright IBM Corp. 2008, 2011 All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
/*     */   private static final String sccsid = "@(#) MQMBID sn=p750-002-130704 su=_UmspIOSZEeK1oKoKL_dPJA pn=com.ibm.mq.connector/src/com/ibm/mq/connector/outbound/ManagedConnectionFactoryImpl.java";
/*     */   private static final long serialVersionUID = 2305843009213693951L;
/*  96 */   protected transient PrintWriter thePrintWriter = null;
/*     */   
/*     */ 
/*  99 */   private static JCALogger logger = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private static CSPLog originalLogger = null;
/*     */   
/*     */ 
/* 108 */   private static transient boolean pwWarningSent = false;
/*     */   
/*     */ 
/* 111 */   protected ConnectionFactory theCF = null;
/*     */   
/*     */ 
/* 114 */   private boolean isManaged = false;
/*     */   
/* 116 */   private Object lock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 126 */     ComponentManager compmgr = ComponentManager.getInstance();
/* 127 */     compmgr.registerComponent(new J2SEComponent());
/* 128 */     compmgr.registerComponent(new WMQComponent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnectionFactoryImpl()
/*     */   {
/* 137 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "<init>");
/*     */     
/* 139 */     JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "<init>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object createConnectionFactory(ConnectionManager cm)
/*     */   {
/* 152 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "createConnectionFactory(...)");
/*     */     
/*     */     try
/*     */     {
/* 156 */       this.isManaged = true;
/* 157 */       return new ConnectionFactoryImpl(this, cm);
/*     */     }
/*     */     finally
/*     */     {
/* 161 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "createConnectionFactory(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object createConnectionFactory()
/*     */   {
/* 173 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "createConnectionFactory()");
/*     */     try
/*     */     {
/* 176 */       this.isManaged = false;
/* 177 */       return new ConnectionFactoryImpl(this);
/*     */     }
/*     */     finally
/*     */     {
/* 181 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "createConnectionFactory()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnection createManagedConnection(Subject arg0, ConnectionRequestInfo arg1)
/*     */     throws ResourceException
/*     */   {
/* 197 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "createManagedConnection(...)");
/*     */     try
/*     */     {
/* 200 */       ManagedConnection mc = new ManagedConnectionImpl(arg0, arg1, this);
/*     */       
/* 202 */       mc.setLogWriter(this.thePrintWriter);
/*     */       
/* 204 */       return mc;
/*     */     }
/*     */     finally
/*     */     {
/* 208 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "createManagedConnection(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ManagedConnection matchManagedConnections(final Set connectionSet, final Subject subject, final ConnectionRequestInfo cri)
/*     */   {
/* 231 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)");
/*     */     
/*     */     try
/*     */     {
/* 235 */       ManagedConnection theConnection = null;
/*     */       
/*     */ 
/* 238 */       if (JCATraceAdapter.isOn) {
/* 239 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "ConnectionRequestInfo: " + cri);
/* 240 */         JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "Subject: " + subject);
/*     */       }
/*     */       
/* 243 */       theConnection = (ManagedConnection)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public ManagedConnection run() {
/* 246 */           ManagedConnection connection = null;
/*     */           
/* 248 */           if (connectionSet != null) {
/* 249 */             if (JCATraceAdapter.isOn) {
/* 250 */               JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "supplied set contains " + connectionSet.size() + " entries");
/*     */             }
/*     */             
/*     */ 
/* 254 */             synchronized (ManagedConnectionFactoryImpl.this.lock)
/*     */             {
/* 256 */               Iterator i = connectionSet.iterator();
/* 257 */               while ((connection == null) && (i.hasNext())) {
/* 258 */                 Object o = i.next();
/*     */                 
/* 260 */                 if ((o instanceof ManagedConnectionImpl))
/*     */                 {
/* 262 */                   ManagedConnectionImpl mc = (ManagedConnectionImpl)o;
/*     */                   
/* 264 */                   if (mc.isTransactionStarted()) {
/* 265 */                     JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "transaction in progress on connection, skipping");
/*     */ 
/*     */ 
/*     */                   }
/* 269 */                   else if ((cri != null) && (cri.equals(mc.getConnectionRequestInfo()))) {
/* 270 */                     connection = mc;
/*     */ 
/*     */                   }
/* 273 */                   else if ((cri == null) && (subject != null) && (subject.equals(mc.getSubject()))) {
/* 274 */                     connection = mc;
/*     */ 
/*     */ 
/*     */                   }
/* 278 */                   else if ((cri == null) && (subject == null) && 
/* 279 */                     (mc.getConnectionRequestInfo() == null) && (mc.getSubject() == null)) {
/* 280 */                     connection = mc;
/*     */                   }
/*     */                   
/*     */ 
/*     */                 }
/*     */                 else
/*     */                 {
/* 287 */                   JCATraceAdapter.traceNonNLSWarning(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "unexpected object in MCF set: " + o.getClass(), null);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 294 */             JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "null set supplied");
/*     */           }
/* 296 */           return connection;
/*     */         }
/*     */         
/* 299 */       });
/* 300 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)", "returning: " + theConnection);
/*     */       
/* 302 */       return theConnection;
/*     */     }
/*     */     finally
/*     */     {
/* 306 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "matchManagedConnections(...)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogWriter(PrintWriter pw)
/*     */   {
/* 329 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "setLogWriter()");
/*     */     
/* 331 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "setLogWriter()", "PrintWriter: " + pw);
/*     */     
/*     */ 
/* 334 */     if (JCATraceAdapter.isLogWriterEnabled()) {
/* 335 */       this.thePrintWriter = pw;
/*     */     }
/*     */     else
/*     */     {
/* 339 */       this.thePrintWriter = null;
/*     */       
/*     */ 
/*     */ 
/* 343 */       if (!isPwWarningSent()) {
/* 344 */         JCAMessageBuilder.buildWarning("MQJCA4017");
/*     */         
/* 346 */         setPwWarningSent(true);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 351 */     if (this.thePrintWriter != null) {
/* 352 */       if (logger == null) {
/* 353 */         logger = new JCALogger(this.thePrintWriter);
/* 354 */         originalLogger = Log.getCSPLog();
/* 355 */         Log.setCSPLog(logger);
/*     */       }
/*     */       else
/*     */       {
/* 359 */         logger.setWriter(this.thePrintWriter);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 365 */     else if (originalLogger != null)
/*     */     {
/* 367 */       Log.setCSPLog(originalLogger);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 376 */     JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "setLogWriter()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintWriter getLogWriter()
/*     */     throws ResourceException
/*     */   {
/* 392 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "getLogWriter()", "returning log writer: " + this.thePrintWriter);
/* 393 */     return this.thePrintWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getInvalidConnections(Set connectionSet)
/*     */   {
/*     */     try
/*     */     {
/* 410 */       JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "getInvalidConnections()");
/*     */       
/* 412 */       JCATraceAdapter.traceNonNLSWarning(this, "ManagedConnectionFactoryImpl", "getInvalidConnections()", "ManagedConnectionFactoryImpl.getInvalidConnections() called", null);
/*     */       
/* 414 */       return new HashSet();
/*     */     }
/*     */     finally
/*     */     {
/* 418 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "getInvalidConnections()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection createConnection(ManagedConnectionImpl mc, Subject subj, ConnectionRequestInfo cri)
/*     */     throws ResourceException
/*     */   {
/* 433 */     if (this.theCF == null) {
/*     */       try {
/* 435 */         this.theCF = createConnectionFactory(1);
/*     */       }
/*     */       catch (JMSException je)
/*     */       {
/* 439 */         throw ((ResourceException)JCAExceptionBuilder.buildException(0, "MQJCA1012", je));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 444 */     return ConnectionBuilder.createConnection(this.theCF, this, mc, subj, cri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConnectionFactory createConnectionFactory(int type)
/*     */     throws JMSException
/*     */   {
/* 456 */     JCATraceAdapter.traceEntry(this, "ManagedConnectionFactoryImpl", "createConnectionFactory()");
/*     */     
/* 458 */     ConnectionFactory cf = null;
/*     */     try
/*     */     {
/* 461 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "createConnectionFactory()", "Instantiating ConnectionFactory");
/* 462 */       cf = ConnectionFactoryBuilder.getInstance().createConnectionFactory(this, type, true);
/* 463 */       return cf;
/*     */     }
/*     */     finally
/*     */     {
/* 467 */       JCATraceAdapter.traceExit(this, "ManagedConnectionFactoryImpl", "createConnectionFactory()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isXAConnectionFactory()
/*     */   {
/* 477 */     return this.theCF instanceof XAConnectionFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isManaged()
/*     */   {
/* 486 */     return this.isManaged;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void setPwWarningSent(boolean pw)
/*     */   {
/* 495 */     pwWarningSent = pw;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static boolean isPwWarningSent()
/*     */   {
/* 504 */     return pwWarningSent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean getRRSTransactional()
/*     */   {
/* 522 */     boolean rrsTransactional = false;
/* 523 */     WASSupport.WASRuntimeHelper helper = (WASSupport.WASRuntimeHelper)PropertyStore.getObjectProperty("com.ibm.mq.connector.JCARuntimeHelper");
/* 524 */     if ((helper != null) && 
/* 525 */       (helper.getEnvironment() == 184)) {
/* 526 */       JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "getRRSTransactional()", "Running on zOS Liberty");
/*     */       
/* 528 */       TransportTypeEnum trType = getTransportTypeEnum();
/*     */       
/* 530 */       if (trType == TransportTypeEnum.BINDINGS) {
/* 531 */         rrsTransactional = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 537 */     JCATraceAdapter.traceInfo(this, "ManagedConnectionFactoryImpl", "getRRSTransactional()", "rrsTransactional:" + rrsTransactional);
/* 538 */     return rrsTransactional;
/*     */   }
/*     */ }


/* Location:              /home/adongre/Documents/Stp/IBM/com.ibm.mq.connector.jar!/com/ibm/mq/connector/outbound/ManagedConnectionFactoryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */